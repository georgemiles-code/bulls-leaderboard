#!/bin/bash
cd "$(cd "$(dirname "$0")" && pwd)"
export BULLS_DATA_DIR="$PWD/data"
export BULLS_ENV_FILE="$PWD/.env"
export BULLS_FRONTEND_DIR="$PWD/web"
export BULLS_PORT=8097
export PYTHONNOUSERSITE=1          # ignore any system packages -> use the bundled ones
export BULLS_RESTARTABLE=1         # lets the in-app "Update now" button restart the engine
echo "Starting the Leaderboard engine..."
# Force arm64 on Apple Silicon so Python matches the arm64 vendored packages (a double-clicked
# launcher can otherwise start under x86_64/Rosetta and crash on pydantic_core). Detect via
# sysctl (uname -m reports the launcher's own arch, unreliable under Rosetta).
PY="/usr/bin/python3"
if [ "$(sysctl -n hw.optional.arm64 2>/dev/null)" = "1" ]; then PY="arch -arm64 /usr/bin/python3"; fi
# Restart loop: relaunch the engine whenever it exits with code 42 (the "Update now" button
# triggers this so new backend code takes effect). Any other exit ends the loop.
( while true; do
    $PY "$PWD/api/serve.py"
    [ $? -eq 42 ] || break
    echo "Applying update, restarting engine..."; sleep 2
  done ) &
ENGINE=$!
sleep 5
URL="http://localhost:8097"
# Browser profile lives in Application Support, NOT the app folder, so running from a
# OneDrive-synced folder doesn't make OneDrive churn on the live browser profile.
PROFILE="$HOME/Library/Application Support/Leaderboard/chrome-profile"
mkdir -p "$PROFILE"
if [ -d "/Applications/Google Chrome.app" ]; then
  open -na "Google Chrome" --args --kiosk --user-data-dir="$PROFILE" --no-first-run "$URL"
else
  open "$URL"
fi
echo ""
echo "Leaderboard is running. Leave this window open."
echo "To stop: close the board (Cmd+Q), then close this window."
wait $ENGINE
