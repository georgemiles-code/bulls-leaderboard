' Launches the Leaderboard with NOTHING terminal-like visible — only the board fullscreen.
' Runs via wscript (windowless). It starts the engine supervisor HIDDEN (window style 0) and
' opens the board in Chrome kiosk. This is the file the Desktop shortcut points at.
Option Explicit
Dim sh, fso, base, profile, chrome, url
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName) & "\"
url = "http://localhost:8097"

' Clear any previous engine so windows/processes never pile up (hidden, wait for it to finish)
sh.Run "cmd /c taskkill /f /im pythonw.exe & taskkill /f /im python.exe", 0, True

' Start the engine supervisor loop, fully hidden (0 = hidden window)
sh.Run """" & base & "engine-loop (Windows).bat""", 0, False

' Give the engine a few seconds to come up
WScript.Sleep 6000

' Open the board fullscreen (visible — this is the only thing you should see)
profile = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Leaderboard\chrome-profile"
chrome = sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe"
If Not fso.FileExists(chrome) Then chrome = sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Google\Chrome\Application\chrome.exe"
If fso.FileExists(chrome) Then
  sh.Run """" & chrome & """ --kiosk --user-data-dir=""" & profile & """ --no-first-run --disable-first-run-ui " & url, 1, False
Else
  sh.Run "msedge --kiosk --user-data-dir=""" & sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Leaderboard\edge-profile"" --no-first-run " & url, 1, False
End If
