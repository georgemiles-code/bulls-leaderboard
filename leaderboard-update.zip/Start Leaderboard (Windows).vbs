' Launches the Leaderboard with NOTHING terminal-like ever visible — only the board fullscreen.
' Runs via wscript (windowless). Clears old engines via WMI (no console), starts the VBScript
' engine supervisor windowless, then opens the board in Chrome kiosk. This is what the Desktop
' shortcut points at.
Option Explicit
Dim sh, fso, base, profile, chrome, url, procs, p
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName) & "\"
url = "http://localhost:8097"

' Clear any previous engine via WMI (no console window, so no terminal tab)
On Error Resume Next
Set procs = GetObject("winmgmts:").ExecQuery("Select * from Win32_Process Where Name='pythonw.exe' Or Name='python.exe'")
For Each p In procs
  p.Terminate()
Next
On Error Goto 0

' Start the engine supervisor (windowless wscript running the .vbs loop)
sh.Run "wscript.exe """ & base & "engine-loop (Windows).vbs""", 0, False

' Give the engine a few seconds to come up
WScript.Sleep 6000

' Open the board fullscreen (the only thing you should ever see)
profile = sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Leaderboard\chrome-profile"
chrome = sh.ExpandEnvironmentStrings("%ProgramFiles%") & "\Google\Chrome\Application\chrome.exe"
If Not fso.FileExists(chrome) Then chrome = sh.ExpandEnvironmentStrings("%ProgramFiles(x86)%") & "\Google\Chrome\Application\chrome.exe"
If fso.FileExists(chrome) Then
  sh.Run """" & chrome & """ --kiosk --user-data-dir=""" & profile & """ --no-first-run --disable-first-run-ui " & url, 1, False
Else
  sh.Run "msedge --kiosk --user-data-dir=""" & sh.ExpandEnvironmentStrings("%LOCALAPPDATA%") & "\Leaderboard\edge-profile"" --no-first-run " & url, 1, False
End If
