@echo off
rem The real launch is the windowless .vbs (no terminal windows at all). This .bat just hands off
rem to it via wscript and exits, so double-clicking the .bat also gives a clean hidden start.
start "" wscript.exe "%~dp0Start Leaderboard (Windows).vbs"
exit
