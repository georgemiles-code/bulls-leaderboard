@echo off
title Stop Leaderboard
taskkill /f /im pythonw.exe >nul 2>&1
taskkill /f /im python.exe >nul 2>&1
taskkill /f /fi "WINDOWTITLE eq Leaderboard Engine*" >nul 2>&1
exit
