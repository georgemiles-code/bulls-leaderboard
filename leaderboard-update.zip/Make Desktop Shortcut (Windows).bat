@echo off
title Make Leaderboard Shortcut
rem Creates a Desktop shortcut (Bulls icon) that launches the board with NO terminal windows.
rem It targets wscript.exe running the windowless .vbs launcher.
set "VBS=%~dp0Start Leaderboard (Windows).vbs"
set "ICON=%~dp0Leaderboard.ico"
powershell -NoProfile -Command "$w=New-Object -ComObject WScript.Shell; $lnk=$w.CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Leaderboard.lnk'); $lnk.TargetPath='wscript.exe'; $lnk.Arguments=('\"'+$env:VBS+'\"'); $lnk.IconLocation=$env:ICON; $lnk.WorkingDirectory='%~dp0'; $lnk.Save()"
echo.
echo Done - a "Leaderboard" icon (Bulls logo) is on your Desktop.
echo Double-click it to run the board. No black windows will appear.
pause
