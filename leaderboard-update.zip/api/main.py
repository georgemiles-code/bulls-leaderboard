"""Bulls Dashboard v2 — FastAPI backend. Runs on port 8093."""
import json
import os
import re
from contextlib import asynccontextmanager
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

NZT = timezone(timedelta(hours=12))  # NZST (UTC+12, standard time)

def _today_nzt() -> str:
    return datetime.now(NZT).strftime("%Y-%m-%d")

from fastapi import BackgroundTasks, FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel

from routes.calendar import router as calendar_router
from routes.force_lab import router as force_lab_router, start_auto_publish
from routes.gymaware import router as gymaware_router
from routes.gps import router as gps_router
from routes.strength import router as strength_router
from routes.athlete_hub import router as hub_router
from routes.chat import router as chat_router
from routes.sync import router as sync_router, start_scheduler
from routes.updates import router as updates_router, start_update_checker
from routes.attendance import router as attendance_router
from routes.rehab_programs import router as rehab_programs_router
from routes.programming import router as programming_router
from routes.run_session_plans import router as run_session_plans_router
from routes.periodisation import router as periodisation_router
from routes.injuries import router as injuries_router
from routes.briefing import router as briefing_router, start_briefing_scheduler
from routes.s_and_c import router as s_and_c_router

# Same BULLS_DATA_DIR-first resolution as force_lab.py/sync.py — in the bundled .app,
# `__file__`-relative paths point nowhere near the real repo (only v2/api is bundled as a
# resource), so this must check the env var the Rust shell sets first. Without it, every
# _read_json call here (including the athlete lookup behind /athletes/{id}/photo) silently
# returned an empty default in the packaged app, which is why athlete photos have never
# shown up on the TV — the 404 wasn't a missing photo file, it was a failed athlete lookup.
_data_env = os.environ.get("BULLS_DATA_DIR", "")
if _data_env:
    DATA_DIR = Path(_data_env)
    _REPO_ROOT = DATA_DIR.parent
else:
    DATA_DIR = Path(__file__).parent.parent.parent / "data"
    _REPO_ROOT = Path(__file__).parent.parent.parent


@asynccontextmanager
async def lifespan(app: FastAPI):
    start_scheduler()
    start_update_checker()
    start_auto_publish()
    start_briefing_scheduler()
    yield


app = FastAPI(title="Bulls Dashboard v2", version="2.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:1420", "http://localhost:8093", "tauri://localhost", "https://georgemiles-code.github.io"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(calendar_router)
app.include_router(force_lab_router)
app.include_router(gymaware_router)
app.include_router(gps_router)
app.include_router(strength_router)
app.include_router(hub_router)
app.include_router(chat_router)
app.include_router(sync_router)
app.include_router(updates_router)
app.include_router(attendance_router)
app.include_router(rehab_programs_router)
app.include_router(programming_router)
app.include_router(run_session_plans_router)
app.include_router(periodisation_router)
app.include_router(injuries_router)
app.include_router(briefing_router)
app.include_router(s_and_c_router)


def _read_json(name: str, default=None):
    path = DATA_DIR / name
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text())
    except Exception:
        return default


def _parse_date(s: str) -> Optional[datetime]:
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except (ValueError, TypeError):
            pass
    return None


def _cmj_readiness(history: list) -> dict:
    """Compute latest CMJ and delta vs 7-day rolling average."""
    if not history:
        return {"latest_jh": None, "latest_date": None, "avg_7d": None, "delta_pct": None, "days_since": None}

    today = datetime.now(NZT).replace(tzinfo=None)
    dated = [(h, _parse_date(h.get("date", ""))) for h in history]
    dated = [(h, d) for h, d in dated if d is not None]
    dated.sort(key=lambda x: x[1])

    if not dated:
        return {"latest_jh": None, "latest_date": None, "avg_7d": None, "delta_pct": None, "days_since": None}

    latest_entry, latest_dt = dated[-1]
    latest_jh = latest_entry.get("jh")
    days_since = (today - latest_dt).days

    # 7-day rolling avg — entries in the 7 days before and including the latest test
    window_start = latest_dt - timedelta(days=7)
    window = [h.get("jh") for h, d in dated if window_start <= d <= latest_dt and h.get("jh")]
    avg_7d = round(sum(window) / len(window), 1) if window else None

    delta_pct = None
    if latest_jh and avg_7d and avg_7d > 0:
        delta_pct = round((latest_jh - avg_7d) / avg_7d * 100, 1)

    return {
        "latest_jh": round(float(latest_jh), 1) if latest_jh else None,
        "latest_date": latest_dt.strftime("%Y-%m-%d"),
        "avg_7d": avg_7d,
        "delta_pct": delta_pct,
        "days_since": days_since,
    }


def _cmj_flag(r: dict) -> Optional[str]:
    if r["days_since"] is None:
        return "no_data"
    if r["days_since"] > 14:
        return "stale"
    if r["delta_pct"] is not None and r["delta_pct"] <= -10:
        return "drop"
    return None


@app.get("/health")
def health():
    return {"ok": True, "version": "2.0.0"}


# ── In-app auto-update (web-based) ───────────────────────────────────────────────
# The app checks a public URL (GitHub Pages) for a newer build, downloads the update zip over
# HTTPS itself, extracts it over its own files, and restarts — no OneDrive, no file-sync. This
# works on ANY machine with internet, whether it runs from a local folder or anywhere else.
#
# Why extracting-while-running is safe: the payload only contains web/ (served per-request, not
# locked), api/*.py (Python reads source at import then closes the handle — not locked) and
# small data/version files. python-win/vendor/.env are never in the payload. After extracting,
# the engine exits with _RESTART_CODE so the restart-loop launcher relaunches it with new code.
import threading as _threading
import time as _time
import zipfile as _zipfile
import io as _io
import requests as _requests  # vendored (bundles certifi) — robust HTTPS on Windows embeddable
                              # Python, where urllib's reliance on the OS cert store often fails.

_VERSION_FILE = _REPO_ROOT / "version.json"
_RESTART_CODE = 42
_UPDATE_BASE = os.environ.get("BULLS_UPDATE_URL", "https://georgemiles-code.github.io/bulls-leaderboard").rstrip("/")
_STAGING = _REPO_ROOT / ".update"
_upd = {"latest": "", "notes": "", "ready": False, "checking": False, "last_check": 0.0, "error": ""}

def _local_version() -> str:
    try:
        return str(json.loads(_VERSION_FILE.read_text()).get("version", ""))
    except Exception:
        return ""

def _staged_version() -> str:
    try:
        return (_STAGING / "staged.version").read_text().strip()
    except Exception:
        return ""

def _check_and_stage() -> None:
    """Fetch the remote version; if newer than local, download+stage the update zip. Best-effort
    (network may be down); errors are recorded, not raised."""
    if _upd["checking"]:
        return
    _upd["checking"] = True
    try:
        cb = int(_time.time())  # cache-bust GitHub Pages/CDN
        resp = _requests.get(f"{_UPDATE_BASE}/leaderboard-version.json?t={cb}", timeout=15)
        resp.raise_for_status()
        meta = resp.json()
        latest = str(meta.get("version", "")); _upd["latest"] = latest; _upd["notes"] = meta.get("notes", "")
        _upd["last_check"] = _time.time(); _upd["error"] = ""
        if latest and latest != _local_version():
            if _staged_version() != latest:  # need to (re)download
                zr = _requests.get(f"{_UPDATE_BASE}/leaderboard-update.zip?t={cb}", timeout=180)
                zr.raise_for_status()
                data = zr.content
                _zipfile.ZipFile(_io.BytesIO(data))  # validate; raises on corrupt download
                _STAGING.mkdir(exist_ok=True)
                (_STAGING / "staged.zip").write_bytes(data)
                (_STAGING / "staged.version").write_text(latest)
            _upd["ready"] = True
        else:
            _upd["ready"] = False
    except Exception as e:
        _upd["error"] = str(e)
    finally:
        _upd["checking"] = False

@app.get("/app-version")
def app_version():
    # Current running version (used for the faint on-screen "Updated …" stamp).
    return {"version": _local_version(), "notes": "", "restartable": os.environ.get("BULLS_RESTARTABLE") == "1"}

@app.get("/update-status")
def update_status():
    # Only the packaged/browser app (restart-loop launcher sets BULLS_RESTARTABLE=1) self-updates.
    # The dev Tauri app must NOT — otherwise it would download and extract a build over the repo.
    if os.environ.get("BULLS_RESTARTABLE") != "1":
        return {"current": _local_version(), "latest": "", "available": False, "ready": False, "notes": "", "error": ""}
    # Kick a background check if it's been >5 min (keeps GET fast; never blocks the UI).
    if not _upd["checking"] and _time.time() - _upd["last_check"] > 300:
        _threading.Thread(target=_check_and_stage, daemon=True).start()
    cur = _local_version()
    return {"current": cur, "latest": _upd["latest"],
            "available": bool(_upd["latest"]) and _upd["latest"] != cur,
            "ready": _upd["ready"], "notes": _upd["notes"], "error": _upd["error"]}

@app.post("/apply-update")
def apply_update():
    """Extract the staged update over the app files, then exit so the restart-loop launcher
    relaunches with the new code. Returns before exiting so the response flushes."""
    staged = _STAGING / "staged.zip"
    if staged.exists():
        try:
            with _zipfile.ZipFile(staged) as z:
                z.extractall(_REPO_ROOT)   # zip holds relative paths: web/…, api/…, data/…, version.json
                # DELETE.json (if present) lists relative paths to remove after extracting —
                # extraction can only add/overwrite, so removing a retired file (e.g. an athlete's
                # photo they've asked to take down) needs this explicit step to actually reach
                # every already-installed board, not just the freshly-published payload.
                if "DELETE.json" in z.namelist():
                    for rel in json.loads(z.read("DELETE.json").decode()):
                        (_REPO_ROOT / rel).unlink(missing_ok=True)
            staged.unlink(missing_ok=True)
            (_STAGING / "staged.version").unlink(missing_ok=True)
        except Exception as e:
            return {"restarting": False, "error": f"extract failed: {e}"}
    if os.environ.get("BULLS_RESTARTABLE") == "1":
        _threading.Thread(target=lambda: (_time.sleep(1.0), os._exit(_RESTART_CODE)), daemon=True).start()
        return {"restarting": True}
    # Not restartable (e.g. dev Tauri app): files are updated on disk; a reload applies them.
    return {"restarting": False}


@app.post("/cast-to-tv")
def cast_to_tv():
    """Open the OS wireless-display / screen-mirroring picker so the operator just picks the TV.
    Windows: injects Win+K (the 'Cast / Connect to a wireless display' panel). Mac: opens the
    Screen Mirroring control. Best-effort — the frontend shows manual steps if this can't fire."""
    import subprocess
    try:
        if os.name == "nt":
            # Send Win+K via keybd_event so the Cast flyout opens over the fullscreen board.
            ps = (
                "$s='[DllImport(\"user32.dll\")] public static extern void keybd_event(byte b,byte c,uint f,int e);';"
                "Add-Type -MemberDefinition $s -Name K -Namespace W;"
                "[W.K]::keybd_event(0x5B,0,0,0);[W.K]::keybd_event(0x4B,0,0,0);"
                "Start-Sleep -Milliseconds 60;"
                "[W.K]::keybd_event(0x4B,0,2,0);[W.K]::keybd_event(0x5B,0,2,0)"
            )
            subprocess.Popen(["powershell", "-NoProfile", "-Command", ps],
                             creationflags=0x08000000)  # CREATE_NO_WINDOW
            return {"triggered": True, "platform": "windows"}
        if sys.platform == "darwin":
            # Open Control Center's Screen Mirroring via UI scripting (needs Accessibility perms;
            # unreliable across macOS versions) — best-effort, else the UI falls back to steps.
            script = ('tell application "System Events" to tell process "ControlCenter" to '
                      'click menu bar item "Screen Mirroring" of menu bar 1')
            r = subprocess.run(["osascript", "-e", script], capture_output=True, timeout=5)
            return {"triggered": r.returncode == 0, "platform": "mac"}
        return {"triggered": False, "platform": "other"}
    except Exception as e:
        return {"triggered": False, "error": str(e)}


def _week_dates_main(week_start = None) -> list:
    if week_start:
        try:
            monday = datetime.strptime(week_start, "%Y-%m-%d")
        except ValueError:
            monday = datetime.now(NZT).replace(tzinfo=None)
            monday -= timedelta(days=monday.weekday())
    else:
        today = datetime.now(NZT).replace(tzinfo=None)
        monday = today - timedelta(days=today.weekday())
    return [(monday + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(5)]


def _worst_flag(flags: dict) -> str:
    rank = {"red": 3, "amber": 2, "green": 1, "neutral": 0}
    if not flags:
        return "none"
    return max(flags.values(), key=lambda f: rank.get(f, 0))


def _migrate_gym_store(raw: dict) -> dict:
    """Migrate old list format to dict format in-memory."""
    for date, val in raw.items():
        if isinstance(val, list):
            raw[date] = {name: "present" for name in val}
    return raw


@app.get("/command-centre")
def command_centre(squad: str = "academy", week_start = None):
    athletes     = _read_json("athletes.json", [])
    wellness_all: dict = _read_json("wellness.json", {})
    gym_raw      = _read_json("gym_attendance.json", {})
    gym_store    = _migrate_gym_store(gym_raw)
    excluded_raw = _read_json("excluded_athletes.json", [])
    excluded     = set(excluded_raw)

    squad_athletes = [
        a for a in athletes
        if a.get("squad") == squad and a["name"] not in excluded
    ]

    today      = _today_nzt()
    week_dates = _week_dates_main(week_start)
    week_start = week_dates[0]
    week_end   = week_dates[-1]

    # Status counts
    status_counts = {"Full Contact": 0, "Modified Training": 0, "Rehab": 0, "Out": 0}
    for a in squad_athletes:
        s = a.get("status", "Full Contact")
        status_counts[s] = status_counts.get(s, 0) + 1

    ATTENDED = {"present", "remote"}

    athlete_cards = []
    wellness_submitted_count = 0

    for a in squad_athletes:
        name = a["name"]

        # Wellness
        w_records = wellness_all.get(name, [])
        this_week_w = [r for r in w_records if week_start <= r.get("date", "") <= week_end]
        submitted_this_week = len(this_week_w) > 0
        if submitted_this_week:
            wellness_submitted_count += 1

        latest_w = None
        if w_records:
            latest_w = max(w_records, key=lambda r: r.get("date", ""))

        wellness = {
            "submitted_this_week": submitted_this_week,
            "latest_date": latest_w["date"] if latest_w else None,
            "composite": latest_w.get("composite") if latest_w else None,
            "flags": latest_w.get("flags", {}) if latest_w else {},
            "responses": latest_w.get("responses", {}) if latest_w else {},
            "notes": latest_w.get("notes") if latest_w else None,
            "worst_flag": _worst_flag(latest_w.get("flags", {}) if latest_w else {}),
        }

        # Gym attendance this week — per-day status
        gym_week: dict = {}
        for d in week_dates:
            day_data = gym_store.get(d, {})
            gym_week[d] = day_data.get(name) if isinstance(day_data, dict) else None

        gym_days = [d for d, s in gym_week.items() if s in ATTENDED]
        gym_today_status = gym_week.get(today)
        gym_today = gym_today_status in ATTENDED

        athlete_cards.append({
            "id":               a["id"],
            "name":             name,
            "initials":         a.get("initials", name[:2].upper()),
            "position":         a.get("position", ""),
            "status":           a.get("status", "Full Contact"),
            "injury_notes":     a.get("injury_notes", None),
            "wellness":         wellness,
            "gym_week":         gym_week,
            "gym_days":         gym_days,
            "gym_today":        gym_today,
            "gym_today_status": gym_today_status,
        })

    flag_rank = {"red": 3, "amber": 2, "none": 1, "green": 0, "neutral": 0}
    athlete_cards.sort(key=lambda c: (-flag_rank.get(c["wellness"]["worst_flag"], 0), c["name"]))

    gym_today_count = sum(1 for c in athlete_cards if c["gym_today"])

    return {
        "squad":      squad,
        "today":      today,
        "week_dates": week_dates,
        "total":      len(squad_athletes),
        "status_counts": status_counts,
        "wellness_summary": {
            "submitted": wellness_submitted_count,
            "total":     len(squad_athletes),
            "rate_pct":  round(wellness_submitted_count / len(squad_athletes) * 100) if squad_athletes else 0,
        },
        "gym_summary": {
            "today_count": gym_today_count,
            "total":       len(squad_athletes),
            "today":       today,
        },
        "athletes":  athlete_cards,
        "gym_store": {d: gym_store.get(d, {}) for d in week_dates},
    }


@app.get("/athletes")
def athletes_list(squad: str = "academy"):
    data = _read_json("athletes.json", [])
    filtered = [a for a in data if a.get("squad") == squad]
    return {"athletes": filtered, "count": len(filtered)}


@app.get("/athletes/{athlete_id}")
def athlete(athlete_id: int):
    data = _read_json("athletes.json", [])
    a = next((x for x in data if x.get("id") == athlete_id), None)
    if not a:
        raise HTTPException(404, f"Athlete {athlete_id} not found")
    return a


# Resolved from _REPO_ROOT (see DATA_DIR above), not bundled as a Tauri resource — the
# photos dir isn't copied into the .app at build time, so this must point at the real
# repo's photos directly (same trick sync_agent.py relies on already).
#
# v2/public, NOT v2/dist — dist is Vite's build OUTPUT for the separate v2 web dashboard,
# wiped and regenerated from public/ on every `vite build`. Photos were originally written
# straight into dist/photos, invisible to Vite's source tracking, and got silently erased
# the next time that unrelated app got rebuilt (lost both a 40-photo import and the entire
# hero_photos batch this way). public/ is the actual source Vite copies FROM, so it
# survives a rebuild instead of getting nuked by one.
PHOTOS_DIR = _REPO_ROOT / "v2" / "public" / "photos"

@app.get("/athletes/{athlete_id}/photo")
def athlete_photo(athlete_id: int):
    data = _read_json("athletes.json", [])
    a = next((x for x in data if x.get("id") == athlete_id), None)
    if not a or not a.get("photo"):
        raise HTTPException(404, "No photo")
    photo_path = PHOTOS_DIR / a["photo"]
    if not photo_path.exists():
        # Extension-tolerant fallback: the packaged/distributed copy stores photos as .jpg
        # while athletes.json still names them .png (packaging re-encodes to JPEG). Match by
        # stem so the podium photos resolve regardless of the on-disk extension.
        stem = Path(a["photo"]).stem
        photo_path = next((c for c in sorted(PHOTOS_DIR.glob(stem + ".*"))
                           if c.suffix.lower() in (".jpg", ".jpeg", ".png", ".webp")), None)
        if photo_path is None:
            raise HTTPException(404, "Photo file not found")
    suffix = photo_path.suffix.lower()
    media_type = "image/jpeg" if suffix in (".jpg", ".jpeg") else "image/png"
    return FileResponse(str(photo_path), media_type=media_type)


# "Hero" cinematic photos — creative posed shots, several per athlete, shown as a big
# background in the PB/Leader/All-Time Record cinematics (not the small consistent-crop
# roster headshots above). Stored as v2/public/hero_photos/{slug}/0.jpg, 1.jpg, ... — see
# PHOTOS_DIR above for why public/ and not dist/. No per-athlete field to look up, so the
# slug is derived from the name the same way the import script derives it when writing
# the files.
HERO_PHOTOS_DIR = _REPO_ROOT / "v2" / "public" / "hero_photos"

def _hero_slug(name: str) -> str:
    slug = name.lower().strip().replace("'", "")
    slug = re.sub(r"\s+", "_", slug)
    slug = re.sub(r"[^a-z0-9_\-]", "", slug)
    return slug

@app.get("/athletes/{athlete_id}/hero-photos")
def athlete_hero_photo_count(athlete_id: int):
    data = _read_json("athletes.json", [])
    a = next((x for x in data if x.get("id") == athlete_id), None)
    if not a:
        raise HTTPException(404, f"Athlete {athlete_id} not found")
    d = HERO_PHOTOS_DIR / _hero_slug(a["name"])
    if not d.is_dir():
        return {"count": 0}
    count = len([f for f in d.iterdir() if f.suffix.lower() in (".jpg", ".jpeg", ".png")])
    return {"count": count}

@app.get("/athletes/{athlete_id}/hero-photo/{index}")
def athlete_hero_photo(athlete_id: int, index: int):
    data = _read_json("athletes.json", [])
    a = next((x for x in data if x.get("id") == athlete_id), None)
    if not a:
        raise HTTPException(404, f"Athlete {athlete_id} not found")
    photo_path = HERO_PHOTOS_DIR / _hero_slug(a["name"]) / f"{index}.jpg"
    if not photo_path.exists():
        raise HTTPException(404, "Hero photo not found")
    return FileResponse(str(photo_path), media_type="image/jpeg")


VALID_STATUSES = {"Full Contact", "Modified Training", "Rehab", "Out"}

class StatusUpdate(BaseModel):
    status: str

@app.patch("/athletes/{name}/status")
def update_athlete_status(name: str, body: StatusUpdate, background_tasks: BackgroundTasks):
    if body.status not in VALID_STATUSES:
        raise HTTPException(422, f"Invalid status")
    path = DATA_DIR / "athletes.json"
    data = json.loads(path.read_text())
    athlete = next((a for a in data if a.get("name") == name), None)
    if not athlete:
        raise HTTPException(404, f"Athlete '{name}' not found")
    old_status = athlete.get("status", "")
    athlete["status"] = body.status
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(path)
    # Agent 1: automatically draft individual program when athlete enters Modified Training
    if body.status == "Modified Training" and old_status != "Modified Training":
        from routes.programming import draft_individual_background
        background_tasks.add_task(
            draft_individual_background,
            name,
            athlete.get("injury_notes", ""),
            athlete.get("position", ""),
        )
    return {"name": name, "status": body.status}




# ── Browser mode (Windows package) ──────────────────────────────────────────────
# Serve the built frontend when BULLS_FRONTEND_DIR is set. Registered LAST so every API route
# above wins; unset on the Tauri desktop app (loads its own bundled frontend), so it's a no-op.
_frontend_dir = os.environ.get("BULLS_FRONTEND_DIR", "")
if _frontend_dir and Path(_frontend_dir).exists():
    from fastapi.staticfiles import StaticFiles
    app.mount("/", StaticFiles(directory=_frontend_dir, html=True), name="frontend")
