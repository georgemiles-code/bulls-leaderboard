"""Start the v2 API server. Run with: python3 api/run.py"""
import os
from pathlib import Path
import uvicorn

# Load .env from repo root so ANTHROPIC_API_KEY is available
env_file = Path(__file__).parent.parent.parent / ".env"
if env_file.exists():
    for line in env_file.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip())

if __name__ == "__main__":
    uvicorn.run("main:app", host="127.0.0.1", port=8093, reload=True, app_dir=str(__file__).rsplit("/", 1)[0])
