"""Gym attendance — 4-state (present/remote/excused/missed) per session day."""
import json
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

router = APIRouter(prefix="/attendance", tags=["attendance"])

NZT = timezone(timedelta(hours=12))

DATA_DIR      = Path(__file__).parent.parent.parent.parent / "data"
STORE_PATH    = DATA_DIR / "gym_attendance.json"
EXCLUDED_PATH = DATA_DIR / "excluded_athletes.json"
_lock         = threading.Lock()

VALID_STATUSES = {"present", "remote", "excused", "missed"}


def _load() -> dict:
    """Load store, migrating old list format → dict format on the fly."""
    try:
        raw = json.loads(STORE_PATH.read_text())
    except Exception:
        return {}
    for date, val in raw.items():
        if isinstance(val, list):
            raw[date] = {name: "present" for name in val}
    return raw


def _save(data: dict):
    STORE_PATH.write_text(json.dumps(data, indent=2))


def _week_dates(date_str: Optional[str] = None) -> list:
    base = datetime.strptime(date_str, "%Y-%m-%d") if date_str else datetime.now(NZT).replace(tzinfo=None)
    monday = base - timedelta(days=base.weekday())
    return [(monday + timedelta(days=i)).strftime("%Y-%m-%d") for i in range(5)]


def _load_excluded() -> list:
    try:
        return json.loads(EXCLUDED_PATH.read_text())
    except Exception:
        return []


# ── Week view ──────────────────────────────────────────────────────────────────

@router.get("/week")
def get_week(date: Optional[str] = None):
    """Return per-day status dicts for the current week."""
    dates = _week_dates(date)
    with _lock:
        store = _load()
    return {
        "dates": dates,
        "attendance": {d: store.get(d, {}) for d in dates},
    }


# ── Mark endpoint ──────────────────────────────────────────────────────────────

class MarkBody(BaseModel):
    athlete_name: str
    date: str
    status: Optional[str]  # present | remote | excused | missed | null to clear


@router.post("/mark")
def mark(body: MarkBody):
    if body.status is not None and body.status not in VALID_STATUSES:
        raise HTTPException(422, f"Invalid status '{body.status}'")
    with _lock:
        store = _load()
        day = store.setdefault(body.date, {})
        if body.status is None:
            day.pop(body.athlete_name, None)
        else:
            day[body.athlete_name] = body.status
        _save(store)
    return {"date": body.date, "athlete_name": body.athlete_name, "status": body.status}


# ── All-time attendance stats ──────────────────────────────────────────────────

@router.get("/stats")
def attendance_stats(squad: str = "academy"):
    """All-time per-athlete counts and attendance % (excused not in denominator)."""
    athletes_path = DATA_DIR / "athletes.json"
    try:
        athletes_all = json.loads(athletes_path.read_text())
    except Exception:
        athletes_all = []

    excluded = set(_load_excluded())
    squad_names = [
        a["name"] for a in athletes_all
        if a.get("squad") == squad and a["name"] not in excluded
    ]

    with _lock:
        store = _load()

    # Build per-athlete totals across all recorded dates
    counts: dict[str, dict] = {
        name: {"present": 0, "remote": 0, "excused": 0, "missed": 0}
        for name in squad_names
    }

    for date, day_data in store.items():
        if not isinstance(day_data, dict):
            continue
        for name, status in day_data.items():
            if name in counts and status in VALID_STATUSES:
                counts[name][status] += 1

    result = {}
    for name in squad_names:
        c = counts[name]
        attended      = c["present"] + c["remote"]
        denominator   = attended + c["missed"]   # excused excluded from denom
        pct = round(attended / denominator * 100) if denominator > 0 else None
        result[name] = {
            "present":        c["present"],
            "remote":         c["remote"],
            "excused":        c["excused"],
            "missed":         c["missed"],
            "attended":       attended,
            "total_counted":  denominator,
            "attendance_pct": pct,
            "flagged":        pct is not None and pct < 70,
        }

    return {"stats": result, "threshold_pct": 70}


# ── Athlete wellness history ───────────────────────────────────────────────────

@router.get("/wellness/{athlete_name}")
def athlete_wellness(athlete_name: str, limit: int = 12):
    """Last N wellness submissions for one athlete."""
    wellness_path = DATA_DIR / "wellness.json"
    wellness_all: dict = (
        json.loads(wellness_path.read_text()) if wellness_path.exists() else {}
    )
    records = wellness_all.get(athlete_name, [])
    recent = sorted(records, key=lambda r: r.get("date", ""), reverse=True)[:limit]
    return {"athlete": athlete_name, "records": recent}


# ── Excluded athletes ──────────────────────────────────────────────────────────

@router.get("/excluded")
def get_excluded():
    return {"excluded": _load_excluded()}


class ExcludedBody(BaseModel):
    excluded: list


@router.post("/excluded")
def set_excluded(body: ExcludedBody):
    EXCLUDED_PATH.write_text(json.dumps(body.excluded, indent=2))
    return {"excluded": body.excluded}


# ── CSV report (legacy) ────────────────────────────────────────────────────────

@router.get("/report/csv")
def weekly_report_csv(squad: str = "academy", date: Optional[str] = None):
    athletes_path = DATA_DIR / "athletes.json"
    wellness_path = DATA_DIR / "wellness.json"

    try:
        athletes_all = json.loads(athletes_path.read_text())
    except Exception:
        athletes_all = []

    excluded = set(_load_excluded())
    squad_athletes = [
        a for a in athletes_all
        if a.get("squad") == squad and a["name"] not in excluded
    ]

    wellness_all: dict = (
        json.loads(wellness_path.read_text()) if wellness_path.exists() else {}
    )

    dates = _week_dates(date)
    week_start, week_end = dates[0], dates[-1]

    with _lock:
        store = _load()

    day_labels = [
        datetime.strptime(d, "%Y-%m-%d").strftime("%a %d %b") for d in dates
    ]

    rows = [
        ["Name", "Position", "Status",
         "Wellness Composite", "Worst Flag", "Submitted This Week",
         *[f"Gym {l}" for l in day_labels], "Gym Days Total"],
    ]

    flag_rank = {"red": 3, "amber": 2, "green": 1, "neutral": 0}
    for a in sorted(squad_athletes, key=lambda x: x.get("name", "")):
        name = a["name"]
        w_records = wellness_all.get(name, [])
        this_week = [r for r in w_records if week_start <= r.get("date", "") <= week_end]
        composite, worst_flag, submitted = "", "", "No"
        if this_week:
            submitted = "Yes"
            latest = max(this_week, key=lambda r: r["date"])
            composite = str(latest.get("composite", ""))
            flags = latest.get("flags", {})
            if flags:
                worst_flag = max(flags.values(), key=lambda f: flag_rank.get(f, 0))

        gym_statuses = []
        for d in dates:
            day_data = store.get(d, {})
            status = day_data.get(name, "")
            gym_statuses.append(status)
        gym_attended = sum(1 for s in gym_statuses if s in ("present", "remote"))

        rows.append([
            name, a.get("position", ""), a.get("status", "Full Contact"),
            composite, worst_flag, submitted,
            *gym_statuses, str(gym_attended),
        ])

    csv_lines = [",".join(f'"{c}"' for c in r) for r in rows]
    csv_text  = f"Taranaki Bulls — Weekly Summary ({week_start} to {week_end})\n\n"
    csv_text += "\n".join(csv_lines)

    return Response(
        content=csv_text,
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="bulls_weekly_{week_start}.csv"'},
    )


ACADEMY_ATT_PATH = DATA_DIR / "academy_attendance.json"


@router.get("/report-data")
def report_data(squad: str = "academy"):
    """Weekly staff report data: this-week gym attendance, 3-week avg, last 2 wellness entries."""
    athletes_path = DATA_DIR / "athletes.json"
    athletes_all = json.loads(athletes_path.read_text()) if athletes_path.exists() else []
    excluded = set(_load_excluded())
    squad_names = [a["name"] for a in athletes_all if a.get("squad") == squad and a["name"] not in excluded]

    wellness_path = DATA_DIR / "wellness.json"
    wellness_all: dict = json.loads(wellness_path.read_text()) if wellness_path.exists() else {}

    with _lock:
        store = _load()

    now = datetime.now(NZT).replace(tzinfo=None)
    monday = now - timedelta(days=now.weekday())

    # Mon=0, Tue=1, Thu=3 in Python weekday
    GYM_DAYS = {0, 1, 3}

    # This week's gym dates (Mon/Tue/Thu)
    this_week_gym_dates = [
        (monday + timedelta(days=i)).strftime("%Y-%m-%d")
        for i in range(5) if i in GYM_DAYS
    ]

    # Last 3 weeks of gym dates (Mon/Tue/Thu), up to and including today
    today_str = now.strftime("%Y-%m-%d")
    three_week_dates: list[str] = []
    for w in range(3):
        wk_mon = monday - timedelta(weeks=w)
        for i in range(5):
            if i in GYM_DAYS:
                d = (wk_mon + timedelta(days=i)).strftime("%Y-%m-%d")
                if d <= today_str:
                    three_week_dates.append(d)

    def _worst(flags: dict) -> str:
        rank = {"red": 3, "amber": 2, "green": 1, "neutral": 0}
        best = "none"
        best_rank = -1
        for f in flags.values():
            if rank.get(f, -1) > best_rank:
                best_rank = rank[f]
                best = f
        return best

    athletes_out = {}
    for name in squad_names:
        # This week per-day status for gym days
        week_att = {d: store.get(d, {}).get(name) for d in this_week_gym_dates}

        # 3-week avg (excused excluded from denominator)
        attended = 0
        counted = 0
        for d in three_week_dates:
            s = store.get(d, {}).get(name)
            if s in ("present", "remote"):
                attended += 1
                counted += 1
            elif s == "missed":
                counted += 1
        three_week_avg = round(attended / counted * 100) if counted > 0 else None

        # Last 2 wellness submissions
        w_records = sorted(wellness_all.get(name, []), key=lambda r: r.get("date", ""), reverse=True)
        last_two = [
            {
                "date": r.get("date"),
                "composite": r.get("composite"),
                "flags": r.get("flags", {}),
                "responses": r.get("responses", {}),
                "notes": r.get("notes"),
                "worst_flag": _worst(r.get("flags", {})),
            }
            for r in w_records[:2]
        ]

        athletes_out[name] = {
            "week_attendance": week_att,
            "three_week_avg": three_week_avg,
            "wellness_last_two": last_two,
        }

    return {
        "this_week_gym_dates": this_week_gym_dates,
        "athletes": athletes_out,
    }


@router.get("/academy-block")
def academy_block_attendance(group: Optional[str] = None, from_date: Optional[str] = None, to_date: Optional[str] = None):
    """Block 1 2026 attendance from the Academy Excel sheet. Pass from_date/to_date to filter by date range."""
    if not ACADEMY_ATT_PATH.exists():
        raise HTTPException(404, "Academy attendance data not found")
    raw = json.loads(ACADEMY_ATT_PATH.read_text())

    # Filter sessions to date range if provided
    all_sessions = raw["sessions"]
    if from_date or to_date:
        season_dates = {
            s["date"] for s in all_sessions
            if (not from_date or s["date"] >= from_date)
            and (not to_date or s["date"] <= to_date)
        }
        date_range = {
            "start": from_date or raw["date_range"]["start"],
            "end": to_date or raw["date_range"]["end"],
        }
        total_sessions = len(season_dates)
    else:
        season_dates = None
        date_range = raw["date_range"]
        total_sessions = raw["total_sessions"]

    players = raw["players"]
    if group:
        players = [p for p in players if group.lower() in p["group"].lower()]

    # Recompute per-player summary if date-filtered
    if season_dates is not None:
        filtered_players = []
        for p in players:
            att = p["attendance"]
            season_att = {d: v for d, v in att.items() if d in season_dates}
            present = sum(1 for v in season_att.values() if v == "Y")
            excused = sum(1 for v in season_att.values() if v == "E")
            missed  = sum(1 for v in season_att.values() if v == "M")
            denom   = present + excused + missed
            att_pct = round(present / denom * 100, 1) if denom > 0 else None
            filtered_players.append({
                **p,
                "summary": {
                    "present": present,
                    "excused": excused,
                    "missed": missed,
                    "total_sessions": total_sessions,
                    "attendance_pct": att_pct,
                    "compliance_pct": att_pct,
                },
            })
        players = filtered_players

    totals = [p["summary"]["attendance_pct"] for p in players if p["summary"]["attendance_pct"] is not None]
    squad_avg = round(sum(totals) / len(totals), 1) if totals else None

    green  = sum(1 for t in totals if t >= 80)
    amber  = sum(1 for t in totals if 60 <= t < 80)
    red    = sum(1 for t in totals if t < 60)

    groups = sorted({p["group"] for p in raw["players"]})

    return {
        "block": raw["block"],
        "year": raw["year"],
        "date_range": date_range,
        "total_sessions": total_sessions,
        "groups": groups,
        "squad_avg_pct": squad_avg,
        "distribution": {"green_80plus": green, "amber_60_79": amber, "red_under_60": red},
        "players": sorted(players, key=lambda p: p["summary"]["attendance_pct"] or 0),
    }
