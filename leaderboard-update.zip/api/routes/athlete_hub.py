"""Athlete Hub API — combined CMJ + GPS + Strength view for a single athlete."""
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException

DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"
router = APIRouter(prefix="/hub", tags=["hub"])

NZT = timezone(timedelta(hours=12))


def _load_athletes():
    p = DATA_DIR / "athletes.json"
    try:
        return json.loads(p.read_text())
    except Exception:
        return []


def _load_strength():
    p = DATA_DIR / "strength.json"
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}


def _load_gps():
    p = DATA_DIR / "gps.json"
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}


def _parse_date(s: str) -> Optional[datetime]:
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except (ValueError, TypeError):
            pass
    return None


def _norm(name: str) -> str:
    return (name or "").lower().replace(" ", "").replace("-", "").replace("'", "")


def _strength_for_athlete(athlete: dict, strength_data: dict) -> list:
    name = athlete.get("name", "")
    if name in strength_data:
        return strength_data[name]
    norm = _norm(name)
    for key, sessions in strength_data.items():
        if _norm(key) == norm:
            return sessions
    return []


def _gps_for_athlete(athlete: dict, gps_data: dict) -> list:
    name = athlete.get("name", "")
    if name in gps_data:
        return gps_data[name]
    norm = _norm(name)
    for key, sessions in gps_data.items():
        if _norm(key) == norm:
            return sessions
    return []


def _acwr(sessions: list, reference_date: Optional[datetime] = None) -> dict:
    ref = reference_date or datetime.now(NZT).replace(tzinfo=None)
    dated = [(s, _parse_date(s.get("date", ""))) for s in sessions]
    dated = [(s, d) for s, d in dated if d]
    if not dated:
        return {"acwr": None, "acute_avg": None, "chronic_avg": None, "sessions_7d": 0}
    acute  = [s for s, d in dated if (ref - d).days <= 7]
    chronic = [s for s, d in dated if (ref - d).days <= 28]
    acute_dist  = sum(s.get("total_dist", 0) or 0 for s in acute)
    chronic_dist = sum(s.get("total_dist", 0) or 0 for s in chronic)
    acute_avg  = acute_dist / 7
    chronic_avg = chronic_dist / 28
    acwr = round(acute_avg / chronic_avg, 2) if chronic_avg > 0 else None
    return {
        "acwr": acwr,
        "acute_avg": round(acute_avg),
        "chronic_avg": round(chronic_avg),
        "sessions_7d": len(acute),
    }


def _acwr_zone(acwr: Optional[float]) -> str:
    if acwr is None: return "no_data"
    if acwr < 0.8:   return "under"
    if acwr <= 1.3:  return "optimal"
    if acwr <= 1.5:  return "elevated"
    return "danger"


def _acwr_history(sessions: list, days: int = 42) -> list[dict]:
    today = datetime.now(NZT).replace(tzinfo=None, hour=0, minute=0, second=0, microsecond=0)
    result = []
    for i in range(days, -1, -1):
        ref = today - timedelta(days=i)
        a = _acwr(sessions, reference_date=ref)
        if a["acwr"] is not None or a["sessions_7d"] > 0:
            result.append({
                "date": ref.strftime("%Y-%m-%d"),
                "acwr": a["acwr"],
                "zone": _acwr_zone(a["acwr"]),
            })
    return result


PRIMARY_LIFTS = ["BackSquat_kg", "TrapBar_kg", "BenchPress_kg", "RDL_kg", "ChinUp_kg"]
LIFT_LABELS = {
    "BackSquat_kg": "Back Squat", "TrapBar_kg": "Trap Bar DL",
    "BenchPress_kg": "Bench Press", "RDL_kg": "RDL", "ChinUp_kg": "Chin-up",
}


def _strength_prs(sessions: list) -> dict:
    prs: dict[str, dict] = {}
    for s in sessions:
        d = _parse_date(s.get("date", ""))
        if not d:
            continue
        for lift, v in s.items():
            if lift == "date" or not isinstance(v, (int, float)):
                continue
            if lift not in prs or v > prs[lift]["value"]:
                prs[lift] = {"value": v, "date": d.strftime("%Y-%m-%d")}
    return prs


@router.get("/athlete/{athlete_id}")
def athlete_hub(athlete_id: int):
    athletes = _load_athletes()
    strength_data = _load_strength()
    gps_data = _load_gps()

    a = next((x for x in athletes if x["id"] == athlete_id), None)
    if not a:
        raise HTTPException(404, f"Athlete {athlete_id} not found")

    # ── CMJ history ────────────────────────────────────────────────────────
    history = a.get("history", [])
    dated_cmj = [(h, _parse_date(h.get("date", ""))) for h in history]
    dated_cmj = [(h, d) for h, d in dated_cmj if d]
    dated_cmj.sort(key=lambda x: x[1])

    cmj_trend = [
        {
            "date":                  d.strftime("%Y-%m-%d"),
            "jh":                    h.get("jh"),
            "rsi":                   h.get("rsi"),
            "power_wkg":             h.get("power_wkg") or h.get("concentric_mean_power_w_kg"),
            "contraction_ms":        h.get("contraction_time_ms"),
        }
        for h, d in dated_cmj
    ]

    pb = a.get("pb")
    pb_date = _parse_date(a.get("pbDate", ""))

    # 7-day rolling average (relative to most recent test)
    avg_7d = None
    if dated_cmj:
        last_dt = dated_cmj[-1][1]
        window_start = last_dt - timedelta(days=7)
        window = [h.get("jh") for h, d in dated_cmj if window_start <= d <= last_dt and h.get("jh")]
        avg_7d = round(sum(window) / len(window), 1) if window else None

    latest_cmj = dated_cmj[-1][0] if dated_cmj else None
    latest_jh = latest_cmj.get("jh") if latest_cmj else None
    days_since_cmj = (datetime.now(NZT).replace(tzinfo=None) - dated_cmj[-1][1]).days if dated_cmj else None

    delta_pct = None
    if latest_jh and avg_7d and avg_7d > 0 and len(dated_cmj) > 1:
        delta_pct = round((latest_jh - avg_7d) / avg_7d * 100, 1)

    # ── GPS ────────────────────────────────────────────────────────────────
    gps_sessions = _gps_for_athlete(a, gps_data)
    gps_dated = [(s, _parse_date(s.get("date", ""))) for s in gps_sessions]
    gps_dated = [(s, d) for s, d in gps_dated if d]
    gps_dated.sort(key=lambda x: x[1], reverse=True)

    last_gps_dt = gps_dated[0][1] if gps_dated else None
    load = _acwr(gps_sessions, reference_date=last_gps_dt)
    acwr_history = _acwr_history(gps_sessions, days=42)

    recent_gps = [
        {
            "date":       d.strftime("%Y-%m-%d"),
            "total_dist": s.get("total_dist"),
            "hsr":        s.get("hsr"),
            "session_type": (s.get("session_type") or "training").lower(),
        }
        for s, d in gps_dated[:8]
    ]

    # ── Strength ───────────────────────────────────────────────────────────
    str_sessions = _strength_for_athlete(a, strength_data)
    all_prs = _strength_prs(str_sessions)
    primary_prs = {
        lift: {
            "label": LIFT_LABELS.get(lift, lift),
            "value": all_prs[lift]["value"],
            "date":  all_prs[lift]["date"],
        }
        for lift in PRIMARY_LIFTS if lift in all_prs
    }

    return {
        "id":             a["id"],
        "name":           a["name"],
        "initials":       a.get("initials", a["name"][:2].upper()),
        "position":       a.get("position", ""),
        "position_group": a.get("positionGroup", ""),
        "status":         a.get("status", "Full Contact"),
        "photo":          a.get("photo"),
        # CMJ
        "cmj": {
            "trend":      cmj_trend,
            "pb":         pb,
            "pb_date":    pb_date.strftime("%Y-%m-%d") if pb_date else None,
            "avg_7d":     avg_7d,
            "latest_jh":  round(float(latest_jh), 1) if latest_jh else None,
            "delta_pct":  delta_pct,
            "days_since": days_since_cmj,
            "total_tests": len(dated_cmj),
        },
        # GPS
        "gps": {
            "acwr":         load["acwr"],
            "acwr_zone":    _acwr_zone(load["acwr"]),
            "acute_avg":    load["acute_avg"],
            "chronic_avg":  load["chronic_avg"],
            "sessions_7d":  load["sessions_7d"],
            "total_sessions": len(gps_sessions),
            "acwr_history": acwr_history,
            "recent":       recent_gps,
        },
        # Strength
        "strength": {
            "prs":           primary_prs,
            "total_sessions": len(str_sessions),
        },
    }
