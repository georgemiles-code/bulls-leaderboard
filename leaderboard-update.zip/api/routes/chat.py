"""Chat API — data queries + layout editing via Claude tool_use."""
import json
import os
from datetime import date
from pathlib import Path
from typing import Any, Optional

import anthropic
import jsonpatch
from fastapi import APIRouter, HTTPException
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

router = APIRouter(prefix="/chat", tags=["chat"])

_client: Optional[anthropic.Anthropic] = None

def _get_client() -> anthropic.Anthropic:
    global _client
    if _client is None:
        key = os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            raise HTTPException(500, "ANTHROPIC_API_KEY not set")
        _client = anthropic.Anthropic(api_key=key)
    return _client


SYSTEM_PROMPT_PATH = Path(__file__).parent.parent / "claude" / "system_prompt.md"

def _load_system_prompt() -> str:
    try:
        return SYSTEM_PROMPT_PATH.read_text()
    except Exception:
        return "You are a sports performance assistant for the Taranaki Bulls."


# ── Data access helpers ────────────────────────────────────────────────────────

DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"

def _load_athletes():
    try:
        return json.loads((DATA_DIR / "athletes.json").read_text())
    except Exception:
        return []

def _load_force_results():
    try:
        return json.loads((DATA_DIR / "force_results.json").read_text())
    except Exception:
        return {}

def _load_ignored() -> set:
    try:
        d = json.loads((DATA_DIR / "ignored_vald_tests.json").read_text())
        return {i if isinstance(i, str) else i.get("test_id", "") for i in d.get("test_ids", [])}
    except Exception:
        return set()


# ── Tool definitions ───────────────────────────────────────────────────────────

TOOLS = [
    {
        "name": "get_leaderboard",
        "description": "Get the CMJ jump height leaderboard for a session date. Returns athletes ranked by jump height with PB flags.",
        "input_schema": {
            "type": "object",
            "properties": {
                "squad": {"type": "string", "enum": ["male", "whio"], "description": "male = Academy & WTG combined, whio = women's squad"},
                "date":  {"type": "string", "description": "YYYY-MM-DD session date. Omit for the most recent session with data."},
            },
            "required": ["squad"],
        },
    },
    {
        "name": "get_all_time",
        "description": "Get all-time CMJ personal bests for a squad, ranked highest to lowest.",
        "input_schema": {
            "type": "object",
            "properties": {
                "squad": {"type": "string", "enum": ["male", "whio"]},
                "limit": {"type": "integer", "description": "Number of records to return (default 10, max 50)", "default": 10},
            },
            "required": ["squad"],
        },
    },
    {
        "name": "get_athletes",
        "description": "Search or list athletes with their squad, position, and CMJ personal best.",
        "input_schema": {
            "type": "object",
            "properties": {
                "squad":  {"type": "string", "description": "Filter by squad: academy, wtg, whio, npc. Omit for all."},
                "search": {"type": "string", "description": "Partial name search (case-insensitive)."},
            },
        },
    },
    {
        "name": "get_athlete_history",
        "description": "Get full CMJ test history for a specific athlete — every recorded jump, date, and score.",
        "input_schema": {
            "type": "object",
            "properties": {
                "name": {"type": "string", "description": "Athlete name (partial match OK)."},
            },
            "required": ["name"],
        },
    },
    {
        "name": "applyPatch",
        "description": "Apply JSON Patch operations (RFC 6902) to modify the active dashboard layout.",
        "input_schema": {
            "type": "object",
            "properties": {
                "ops": {
                    "type": "array",
                    "description": "RFC 6902 JSON Patch operations.",
                    "items": {
                        "type": "object",
                        "properties": {
                            "op":    {"type": "string", "enum": ["add", "remove", "replace", "move", "copy", "test"]},
                            "path":  {"type": "string"},
                            "value": {},
                            "from":  {"type": "string"},
                        },
                        "required": ["op", "path"],
                    },
                },
                "summary": {"type": "string", "description": "One sentence past-tense description. Shown in undo toast."},
            },
            "required": ["ops", "summary"],
        },
    },
    {
        "name": "noChange",
        "description": "Use when the layout request cannot be fulfilled, or when clarification is needed.",
        "input_schema": {
            "type": "object",
            "properties": {
                "reason":             {"type": "string"},
                "suggestions":        {"type": "array", "items": {"type": "string"}},
                "clarifyingQuestion": {"type": "string"},
            },
            "required": ["reason"],
        },
    },
]


# ── Tool execution ─────────────────────────────────────────────────────────────

def _execute_tool(name: str, inputs: dict, default_squad: str) -> str:
    if name == "get_leaderboard":
        squad = inputs.get("squad", default_squad)
        target_date = inputs.get("date")

        # Determine squad athlete IDs
        if squad == "male":
            allowed_squads = {"academy", "npc", "wtg"}
        else:
            allowed_squads = {squad}

        athletes = {str(a["id"]): a for a in _load_athletes() if a.get("squad") in allowed_squads}
        force = _load_force_results()
        ignored = _load_ignored()

        # If no date given, find most recent date with data
        if not target_date:
            dates = set()
            for aid, records in force.items():
                if aid not in athletes:
                    continue
                for r in records:
                    if r.get("test_type") == "cmj" and r.get("test_id") not in ignored and r.get("date"):
                        dates.add(r["date"])
            target_date = max(dates) if dates else date.today().isoformat()

        best: dict[str, dict] = {}
        for aid, records in force.items():
            if aid not in athletes:
                continue
            for r in records:
                if r.get("test_type") != "cmj" or r.get("date") != target_date or r.get("test_id") in ignored:
                    continue
                jh = r.get("metrics", {}).get("jump_height_cm")
                if not jh:
                    continue
                prev = best.get(aid)
                if not prev or float(jh) > float(prev["metrics"].get("jump_height_cm", 0)):
                    best[aid] = r

        entries = []
        for aid, r in best.items():
            athlete = athletes[aid]
            jh = float(r["metrics"]["jump_height_cm"])
            pb = float(athlete.get("pb") or 0)
            entries.append({
                "rank": 0, "name": athlete["name"], "squad": athlete.get("squad", ""),
                "jump_height": round(jh, 1), "pb": round(pb, 1) if pb else None,
                "is_pb": jh >= pb - 0.05 if pb else False,
            })

        entries.sort(key=lambda e: e["jump_height"], reverse=True)
        for i, e in enumerate(entries):
            e["rank"] = i + 1

        avg = round(sum(e["jump_height"] for e in entries) / len(entries), 1) if entries else 0
        return json.dumps({"date": target_date, "squad": squad, "entries": entries, "count": len(entries), "average": avg})

    elif name == "get_all_time":
        squad = inputs.get("squad", default_squad)
        limit = min(int(inputs.get("limit", 10)), 50)

        if squad == "male":
            allowed_squads = {"academy", "npc", "wtg"}
        else:
            allowed_squads = {squad}

        athletes = {str(a["id"]): a for a in _load_athletes() if a.get("squad") in allowed_squads}
        force = _load_force_results()
        ignored = _load_ignored()

        best: dict[str, dict] = {}
        for aid, records in force.items():
            if aid not in athletes:
                continue
            for r in records:
                if r.get("test_type") != "cmj" or r.get("test_id") in ignored:
                    continue
                jh = r.get("metrics", {}).get("jump_height_cm")
                if not jh:
                    continue
                prev = best.get(aid)
                if not prev or float(jh) > float(prev["metrics"].get("jump_height_cm", 0)):
                    best[aid] = r

        entries = []
        for aid, r in best.items():
            athlete = athletes[aid]
            entries.append({
                "name": athlete["name"], "squad": athlete.get("squad", ""),
                "jump_height": round(float(r["metrics"]["jump_height_cm"]), 1),
                "date": r.get("date", ""),
            })

        entries.sort(key=lambda e: e["jump_height"], reverse=True)
        for i, e in enumerate(entries):
            e["rank"] = i + 1

        return json.dumps({"squad": squad, "entries": entries[:limit], "total_athletes": len(entries)})

    elif name == "get_athletes":
        squad_filter = inputs.get("squad", "").lower()
        search = inputs.get("search", "").lower()
        all_athletes = _load_athletes()

        results = []
        for a in all_athletes:
            if squad_filter and a.get("squad", "") != squad_filter:
                continue
            if search and search not in a.get("name", "").lower():
                continue
            results.append({
                "id": a["id"], "name": a["name"],
                "squad": a.get("squad", ""), "position": a.get("position", ""),
                "pb_cmj": a.get("pb"),
            })

        return json.dumps({"athletes": results, "count": len(results)})

    elif name == "get_athlete_history":
        search = inputs.get("name", "").lower()
        all_athletes = _load_athletes()
        force = _load_force_results()
        ignored = _load_ignored()

        matches = [a for a in all_athletes if search in a.get("name", "").lower()]
        if not matches:
            return json.dumps({"error": f"No athlete found matching '{inputs.get('name')}'."})
        if len(matches) > 1:
            return json.dumps({"error": f"Multiple matches: {[a['name'] for a in matches]}. Be more specific."})

        athlete = matches[0]
        records = force.get(str(athlete["id"]), [])
        history = []
        for r in records:
            if r.get("test_type") != "cmj" or r.get("test_id") in ignored:
                continue
            jh = r.get("metrics", {}).get("jump_height_cm")
            if jh:
                history.append({"date": r.get("date", ""), "jump_height": round(float(jh), 1)})

        history.sort(key=lambda h: h["date"])
        pb = max((h["jump_height"] for h in history), default=None)

        return json.dumps({
            "name": athlete["name"], "squad": athlete.get("squad", ""),
            "pb": pb, "test_count": len(history), "history": history,
        })

    return json.dumps({"error": f"Unknown tool: {name}"})


# ── Layout validation ──────────────────────────────────────────────────────────

PROTECTED_PATHS = {"/schemaVersion", "/id", "/meta/createdAt", "/route"}

def _validate_patch(layout: dict, ops: list) -> dict:
    for op in ops:
        path = op.get("path", "")
        if any(path == p or path.startswith(p + "/") for p in PROTECTED_PATHS):
            raise ValueError(f"Operation targets protected path: {path}")
    try:
        clone = json.loads(json.dumps(layout))
        patched = jsonpatch.JsonPatch(ops).apply(clone)
    except Exception as e:
        raise ValueError(f"Patch failed: {e}")
    if not isinstance(patched.get("schemaVersion"), int):
        raise ValueError("schemaVersion must be an integer")
    if "root" not in patched:
        raise ValueError("Layout must have a root node")
    return patched


# ── Catalog for layout editing ─────────────────────────────────────────────────

VALID_NODE_TYPES = {
    "grid", "card", "stat", "chart", "table",
    "kpi_strip", "last_session", "insights", "readiness_grid",
    "cmj_leaders", "squat_leaders", "player_card_grid", "filter_bar", "text",
}

def _build_catalog(squad: str = "academy") -> dict:
    try:
        athletes_raw = _load_athletes()
        athletes = [
            {"id": a["id"], "name": a["name"], "squad": a.get("squad", "")}
            for a in athletes_raw if a.get("squad") == squad
        ]
    except Exception:
        athletes = []

    return {
        "squad": squad,
        "node_types": sorted(VALID_NODE_TYPES),
        "span_values": ["full", "half", "third", "quarter", "or integer 1-12"],
        "endpoints": {
            "/force-lab/leaderboard": "CMJ session leaderboard",
            "/force-lab/all-time":    "All-time CMJ records",
            "/gps/squad":             "GPS load + ACWR per athlete",
            "/strength/squad":        "Strength PRs per athlete",
            "/hub/athlete/{id}":      "Full athlete hub",
        },
        "athletes": athletes[:30],
    }


# ── Request / response models ──────────────────────────────────────────────────

class ChatRequest(BaseModel):
    message: str
    layout: dict
    squad: str = "male"
    history: list[dict] = []


class ChatResponse(BaseModel):
    text: Optional[str] = None
    patch: Optional[list] = None
    summary: Optional[str] = None
    new_layout: Optional[dict] = None
    no_change: Optional[dict] = None
    tools_used: list[str] = []
    error: Optional[str] = None


# ── Endpoint ───────────────────────────────────────────────────────────────────

@router.post("", response_model=ChatResponse)
async def chat(req: ChatRequest):
    if len(json.dumps(req.layout)) > 64 * 1024:
        raise HTTPException(400, "Layout too large (> 64 KB)")

    catalog = _build_catalog(req.squad)
    client = _get_client()

    context_block = f"""<layout>
{json.dumps(req.layout, indent=2)}
</layout>

<catalog>
{json.dumps(catalog, indent=2)}
</catalog>

<today>{date.today().isoformat()}</today>"""

    messages: list[dict] = []
    for h in req.history[-8:]:
        if h.get("role") and h.get("content"):
            messages.append({"role": h["role"], "content": h["content"]})
    messages.append({"role": "user", "content": f"{context_block}\n\nUser: {req.message}"})

    tools_used: list[str] = []
    patch_result: Optional[dict] = None
    no_change_result: Optional[dict] = None
    final_text: Optional[str] = None
    max_rounds = 6

    for _ in range(max_rounds):
        try:
            response = client.messages.create(
                model="claude-opus-4-8",
                max_tokens=4096,
                system=_load_system_prompt(),
                tools=TOOLS,
                tool_choice={"type": "auto"},
                messages=messages,
            )
        except anthropic.APIError as e:
            raise HTTPException(502, f"Anthropic API error: {e}")

        if getattr(response, "stop_reason", None) == "refusal":
            return ChatResponse(no_change={"reason": "Request declined by model."})

        # Collect text and tool blocks
        text_parts: list[str] = []
        tool_calls: list[dict] = []

        for block in response.content:
            if hasattr(block, "type"):
                if block.type == "text":
                    text_parts.append(block.text)
                elif block.type == "tool_use":
                    tool_calls.append(block)

        if text_parts:
            final_text = " ".join(text_parts).strip()

        # No tool calls — we're done
        if not tool_calls:
            break

        # Process tool calls
        tool_results = []
        for tc in tool_calls:
            tools_used.append(tc.name)

            if tc.name == "applyPatch":
                ops = tc.input.get("ops", [])
                summary = tc.input.get("summary", "Layout updated.")
                try:
                    new_layout = _validate_patch(req.layout, ops)
                    if "meta" in new_layout:
                        new_layout["meta"]["version"] = req.layout.get("meta", {}).get("version", 0) + 1
                    patch_result = {"ops": ops, "summary": summary, "new_layout": new_layout}
                    tool_results.append({"type": "tool_result", "tool_use_id": tc.id, "content": "Patch applied successfully."})
                except ValueError as e:
                    tool_results.append({"type": "tool_result", "tool_use_id": tc.id, "content": f"Patch error: {e}", "is_error": True})

            elif tc.name == "noChange":
                no_change_result = tc.input
                tool_results.append({"type": "tool_result", "tool_use_id": tc.id, "content": "Acknowledged."})

            else:
                result = _execute_tool(tc.name, tc.input, req.squad)
                tool_results.append({"type": "tool_result", "tool_use_id": tc.id, "content": result})

        # If we hit a layout tool, no need to loop further
        if patch_result or no_change_result:
            break

        # Add round to messages and continue
        messages.append({"role": "assistant", "content": response.content})
        messages.append({"role": "user", "content": tool_results})

    return ChatResponse(
        text=final_text,
        patch=patch_result["ops"] if patch_result else None,
        summary=patch_result["summary"] if patch_result else None,
        new_layout=patch_result["new_layout"] if patch_result else None,
        no_change=no_change_result,
        tools_used=list(dict.fromkeys(tools_used)),
    )
