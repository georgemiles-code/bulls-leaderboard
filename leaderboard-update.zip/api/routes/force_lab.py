"""Force Lab API — CMJ leaderboard, all-time rankings, test rejection."""
import asyncio
import base64
import hashlib
import json
import re
import datetime as dt
from datetime import date
from pathlib import Path
from typing import Optional

import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

# ── Live session tunnel state ──────────────────────────────────────────────────
_live_proc: Optional[asyncio.subprocess.Process] = None
_live_tunnel_url: str = ""

# ── Auto-publish state ─────────────────────────────────────────────────────────
_last_published_hash: str = ""

import os as _os
_data_env = _os.environ.get("BULLS_DATA_DIR", "")
DATA_DIR = Path(_data_env) if _data_env else Path(__file__).parent.parent.parent.parent / "data"

router = APIRouter(prefix="/force-lab", tags=["force-lab"])


# ── Helpers ────────────────────────────────────────────────────────────────────

def _load_athletes():
    p = DATA_DIR / "athletes.json"
    try:
        return json.loads(p.read_text())
    except Exception:
        return []


def _load_force_results():
    p = DATA_DIR / "force_results.json"
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}


def _load_ignored() -> set:
    p = DATA_DIR / "ignored_vald_tests.json"
    try:
        d = json.loads(p.read_text())
        ids = set()
        for item in d.get("test_ids", []):
            if isinstance(item, str):
                ids.add(item)
            elif isinstance(item, dict) and item.get("test_id"):
                ids.add(item["test_id"])
        return ids
    except Exception:
        return set()


def _save_ignored(ignored: set):
    p = DATA_DIR / "ignored_vald_tests.json"
    tmp = p.with_suffix(".json.tmp")
    tmp.write_text(json.dumps({"test_ids": sorted(ignored)}, indent=2))
    tmp.replace(p)


def _cinematics_ok(test_type: str) -> bool:
    """False for test types listed in leaderboard_config.json's suppress_cinematics —
    used while a test type is debuting and the handful of existing records aren't a
    real baseline, so early sessions don't throw false PB / ALL-TIME RECORD cinematics.
    """
    p = DATA_DIR / "leaderboard_config.json"
    try:
        cfg = json.loads(p.read_text())
        return test_type not in set(cfg.get("suppress_cinematics", []))
    except Exception:
        return True


def _squad_athlete_ids(squad: str) -> dict[str, dict]:
    """Return {str_id: athlete} for a given squad.
    'male' is a combined alias for academy + npc + wtg.
    An athlete also matches if `squad` appears in their `extra_squads` list,
    so e.g. a wtg player can additionally be selected under the npc squad
    without losing their primary squad membership elsewhere.
    """
    if squad == "male":
        allowed = {"academy", "npc", "wtg"}
    else:
        allowed = {squad}
    result = {}
    for a in _load_athletes():
        extra = set(a.get("extra_squads") or [])
        if a.get("squad") in allowed or extra & allowed:
            result[str(a["id"])] = a
    return result


# ── Endpoints ──────────────────────────────────────────────────────────────────

VALID_TEST_TYPES = {"cmj", "drop_jump", "squat_jump", "ppu", "slj"}


def _compute_primary(test_type: str, metrics: dict) -> float:
    """Primary ranking metric for each test type."""
    if test_type == "drop_jump":
        return float(metrics.get("rsi_jh_ct") or 0) / 100
    if test_type == "ppu":
        # VALD's own "Push Up Height (Flight Time)" — already computed and in cm.
        # Older synced records from before this metric was captured won't have
        # it; fall back to deriving it from flight time for those only.
        pushup_height = metrics.get("pushup_height_cm")
        if pushup_height:
            return float(pushup_height)
        ft = float(metrics.get("flight_time_ms") or 0)
        t = ft / 1000
        return 9.81 * (t / 2) ** 2 / 2 * 100  # push height cm from flight time (fallback)
    return float(metrics.get("jump_height_cm") or 0)


@router.get("/roster")
def force_lab_roster(squad: str = "academy"):
    """Full squad roster regardless of test history — used by the TV app's test-data
    preview mode so it can size the UI (podium/pagination) against everyone who would
    actually show up on a real session day, not just people who've already tested.
    """
    squad_ids = _squad_athlete_ids(squad)
    entries = [
        {
            "id": int(aid),
            "name": a["name"],
            "initials": a.get("initials", a["name"][:2].upper()),
            "position_group": a.get("positionGroup", ""),
        }
        for aid, a in squad_ids.items()
    ]
    entries.sort(key=lambda e: e["name"])
    return {"squad": squad, "entries": entries, "count": len(entries)}


@router.get("/dates")
def force_lab_dates(squad: str = "academy", test_type: str = "cmj"):
    if test_type not in VALID_TEST_TYPES:
        test_type = "cmj"
    squad_ids = _squad_athlete_ids(squad)
    force = _load_force_results()
    ignored = _load_ignored()
    today_str = date.today().isoformat()

    dates: set[str] = set()
    for aid, records in force.items():
        if aid not in squad_ids:
            continue
        for r in records:
            if r.get("test_type") == test_type and r.get("test_id") not in ignored:
                d = r.get("date", "")
                if d:
                    dates.add(d)

    sorted_dates = sorted(dates, reverse=True)
    return {
        "today": today_str,
        "dates": sorted_dates,
    }


@router.get("/leaderboard")
def force_lab_leaderboard(target_date: str, squad: str = "academy", test_type: str = "cmj"):
    if test_type not in VALID_TEST_TYPES:
        test_type = "cmj"
    squad_ids = _squad_athlete_ids(squad)
    force = _load_force_results()
    ignored = _load_ignored()

    is_drop_jump = test_type == "drop_jump"

    def _rank_value(metrics: dict) -> float:
        return _compute_primary(test_type, metrics)

    # Best test per athlete on this date + all attempts (for spotlight)
    best_by_athlete: dict[str, dict] = {}
    all_by_athlete: dict[str, list] = {}
    for aid, records in force.items():
        if aid not in squad_ids:
            continue
        for r in records:
            if r.get("test_type") != test_type:
                continue
            if r.get("date") != target_date:
                continue
            if r.get("test_id") in ignored:
                continue
            val = _rank_value(r.get("metrics", {}))
            if not val:
                continue
            all_by_athlete.setdefault(aid, []).append(r)
            prev = best_by_athlete.get(aid)
            if not prev or val > _rank_value(prev.get("metrics", {})):
                best_by_athlete[aid] = r

    # PB for every test type: best of an athlete's non-ignored attempts from any PRIOR
    # date — the whole of today is excluded, not just the specific test being shown. A
    # session is normally several jumps, each better than the athlete's own earlier reps
    # that same day as they warm up/groove the movement; comparing against those made
    # nearly every improving rep during a session flag as a "PB", which in a real session
    # meant a flood of PB cinematics for ordinary within-session improvement. A PB now has
    # to actually beat a genuinely earlier session, not just an earlier attempt today. This
    # replaced a per-test-type split where cmj alone trusted a stored athletes.json `pb`
    # field that sync updates to match a brand-new athlete's very first test the moment it
    # lands — trivially flagging every debut result as a "PB". Scanning history fresh here
    # avoids that whole class of stale/wrong-on-day-one bug for every test type, not just cmj.
    def _historical_pb(aid: str) -> float:
        best_val = 0.0
        for r2 in force.get(aid, []):
            if r2.get("test_type") != test_type or r2.get("test_id") in ignored:
                continue
            if r2.get("date") == target_date:
                continue
            val = _compute_primary(test_type, r2.get("metrics", {}))
            if val > best_val:
                best_val = val
        return best_val

    # Build ranked entries
    entries = []
    for aid, r in best_by_athlete.items():
        athlete = squad_ids[aid]
        m = r.get("metrics", {})
        jh = float(m.get("jump_height_cm") or 0)
        primary = _rank_value(m)

        pb = _historical_pb(aid)
        tol = 0.005 if is_drop_jump else 0.05
        dec = 3 if is_drop_jump else 1
        # pb > 0 guard: an athlete's first-ever test for this test type has nothing to
        # compare against, so pb defaults to 0 — without the guard the first attempt
        # would trivially satisfy `primary >= 0 - tol` and get flagged as a PB.
        is_pb = pb > 0 and primary >= pb - tol
        delta = round(primary - pb, dec) if pb else None

        # All attempts for this athlete today, chronological, for spotlight display
        day_attempts = sorted(all_by_athlete.get(aid, []), key=lambda x: x.get("recorded_utc", ""))
        dec_d = 3 if is_drop_jump else 1
        recent_jumps = [round(_rank_value(a.get("metrics", {})), dec_d) for a in day_attempts[-3:]]

        entries.append({
            "id": int(aid),
            "name": athlete["name"],
            "initials": athlete.get("initials", athlete["name"][:2].upper()),
            "position_group": athlete.get("positionGroup", ""),
            "position": athlete.get("position", ""),
            "status": athlete.get("status", "Full Contact"),
            "jump_height": round(jh, 2),
            "primary": round(primary, 3),
            "pb": round(pb, 3) if pb else None,
            "is_pb": is_pb,
            "delta_vs_pb": delta,
            "rsi_modified": m.get("rsi_modified"),
            "rsi": round(float(m.get("rsi_jh_ct") or 0) / 100, 3) if m.get("rsi_jh_ct") else None,
            "contact_time_ms": m.get("contact_time_ms"),
            "power_w_kg": m.get("concentric_mean_power_w_kg"),
            "contraction_ms": m.get("contraction_time_ms"),
            "test_id": r.get("test_id", ""),
            "recorded_utc": r.get("recorded_utc", ""),
            "recent_jumps": recent_jumps,
        })

    entries.sort(key=lambda e: e["primary"], reverse=True)
    for i, e in enumerate(entries):
        e["rank"] = i + 1

    return {
        "date": target_date,
        "squad": squad,
        "test_type": test_type,
        "entries": entries,
        "count": len(entries),
        "cinematics_ok": _cinematics_ok(test_type),
    }


@router.get("/all-time")
def force_lab_all_time(squad: str = "academy", limit: int = 5, test_type: str = "cmj"):
    if test_type not in VALID_TEST_TYPES:
        test_type = "cmj"
    squad_ids = _squad_athlete_ids(squad)
    force = _load_force_results()
    ignored = _load_ignored()
    is_drop_jump = test_type == "drop_jump"

    best_by_athlete: dict[str, dict] = {}
    for aid, records in force.items():
        if aid not in squad_ids:
            continue
        for r in records:
            if r.get("test_type") != test_type or r.get("test_id") in ignored:
                continue
            val = _compute_primary(test_type, r.get("metrics", {}))
            if not val:
                continue
            prev = best_by_athlete.get(aid)
            if not prev or val > _compute_primary(test_type, prev.get("metrics", {})):
                best_by_athlete[aid] = r

    entries = []
    for aid, r in best_by_athlete.items():
        athlete = squad_ids[aid]
        m = r.get("metrics", {})
        primary = round(_compute_primary(test_type, m), 3 if is_drop_jump else 2)
        entries.append({
            "id": int(aid),
            "name": athlete["name"],
            "initials": athlete.get("initials", athlete["name"][:2].upper()),
            "position_group": athlete.get("positionGroup", ""),
            "squad": athlete.get("squad", ""),
            "jump_height": round(float(m.get("jump_height_cm") or 0), 2),
            "primary": primary,
            "date": r.get("date", ""),
            "test_id": r.get("test_id", ""),
        })

    entries.sort(key=lambda e: e["primary"], reverse=True)
    for i, e in enumerate(entries):
        e["rank"] = i + 1

    return {"entries": entries[:limit], "total_athletes": len(entries), "test_type": test_type, "cinematics_ok": _cinematics_ok(test_type)}


# Test types with a real TV tab — squat_jump is in VALID_TEST_TYPES for raw VALD
# classification but has no leaderboard/cinematic of its own, so it's left out here.
SESSION_REPORT_TEST_TYPES = ["cmj", "drop_jump", "ppu", "slj"]


# Same threshold as App.tsx's allTimeReady — below this many athletes with real history
# for a test type, "all-time best" is just whoever happened to go first, so it's not a
# meaningful record yet. Keeping this in sync with the frontend is exactly the bug the
# user flagged: without it, the report handed out "all-time records" the live board and
# cinematics would have correctly refused to show.
MIN_ALLTIME_SAMPLE = 8


@router.get("/session-report")
def force_lab_session_report(target_date: str, squad: str = "academy"):
    """Everyone who got a PB or broke an all-time record on `target_date`, across every
    test type — a single end-of-session recap instead of having to check each test-type
    tab individually. Same PB/all-time rules as the live leaderboard and cinematics:
    a PB has to beat a genuinely earlier session (today's own other attempts don't count,
    see force_lab_leaderboard's _historical_pb), an all-time record has to beat the
    squad's best EXCLUDING the athlete's own entry (see App.tsx's live detection fix for
    why — otherwise an athlete who already IS today's top result trivially "beats" their
    own score), and a test type needs a real sample size before "all-time" means anything
    (MIN_ALLTIME_SAMPLE, mirroring App.tsx's allTimeReady).
    """
    squad_ids = _squad_athlete_ids(squad)
    force = _load_force_results()
    ignored = _load_ignored()

    pbs = []
    records = []
    for test_type in SESSION_REPORT_TEST_TYPES:
        if not _cinematics_ok(test_type):
            continue
        is_drop_jump = test_type == "drop_jump"
        dec = 3 if is_drop_jump else 1
        tol = 0.005 if is_drop_jump else 0.05

        best_by_athlete: dict[str, dict] = {}
        best_ever_by_athlete: dict[str, float] = {}
        for aid, recs in force.items():
            if aid not in squad_ids:
                continue
            for r in recs:
                if r.get("test_type") != test_type or r.get("test_id") in ignored:
                    continue
                val = _compute_primary(test_type, r.get("metrics", {}))
                if not val:
                    continue
                if val > best_ever_by_athlete.get(aid, 0.0):
                    best_ever_by_athlete[aid] = val
                if r.get("date") != target_date:
                    continue
                prev = best_by_athlete.get(aid)
                if not prev or val > _compute_primary(test_type, prev.get("metrics", {})):
                    best_by_athlete[aid] = r
        if not best_by_athlete:
            continue
        all_time_ready = len(best_ever_by_athlete) >= MIN_ALLTIME_SAMPLE

        def _hist_pb(aid: str) -> float:
            best = 0.0
            for r in force.get(aid, []):
                if r.get("test_type") != test_type or r.get("test_id") in ignored or r.get("date") == target_date:
                    continue
                v = _compute_primary(test_type, r.get("metrics", {}))
                if v > best:
                    best = v
            return best

        # The record to beat is the squad's best EXCLUDING today (any athlete, any earlier
        # date) — NOT excluding the athlete being checked. Excluding the athlete themselves
        # was the live-detection fix for a different problem (that data reflects CURRENT
        # state, which already includes their own brand new score); here we're reading
        # complete history, so there's no such race. Excluding the athlete unconditionally
        # was actually wrong for this endpoint: an athlete who already held the record and
        # broke their OWN previous best got credited with "beating" whoever was in 2nd,
        # instead of their own true prior best (real case: Quintony held CMJ at 56.03 from
        # June; today's 56.93 should read as beating his own 56.03, not Sam Clarke's 54.1).
        # One squad-wide pass, not per-athlete — also cheaper.
        at_best, at_name, at_date = 0.0, None, None
        for aid2 in squad_ids:
            for r in force.get(aid2, []):
                if r.get("test_type") != test_type or r.get("test_id") in ignored or r.get("date") == target_date:
                    continue
                v = _compute_primary(test_type, r.get("metrics", {}))
                if v > at_best:
                    at_best, at_name, at_date = v, squad_ids[aid2]["name"], r.get("date", "")

        for aid, r in best_by_athlete.items():
            athlete = squad_ids[aid]
            primary = round(_compute_primary(test_type, r.get("metrics", {})), dec)

            pb = _hist_pb(aid)
            if pb > 0 and primary >= pb - tol:
                pbs.append({
                    "id": athlete["id"], "name": athlete["name"], "initials": athlete.get("initials", athlete["name"][:2].upper()),
                    "test_type": test_type,
                    "primary": primary, "prev_pb": round(pb, dec),
                })

            if not all_time_ready:
                continue
            if at_best > 0 and primary > at_best:
                records.append({
                    "id": athlete["id"], "name": athlete["name"], "initials": athlete.get("initials", athlete["name"][:2].upper()),
                    "test_type": test_type,
                    "primary": primary, "prev_record": round(at_best, dec),
                    "prev_holder": at_name, "prev_date": at_date,
                })

    pbs.sort(key=lambda x: (x["test_type"], x["name"]))
    records.sort(key=lambda x: (x["test_type"], x["name"]))
    return {"date": target_date, "squad": squad, "pbs": pbs, "all_time_records": records}


PLYO_STAGES = [
    {
        "stage": 1, "name": "Eccentric Absorption", "color": "#EF4444",
        "drills": ["Tall-to-short landings", "Altitude landings", "Loaded eccentric step-downs"],
        "focus": "Learn to absorb and control landing forces",
    },
    {
        "stage": 2, "name": "Concentric Development", "color": "#F97316",
        "drills": ["Box jumps", "Squat jumps", "Broad jumps"],
        "focus": "Build explosive take-off strength",
    },
    {
        "stage": 3, "name": "Jump Integration", "color": "#EAB308",
        "drills": ["CMJ", "Single hurdle jumps", "Single-leg bounds"],
        "focus": "Combine eccentric and concentric actions",
    },
    {
        "stage": 4, "name": "Continuous Jumps", "color": "#84CC16",
        "drills": ["Mini hurdle hops", "Continuous broad jumps", "Ankle stiffness pogos"],
        "focus": "Reduce contact time and build rhythm",
    },
    {
        "stage": 5, "name": "Shock Method", "color": "#22C55E",
        "drills": ["Drop jumps", "Depth jumps", "Depth hops"],
        "focus": "Maximal reactive stimulus — exploit stretch-shortening cycle",
    },
]

def _plyo_stage(cmj_cm: Optional[float], rsi: Optional[float]) -> dict:
    """Classify athlete on the plyometric continuum.

    CMJ acts as a ceiling: athletes need concentric power before reactive loading.
    Rugby norms (Wood et al. 2018): forwards ~38 cm, backs ~41 cm.
    RSI is the primary classification metric within that ceiling.
    """
    cmj = cmj_cm or 0
    r   = rsi   or 0

    # CMJ ceiling — low concentric power limits reactive readiness
    if cmj > 0 and cmj < 25:
        cmj_ceiling = 1   # Very poor: eccentric absorption only
    elif cmj > 0 and cmj < 32:
        cmj_ceiling = 2   # Below average: build concentric power first
    elif cmj > 0 and cmj < 38:
        cmj_ceiling = 3   # Developing: jump integration phase
    else:
        cmj_ceiling = 5   # Rugby-standard+ CMJ: no reactive ceiling

    # RSI primary stage
    if r < 0.8:
        rsi_stage = 1
    elif r < 1.3:
        rsi_stage = 2
    elif r < 1.8:
        rsi_stage = 3
    elif r < 2.4:
        rsi_stage = 4
    else:
        rsi_stage = 5

    # Effective stage
    if cmj > 0 and r > 0:
        idx = min(rsi_stage, cmj_ceiling) - 1
    elif cmj > 0:
        # No RSI — CMJ tells us concentric readiness but not reactive; cap at Stage 3
        idx = min(cmj_ceiling, 3) - 1
    elif r > 0:
        idx = rsi_stage - 1
    else:
        idx = 2  # Stage 3 default when no data

    s = dict(PLYO_STAGES[idx])

    if cmj == 0 and r == 0:
        s["flag"] = "incomplete"
        s["flag_label"] = "Data incomplete"
        s["flag_note"] = "Needs both CMJ and drop jump test to classify"
    elif cmj == 0:
        s["flag"] = "no_cmj"
        s["flag_label"] = "No CMJ data"
        s["flag_note"] = "Classified from RSI only — add CMJ to confirm stage"
    elif r == 0:
        s["flag"] = "no_dj"
        s["flag_label"] = "No DJ data"
        s["flag_note"] = "Classified from CMJ only — add drop jump to confirm stage"
    elif cmj >= 38 and r < 1.8:
        # CMJ meets rugby forward standard but reactive capacity lags
        s["flag"] = "reactive_deficit"
        s["flag_label"] = "Reactive Deficit"
        s["flag_note"] = "CMJ meets rugby standard (≥38 cm) but RSI is low — prioritise reactive training over volume"
    else:
        s["flag"] = None
        s["flag_label"] = None
        s["flag_note"] = None

    return s


@router.get("/plyo-profile")
def plyo_profile(squad: str = "academy"):
    """Compare each athlete's best CMJ and DJ RSI to place them on the plyometric continuum."""
    squad_ids = _squad_athlete_ids(squad)
    force = _load_force_results()
    ignored = _load_ignored()

    profiles = []
    for aid, athlete in squad_ids.items():
        best_cmj_cm   = None
        best_cmj_date = None
        best_rsi      = None
        best_rsi_date = None

        for r in force.get(aid, []):
            if r.get("test_id") in ignored:
                continue
            m = r.get("metrics", {})
            tt = r.get("test_type")

            if tt == "cmj":
                jh = float(m.get("jump_height_cm") or 0)
                if jh and (best_cmj_cm is None or jh > best_cmj_cm):
                    best_cmj_cm   = round(jh, 1)
                    best_cmj_date = r.get("date", "")

            elif tt == "drop_jump":
                rsi = float(m.get("rsi_jh_ct") or 0) / 100
                if rsi and (best_rsi is None or rsi > best_rsi):
                    best_rsi      = round(rsi, 3)
                    best_rsi_date = r.get("date", "")

        stage = _plyo_stage(best_cmj_cm, best_rsi)
        profiles.append({
            "id":           int(aid),
            "name":         athlete["name"],
            "initials":     athlete.get("initials", athlete["name"][:2].upper()),
            "squad":        athlete.get("squad", ""),
            "position":     athlete.get("position", ""),
            "cmj_cm":       best_cmj_cm,
            "cmj_date":     best_cmj_date,
            "rsi":          best_rsi,
            "rsi_date":     best_rsi_date,
            "stage":        stage["stage"],
            "stage_name":   stage["name"],
            "stage_color":  stage["color"],
            "drills":       stage["drills"],
            "focus":        stage["focus"],
            "flag":         stage.get("flag"),
            "flag_label":   stage.get("flag_label"),
            "flag_note":    stage.get("flag_note"),
        })

    # Sort by stage desc then RSI desc
    profiles.sort(key=lambda p: (p["stage"], p["rsi"] or 0), reverse=True)
    return {"profiles": profiles, "squad": squad}


class RejectRequest(BaseModel):
    test_id: str
    reason: Optional[str] = None


@router.post("/reject")
def force_lab_reject(body: RejectRequest):
    if not body.test_id:
        raise HTTPException(400, "test_id required")
    ignored = _load_ignored()
    if body.test_id in ignored:
        return {"ok": True, "already_ignored": True}
    ignored.add(body.test_id)
    _save_ignored(ignored)
    return {"ok": True, "ignored_count": len(ignored)}


@router.delete("/reject/{test_id}")
def force_lab_unreject(test_id: str):
    ignored = _load_ignored()
    ignored.discard(test_id)
    _save_ignored(ignored)
    return {"ok": True, "ignored_count": len(ignored)}


async def _update_gist_session(tunnel_url: Optional[str], active: bool):
    """Patch the live session fields into the existing Gist without overwriting leaderboard data."""
    config_path = DATA_DIR / "leaderboard_share_config.json"
    try:
        config = json.loads(config_path.read_text())
    except Exception:
        return
    pat = config.get("github_pat", "").strip()
    gist_id = config.get("gist_id", "").strip()
    if not pat or not gist_id:
        return
    headers = {"Authorization": f"token {pat}", "Accept": "application/vnd.github.v3+json"}
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.get(f"https://api.github.com/gists/{gist_id}", headers=headers)
        if r.status_code != 200:
            return
        try:
            current = json.loads(r.json()["files"]["leaderboard.json"]["content"])
        except Exception:
            current = {}
        current["session_active"] = active
        current["tunnel_url"] = tunnel_url
        current["session_updated_at"] = dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ")
        await client.patch(
            f"https://api.github.com/gists/{gist_id}", headers=headers,
            json={"files": {"leaderboard.json": {"content": json.dumps(current, indent=2)}}},
        )


@router.get("/live-status")
def live_status():
    is_running = _live_proc is not None and _live_proc.returncode is None
    return {"active": is_running, "tunnel_url": _live_tunnel_url if is_running else None}


@router.post("/start-live-session")
async def start_live_session():
    global _live_proc, _live_tunnel_url
    CLOUDFLARED = "/opt/homebrew/bin/cloudflared"

    if _live_proc and _live_proc.returncode is None:
        try:
            _live_proc.terminate()
            await asyncio.wait_for(_live_proc.wait(), timeout=3.0)
        except Exception:
            pass

    try:
        _live_proc = await asyncio.create_subprocess_exec(
            CLOUDFLARED, "tunnel", "--url", "http://localhost:8093", "--no-autoupdate",
            stderr=asyncio.subprocess.PIPE,
            stdout=asyncio.subprocess.DEVNULL,
        )
    except FileNotFoundError:
        raise HTTPException(500, "cloudflared not installed. Run: brew install cloudflared")

    tunnel_url: Optional[str] = None

    async def _read_url():
        nonlocal tunnel_url
        if _live_proc is None or _live_proc.stderr is None:
            return
        while True:
            line = await _live_proc.stderr.readline()
            if not line:
                break
            m = re.search(r'https://[a-z0-9\-]+\.trycloudflare\.com', line.decode("utf-8", errors="replace"))
            if m:
                tunnel_url = m.group(0)
                return

    try:
        await asyncio.wait_for(_read_url(), timeout=25.0)
    except asyncio.TimeoutError:
        if _live_proc:
            _live_proc.terminate()
        raise HTTPException(500, "Tunnel URL not captured within 25 seconds")

    if not tunnel_url:
        raise HTTPException(500, "No tunnel URL detected from cloudflared output")

    _live_tunnel_url = tunnel_url
    await _update_gist_session(tunnel_url=tunnel_url, active=True)
    return {"ok": True, "tunnel_url": tunnel_url}


@router.post("/end-live-session")
async def end_live_session():
    global _live_proc, _live_tunnel_url
    if _live_proc:
        try:
            _live_proc.terminate()
        except Exception:
            pass
        _live_proc = None
    _live_tunnel_url = ""
    await _update_gist_session(tunnel_url=None, active=False)
    return {"ok": True}


@router.post("/deploy-leaderboard")
async def deploy_leaderboard():
    """Push HTML files from v2/public/ to the GitHub Pages repo (design updates)."""
    config_path = DATA_DIR / "leaderboard_share_config.json"
    try:
        config = json.loads(config_path.read_text())
    except Exception:
        raise HTTPException(400, "leaderboard_share_config.json not found")
    pat = config.get("github_pat", "").strip()
    if not pat:
        raise HTTPException(400, "github_pat not set")

    public_dir = DATA_DIR.parent / "v2" / "public"
    # local filename → GitHub Pages filename
    file_map = {"leaderboard.html": "index.html", "live.html": "live.html"}
    gh_headers = {"Authorization": f"Bearer {pat}", "Accept": "application/vnd.github+json"}
    deployed: list[str] = []

    async with httpx.AsyncClient(timeout=30) as client:
        for local_name, remote_name in file_map.items():
            src = public_dir / local_name
            if not src.exists():
                continue
            encoded = base64.b64encode(src.read_bytes()).decode()
            # Get existing SHA so we can update (not create a duplicate)
            r = await client.get(
                f"https://api.github.com/repos/georgemiles-code/bulls-leaderboard/contents/{remote_name}",
                headers=gh_headers,
            )
            sha = r.json().get("sha") if r.status_code == 200 else None
            body: dict = {"message": f"Deploy {remote_name}", "content": encoded}
            if sha:
                body["sha"] = sha
            r = await client.put(
                f"https://api.github.com/repos/georgemiles-code/bulls-leaderboard/contents/{remote_name}",
                headers=gh_headers, json=body,
            )
            if r.status_code in (200, 201):
                deployed.append(remote_name)

    if not deployed:
        raise HTTPException(500, "No files deployed — check HTML files exist in v2/public/")

    return {
        "ok": True,
        "deployed": deployed,
        "deployed_at": dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "url": "https://georgemiles-code.github.io/bulls-leaderboard/",
    }


# ── Auto-publish helpers ───────────────────────────────────────────────────────

def _force_results_hash() -> str:
    p = DATA_DIR / "force_results.json"
    return hashlib.md5(p.read_bytes()).hexdigest() if p.exists() else ""


async def _auto_publish_tick():
    """Publish to Gist if force_results.json has changed since last publish."""
    global _last_published_hash
    config_path = DATA_DIR / "leaderboard_share_config.json"
    try:
        config = json.loads(config_path.read_text())
    except Exception:
        return
    if not config.get("github_pat") or not config.get("gist_id"):
        return
    current = _force_results_hash()
    if current and current != _last_published_hash:
        try:
            await publish_leaderboard()
            _last_published_hash = current
        except Exception:
            pass


async def _auto_publish_loop():
    await asyncio.sleep(90)  # Wait for startup before first check
    while True:
        await _auto_publish_tick()
        await asyncio.sleep(300)  # Every 5 minutes


def start_auto_publish():
    asyncio.create_task(_auto_publish_loop())


@router.post("/publish")
async def publish_leaderboard():
    """Publish latest leaderboard snapshot to GitHub Gist for external sharing."""
    config_path = DATA_DIR / "leaderboard_share_config.json"
    try:
        config = json.loads(config_path.read_text())
    except Exception:
        raise HTTPException(400, "leaderboard_share_config.json not found. Add github_pat to enable sharing.")

    pat = config.get("github_pat", "").strip()
    if not pat:
        raise HTTPException(400, "github_pat not set in leaderboard_share_config.json")

    squad_ids = _squad_athlete_ids("male")
    force = _load_force_results()
    ignored = _load_ignored()

    tests_data: dict = {}
    for tt in ["cmj", "drop_jump", "ppu", "slj"]:
        # Find most recent session date with data for this test type
        dates: set[str] = set()
        for aid, records in force.items():
            if aid not in squad_ids:
                continue
            for r in records:
                if r.get("test_type") == tt and r.get("test_id") not in ignored:
                    d = r.get("date", "")
                    if d:
                        dates.add(d)
        if not dates:
            continue
        latest = max(dates)

        # Best result per athlete on that date
        best_on_date: dict[str, dict] = {}
        for aid, records in force.items():
            if aid not in squad_ids:
                continue
            for r in records:
                if r.get("test_type") != tt or r.get("date") != latest or r.get("test_id") in ignored:
                    continue
                val = _compute_primary(tt, r.get("metrics", {}))
                if not val:
                    continue
                prev = best_on_date.get(aid)
                if not prev or val > _compute_primary(tt, prev.get("metrics", {})):
                    best_on_date[aid] = r

        # PB = best of an athlete's non-ignored attempts from any PRIOR date — the whole
        # of `latest` is excluded, not just the specific test being shown, so an ordinary
        # improving rep within the same session doesn't count as a PB. Mirrors the same
        # fix in force_lab_leaderboard.
        def _hist_pb(aid: str) -> float:
            best = 0.0
            for r in force.get(aid, []):
                if r.get("test_type") != tt or r.get("test_id") in ignored:
                    continue
                if r.get("date") == latest:
                    continue
                v = _compute_primary(tt, r.get("metrics", {}))
                if v > best:
                    best = v
            return best

        dec = 3 if tt == "drop_jump" else 1
        entries = []
        for aid, r in best_on_date.items():
            athlete = squad_ids[aid]
            primary = round(_compute_primary(tt, r.get("metrics", {})), dec)
            pb = round(_hist_pb(aid), dec)
            entries.append({
                "name": athlete["name"],
                "position": athlete.get("position", ""),
                "squad": athlete.get("squad", ""),
                "primary": primary,
                "pb": pb if pb else None,
                "is_pb": pb > 0 and primary >= pb - (0.005 if tt == "drop_jump" else 0.05),
            })
        entries.sort(key=lambda e: e["primary"], reverse=True)
        for i, e in enumerate(entries):
            e["rank"] = i + 1

        avg = round(sum(e["primary"] for e in entries) / len(entries), dec) if entries else 0
        tests_data[tt] = {"date": latest, "entries": entries, "avg": avg, "count": len(entries)}

    payload = {
        "published_at": dt.datetime.utcnow().strftime("%Y-%m-%dT%H:%M:%SZ"),
        "team": "Taranaki Bulls",
        "tests": tests_data,
    }

    gist_id = config.get("gist_id", "").strip()
    gh_headers = {
        "Authorization": f"token {pat}",
        "Accept": "application/vnd.github.v3+json",
    }
    gist_body = {"files": {"leaderboard.json": {"content": json.dumps(payload, indent=2)}}}

    async with httpx.AsyncClient(timeout=15) as client:
        if gist_id:
            r = await client.patch(f"https://api.github.com/gists/{gist_id}", headers=gh_headers, json=gist_body)
        else:
            r = await client.post("https://api.github.com/gists", headers=gh_headers, json={
                **gist_body,
                "description": "Taranaki Bulls ForceDecks Leaderboard",
                "public": True,
            })

        if r.status_code not in (200, 201):
            raise HTTPException(502, f"GitHub API error {r.status_code}: {r.text[:200]}")

        gist = r.json()
        new_gist_id = gist["id"]
        owner = gist["owner"]["login"]
        canonical_url = f"https://gist.githubusercontent.com/{owner}/{new_gist_id}/raw/leaderboard.json"

        # Persist gist_id + canonical_url so future publishes update the same gist
        if not gist_id:
            config["gist_id"] = new_gist_id
            config["canonical_url"] = canonical_url
            config_path.write_text(json.dumps(config, indent=2))

    return {
        "ok": True,
        "gist_id": new_gist_id,
        "canonical_url": canonical_url,
        "tests_published": list(tests_data.keys()),
        "published_at": payload["published_at"],
    }
