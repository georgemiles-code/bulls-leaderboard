"""Pre-session briefing — daily synthesis of squad readiness, wellness, injuries.

Generates a structured briefing each morning using claude-fable-5 tool_use.
Scheduled at 07:00 NZT. Manual trigger available via POST /briefing/generate.
"""
import json
import os
import threading
import time
import uuid
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

import anthropic
from fastapi import APIRouter, HTTPException

NZT = timezone(timedelta(hours=12))

router = APIRouter(prefix="/briefing", tags=["briefing"])

DATA_DIR       = Path(__file__).parent.parent.parent.parent / "data"
BRIEFING_PATH  = DATA_DIR / "briefing.json"
ATHLETES_PATH  = DATA_DIR / "athletes.json"
WELLNESS_PATH  = DATA_DIR / "wellness.json"
INJURIES_PATH  = DATA_DIR / "injuries.json"
BLOCKS_PATH    = DATA_DIR / "training_blocks.json"

_generating = False


def _now_nzt() -> datetime:
    return datetime.now(NZT)


def _today_nzt() -> str:
    return _now_nzt().strftime("%Y-%m-%d")


def _load(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text())
    except Exception:
        return default


def _save(path: Path, data) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(path)


# ── Briefing tool schema ──────────────────────────────────────────────────────

_BRIEFING_TOOL = {
    "name": "generate_briefing",
    "description": "Generate a structured pre-session coaching briefing for today",
    "input_schema": {
        "type": "object",
        "required": ["headline", "session_focus", "squad_summary", "wellness_flags", "injury_updates", "action_items"],
        "properties": {
            "headline": {
                "type": "string",
                "description": "One sentence that captures today's key context (e.g. 'Heavy load day with 3 wellness flags — monitor closely')"
            },
            "session_focus": {
                "type": "string",
                "description": "What today's session should emphasise given the day of week, block phase, and squad state"
            },
            "squad_summary": {
                "type": "object",
                "required": ["available", "modified", "out"],
                "properties": {
                    "available": {"type": "integer"},
                    "modified": {"type": "integer"},
                    "out": {"type": "integer"},
                    "notes": {"type": "string", "description": "Any notable changes since yesterday"}
                }
            },
            "wellness_flags": {
                "type": "array",
                "description": "Athletes with red or amber wellness flags this morning",
                "items": {
                    "type": "object",
                    "required": ["athlete", "flag", "detail"],
                    "properties": {
                        "athlete": {"type": "string"},
                        "flag": {"type": "string", "enum": ["red", "amber"]},
                        "detail": {"type": "string", "description": "What's flagged (e.g. 'Sleep 3/10, Fatigue 2/10')"}
                    }
                }
            },
            "injury_updates": {
                "type": "array",
                "description": "Status note for each athlete on Modified/Rehab/Out",
                "items": {
                    "type": "object",
                    "required": ["athlete", "body_part", "phase", "note"],
                    "properties": {
                        "athlete": {"type": "string"},
                        "body_part": {"type": "string"},
                        "phase": {"type": "integer"},
                        "note": {"type": "string", "description": "What they can do today, any progression due"}
                    }
                }
            },
            "action_items": {
                "type": "array",
                "description": "3 to 5 specific things to do or watch during today's session",
                "items": {"type": "string"},
                "minItems": 3,
                "maxItems": 5
            },
            "load_note": {
                "type": "string",
                "description": "Load management note if relevant (e.g. high-load week, pre-competition taper)"
            }
        }
    }
}


def _build_context() -> str:
    athletes  = _load(ATHLETES_PATH, [])
    wellness  = _load(WELLNESS_PATH, {})
    injuries  = _load(INJURIES_PATH, {})
    blocks    = _load(BLOCKS_PATH, [])
    today     = _today_nzt()
    now       = _now_nzt()
    day_name  = now.strftime("%A")

    # Active block
    active_block = next((b for b in blocks if b.get("is_active")), None)
    block_ctx = ""
    if active_block:
        block_ctx = (
            f"\nACTIVE TRAINING BLOCK: {active_block['name']} — "
            f"{active_block['phase']} phase, week {active_block.get('week_number',1)} of {active_block.get('total_weeks',4)}"
        )

    # Squad status breakdown
    academy = [a for a in athletes if a.get("squad") == "academy"]
    by_status: dict = {}
    for a in academy:
        s = a.get("status", "Full Contact")
        by_status.setdefault(s, []).append(a["name"])

    status_lines = []
    for s, names in by_status.items():
        status_lines.append(f"  {s} ({len(names)}): {', '.join(names)}")
    squad_ctx = "\nSQUAD STATUS:\n" + "\n".join(status_lines)

    # Today's wellness flags
    flag_lines = []
    for name, records in wellness.items():
        if not records:
            continue
        latest = max(records, key=lambda r: r.get("date", ""))
        if latest.get("date") != today:
            continue
        flags = latest.get("flags", {})
        red   = [k for k, v in flags.items() if v == "red"]
        amber = [k for k, v in flags.items() if v == "amber"]
        if red or amber:
            parts = []
            if red:   parts.append(f"RED: {', '.join(red)}")
            if amber: parts.append(f"AMBER: {', '.join(amber)}")
            composite = latest.get("composite")
            score = f" (composite {composite:.1f})" if composite else ""
            flag_lines.append(f"  {name}{score} — {' | '.join(parts)}")
    wellness_ctx = "\nWELLNESS FLAGS TODAY:\n" + ("\n".join(flag_lines) if flag_lines else "  None submitted yet")

    # Active injuries
    injury_lines = []
    for name, entry in injuries.items():
        rec = entry.get("active")
        if not rec:
            continue
        part = rec.get("body_part", "")
        side = rec.get("side", "N/A")
        phase = rec.get("phase", 1)
        restr = ", ".join(rec.get("restrictions", []))
        cleared = ", ".join(rec.get("cleared_for", []))
        days = (datetime.now(NZT).replace(tzinfo=None) - datetime.strptime(rec.get("date_of_injury", today), "%Y-%m-%d")).days
        line = f"  {name}: {part} {'(' + side + ')' if side != 'N/A' else ''} — Phase {phase}, Day {days+1}"
        if restr:    line += f" | Restricted: {restr}"
        if cleared:  line += f" | Cleared: {cleared}"
        injury_lines.append(line)
    injury_ctx = "\nACTIVE INJURIES:\n" + ("\n".join(injury_lines) if injury_lines else "  None")

    return (
        f"DATE: {today} ({day_name})"
        f"{block_ctx}"
        f"{squad_ctx}"
        f"{wellness_ctx}"
        f"{injury_ctx}"
    )


def _run_generate() -> Optional[dict]:
    global _generating
    if _generating:
        return None
    _generating = True
    try:
        key = os.environ.get("ANTHROPIC_API_KEY")
        if not key:
            return None
        client = anthropic.Anthropic(api_key=key)
        context = _build_context()
        today = _today_nzt()

        response = client.messages.create(
            model="claude-fable-5",
            max_tokens=2000,
            system=(
                "You are a sports performance analyst for the Taranaki Bulls rugby academy. "
                "You generate concise, actionable pre-session briefings for the performance staff. "
                "Be direct and specific. Focus on what matters most for today's session. "
                "Use the squad data to make concrete recommendations, not generic advice."
            ),
            messages=[{
                "role": "user",
                "content": (
                    f"Generate today's pre-session briefing based on the following squad data:\n\n{context}\n\n"
                    "Call the generate_briefing tool with a structured briefing. "
                    "Focus on what's most important for performance staff to know before today's session."
                )
            }],
            tools=[_BRIEFING_TOOL],
            tool_choice={"type": "any"},
        )

        tool_use = next((b for b in response.content if b.type == "tool_use"), None)
        if not tool_use:
            return None

        briefing = {
            "id": str(uuid.uuid4())[:10],
            "date": today,
            "generated_at": _now_nzt().strftime("%H:%M"),
            **tool_use.input,
        }
        existing = _load(BRIEFING_PATH, [])
        if isinstance(existing, list):
            existing = [b for b in existing if b.get("date") != today]
        else:
            existing = []
        existing.insert(0, briefing)
        _save(BRIEFING_PATH, existing[:14])  # keep 2 weeks
        return briefing
    except Exception as e:
        print(f"[briefing] generation error: {e}")
        return None
    finally:
        _generating = False


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("")
def get_briefing():
    briefings = _load(BRIEFING_PATH, [])
    today = _today_nzt()
    today_briefing = next((b for b in briefings if b.get("date") == today), None)
    return {
        "today": today_briefing,
        "history": briefings[1:8] if today_briefing else briefings[:7],
        "has_today": today_briefing is not None,
    }


@router.post("/generate")
def generate_briefing():
    if _generating:
        return {"ok": False, "message": "Already generating"}
    threading.Thread(target=_run_generate, daemon=True, name="briefing-gen").start()
    return {"ok": True, "message": "Generating briefing in background"}


# ── Scheduler ─────────────────────────────────────────────────────────────────

def start_briefing_scheduler():
    """Daemon thread: generates briefing at 07:00 NZT each day if not already done."""
    def loop():
        while True:
            time.sleep(60)
            now = _now_nzt()
            if now.hour != 7 or now.minute > 10:
                continue
            briefings = _load(BRIEFING_PATH, [])
            today = _today_nzt()
            if any(b.get("date") == today for b in briefings):
                continue
            print(f"[briefing] Generating morning briefing for {today}")
            _run_generate()

    threading.Thread(target=loop, daemon=True, name="briefing-scheduler").start()
