"""Calendar API — events CRUD + RTP plans + iCal export."""
import json
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Any

from fastapi import APIRouter, HTTPException
from fastapi.responses import Response
from pydantic import BaseModel

DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"
router = APIRouter(prefix="/calendar", tags=["calendar"])


# ── Storage helpers ────────────────────────────────────────────────────────────

def _load_cal() -> dict:
    p = DATA_DIR / "calendar.json"
    try:
        return json.loads(p.read_text()) if p.exists() else {"next_id": 1, "events": []}
    except Exception:
        return {"next_id": 1, "events": []}


def _save_cal(data: dict) -> None:
    tmp = DATA_DIR / "calendar.json.tmp"
    tmp.write_text(json.dumps(data, indent=2))
    tmp.rename(DATA_DIR / "calendar.json")


def _load_rtp() -> dict:
    p = DATA_DIR / "rtp_plans.json"
    try:
        return json.loads(p.read_text()) if p.exists() else {"plans": {}}
    except Exception:
        return {"plans": {}}


def _save_rtp(data: dict) -> None:
    tmp = DATA_DIR / "rtp_plans.json.tmp"
    tmp.write_text(json.dumps(data, indent=2))
    tmp.rename(DATA_DIR / "rtp_plans.json")


def _normalize_date(s: str) -> str:
    """Normalize DD/MM/YYYY → YYYY-MM-DD; pass through ISO dates."""
    if not s:
        return s
    m = re.match(r"^(\d{2})/(\d{2})/(\d{4})$", str(s))
    if m:
        return f"{m.group(3)}-{m.group(2)}-{m.group(1)}"
    return str(s)[:10]


def _normalize_event(ev: dict) -> dict:
    ev = dict(ev)
    ev["date"] = _normalize_date(ev.get("date", ""))
    ev.setdefault("allDay", True)
    ev.setdefault("startTime", "")
    ev.setdefault("endTime", "")
    ev.setdefault("notes", "")
    ev.setdefault("squads", [])
    ev.setdefault("slot", "ALL")
    return ev


# ── Schemas ────────────────────────────────────────────────────────────────────

class EventIn(BaseModel):
    date: str
    title: str
    type: str = "gym"
    slot: str = "ALL"
    allDay: bool = True
    startTime: str = ""
    endTime: str = ""
    notes: str = ""
    squads: list[str] = []


class RTPPlanIn(BaseModel):
    name: str
    weekKey: str
    plan: dict[str, Any]


# ── Events ─────────────────────────────────────────────────────────────────────

@router.get("/events")
def get_events():
    cal = _load_cal()
    return [_normalize_event(e) for e in cal.get("events", [])]


@router.post("/events")
def add_event(ev: EventIn):
    cal = _load_cal()
    new_ev = ev.model_dump()
    new_ev["id"] = cal.get("next_id", 1)
    new_ev["date"] = _normalize_date(new_ev["date"])
    cal["next_id"] = new_ev["id"] + 1
    cal.setdefault("events", []).append(new_ev)
    _save_cal(cal)
    return new_ev


@router.get("/events/ical")
def get_ical():
    """Download all events as an iCalendar file."""
    cal = _load_cal()
    events = cal.get("events", [])

    def _ical_safe(s: str) -> str:
        return str(s).replace("\\", "\\\\").replace("\n", "\\n").replace(",", "\\,").replace(";", "\\;")

    lines = [
        "BEGIN:VCALENDAR",
        "VERSION:2.0",
        "PRODID:-//Taranaki Bulls//Dashboard v2//EN",
        "X-WR-CALNAME:Taranaki Bulls",
        "X-WR-TIMEZONE:Pacific/Auckland",
        "CALSCALE:GREGORIAN",
        "METHOD:PUBLISH",
    ]

    for ev in events:
        date_str = _normalize_date(ev.get("date", ""))
        if not date_str:
            continue
        try:
            dt = datetime.fromisoformat(date_str)
        except ValueError:
            continue

        uid = f"{ev.get('id', id(ev))}@bulls-dashboard-v2"
        summary = _ical_safe(ev.get("title", ""))
        desc = _ical_safe(ev.get("notes", ""))
        start_time = ev.get("startTime") if not ev.get("allDay", True) else ""

        lines.append("BEGIN:VEVENT")
        lines.append(f"UID:{uid}")

        if start_time:
            try:
                h, mn = [int(x) for x in str(start_time).split(":")]
                dt_start = dt.replace(hour=h, minute=mn)
                lines.append(f"DTSTART:{dt_start.strftime('%Y%m%dT%H%M%S')}")
                end_time = ev.get("endTime", "")
                if end_time:
                    he, mne = [int(x) for x in str(end_time).split(":")]
                    dt_end = dt.replace(hour=he, minute=mne)
                else:
                    dt_end = dt_start + timedelta(hours=1)
                lines.append(f"DTEND:{dt_end.strftime('%Y%m%dT%H%M%S')}")
            except Exception:
                lines.append(f"DTSTART;VALUE=DATE:{dt.strftime('%Y%m%d')}")
                lines.append(f"DTEND;VALUE=DATE:{(dt + timedelta(days=1)).strftime('%Y%m%d')}")
        else:
            lines.append(f"DTSTART;VALUE=DATE:{dt.strftime('%Y%m%d')}")
            lines.append(f"DTEND;VALUE=DATE:{(dt + timedelta(days=1)).strftime('%Y%m%d')}")

        lines.append(f"SUMMARY:{summary}")
        if desc:
            lines.append(f"DESCRIPTION:{desc}")
        lines.append("END:VEVENT")

    lines.append("END:VCALENDAR")
    ical_body = "\r\n".join(lines) + "\r\n"

    return Response(
        content=ical_body,
        media_type="text/calendar",
        headers={"Content-Disposition": "attachment; filename=bulls-calendar.ics"},
    )


@router.put("/events/{ev_id}")
def update_event(ev_id: int, ev: EventIn):
    cal = _load_cal()
    events = cal.get("events", [])
    idx = next((i for i, e in enumerate(events) if e.get("id") == ev_id), None)
    if idx is None:
        raise HTTPException(404, "Event not found")
    updated = ev.model_dump()
    updated["id"] = ev_id
    updated["date"] = _normalize_date(updated["date"])
    events[idx] = updated
    _save_cal(cal)
    return updated


@router.delete("/events/{ev_id}")
def delete_event(ev_id: int):
    cal = _load_cal()
    cal["events"] = [e for e in cal.get("events", []) if e.get("id") != ev_id]
    _save_cal(cal)
    return {"deleted": True}


# ── RTP Plans ──────────────────────────────────────────────────────────────────

@router.get("/rtp-plans")
def get_rtp_plans():
    return _load_rtp().get("plans", {})


@router.post("/rtp-plans")
def save_rtp_plan(body: RTPPlanIn):
    if not body.name.strip():
        raise HTTPException(400, "name required")
    rtp = _load_rtp()
    plans = rtp.setdefault("plans", {})
    player_plans = plans.setdefault(body.name, {})
    if body.weekKey:
        player_plans[body.weekKey] = body.plan
    _save_rtp(rtp)
    return {"saved": True}


@router.delete("/rtp-plans/{name:path}")
def delete_rtp_plan(name: str):
    rtp = _load_rtp()
    rtp.get("plans", {}).pop(name, None)
    _save_rtp(rtp)
    return {"deleted": True}
