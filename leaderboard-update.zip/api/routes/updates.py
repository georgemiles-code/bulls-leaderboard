"""Update suggestions — AI-generated improvement ideas for the dashboard."""
import json
import os
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import anthropic
from fastapi import APIRouter
from typing import Optional

router = APIRouter(prefix="/updates", tags=["updates"])

# BULLS_DATA_DIR-first (same as the other routes) — the __file__-relative fallback resolves to
# a path INSIDE the read-only .app bundle on a distributed copy, so writes there fail.
_data_env  = os.environ.get("BULLS_DATA_DIR", "")
DATA_DIR   = Path(_data_env) if _data_env else Path(__file__).parent.parent.parent.parent / "data"
STORE_PATH = DATA_DIR / "update_suggestions.json"
_lock      = threading.Lock()

CHECK_INTERVAL_HOURS = 48


# ── Persistence ────────────────────────────────────────────────────────────────

def _load_store() -> dict:
    try:
        return json.loads(STORE_PATH.read_text())
    except Exception:
        return {"last_check": None, "suggestions": [], "dismissed": []}

def _save_store(store: dict):
    STORE_PATH.write_text(json.dumps(store, indent=2))


# ── Suggestion generation ──────────────────────────────────────────────────────

APP_CONTEXT = """
The Bulls Dashboard v2 is a Tauri desktop app for the Taranaki Bulls rugby performance staff.

Current features:
- CMJ Force Lab leaderboard (live, TV/fullscreen mode, cinematic score reveals, all-time records)
- VALD ForceDecks sync (every 5 seconds when live, every 30 min background)
- Session podium (top 3 with photos), ranked rows (4th+, no photos)
- Cinematic overlays: Personal Best (amber), Session Leader (blue), All-Time Record (gold/white flash)
- Screen wake lock in TV mode
- In-app Claude chat: can query CMJ data, athlete history, all-time records, and edit dashboard layouts
- Calendar view
- GPS / STATSports data
- Strength / TeamBuildr data
- Squad: Academy + WTG (male), Whio (female)
- 106 athletes total, coaches included for fun

Tech stack: Tauri 2 + React/Vite/TypeScript frontend, FastAPI backend on port 8093, Python 3.9

Known data sources: VALD ForceDecks (live), STATSports GPS (not yet live), TeamBuildr strength (not yet live)
"""

SUGGESTION_PROMPT = """You are an advisor for a sports science dashboard used by professional rugby performance staff.

Based on this app description, suggest 4-5 specific, concrete improvement ideas. These should be genuinely useful for the coaches and performance staff, not just technical tidying.

Each suggestion should be something implementable in 1-3 hours of development. Mix UI/UX improvements, new features, and data insights.

Return ONLY a JSON array, no other text:
[
  {
    "id": "unique_slug",
    "title": "Short title (5-8 words)",
    "description": "2-3 sentences on what it does and why it's useful for the staff.",
    "category": "one of: leaderboard | data | ui | sync | chat",
    "effort": "one of: quick | medium",
    "prompt": "Ready-to-use prompt the user can send to Claude to implement this. Be specific."
  }
]

Focus on what would genuinely help performance staff during testing sessions and daily monitoring. Avoid suggestions already implemented per the description above."""


def _generate_suggestions() -> tuple:
    """Returns (suggestions, error_message). error_message is None on success."""
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        return [], "ANTHROPIC_API_KEY not set"

    client = anthropic.Anthropic(api_key=key)
    try:
        response = client.messages.create(
            model="claude-opus-4-8",
            max_tokens=2048,
            messages=[{"role": "user", "content": f"{APP_CONTEXT}\n\n{SUGGESTION_PROMPT}"}],
        )
        text = next((b.text for b in response.content if hasattr(b, "text")), "")
        text = text.strip()
        if text.startswith("```"):
            text = text.split("```")[1]
            if text.startswith("json"):
                text = text[4:]
        return json.loads(text), None
    except anthropic.APIError as e:
        msg = str(e)
        if "credit" in msg.lower() or "balance" in msg.lower():
            return [], "Anthropic account out of credits — top up at console.anthropic.com"
        return [], f"Anthropic API error: {msg}"
    except Exception as e:
        return [], f"Suggestion generation failed: {e}"


# ── Background checker ─────────────────────────────────────────────────────────

def _run_check():
    with _lock:
        store = _load_store()
        last = store.get("last_check")
        if last:
            elapsed = (datetime.utcnow() - datetime.fromisoformat(last)).total_seconds()
            if elapsed < CHECK_INTERVAL_HOURS * 3600:
                return

    suggestions, error = _generate_suggestions()

    with _lock:
        store = _load_store()
        store["last_check"] = datetime.utcnow().isoformat()
        if error:
            store["error"] = error
            print(f"[updates] {error}")
        else:
            store.pop("error", None)
            dismissed = set(store.get("dismissed", []))
            new = [s for s in suggestions if s.get("id") not in dismissed]
            store["suggestions"] = new
            print(f"[updates] generated {len(new)} suggestions")
        _save_store(store)


def start_update_checker():
    """Called at API startup — runs initial check in background."""
    threading.Thread(target=_run_check, daemon=True, name="update-checker").start()


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.get("/suggestions")
def get_suggestions():
    with _lock:
        store = _load_store()
    return {
        "suggestions": store.get("suggestions", []),
        "last_check":  store.get("last_check"),
        "count":       len(store.get("suggestions", [])),
        "error":       store.get("error"),
    }


@router.post("/dismiss/{suggestion_id}")
def dismiss_suggestion(suggestion_id: str):
    with _lock:
        store = _load_store()
        store.setdefault("dismissed", [])
        if suggestion_id not in store["dismissed"]:
            store["dismissed"].append(suggestion_id)
        store["suggestions"] = [s for s in store.get("suggestions", []) if s.get("id") != suggestion_id]
        _save_store(store)
    return {"ok": True}


@router.post("/check")
def force_check():
    """Manually trigger a fresh check (ignores the 48h cooldown)."""
    with _lock:
        store = _load_store()
        store["last_check"] = None
        _save_store(store)
    threading.Thread(target=_run_check, daemon=True).start()
    return {"ok": True, "message": "Check started in background"}
