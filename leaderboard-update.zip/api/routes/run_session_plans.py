"""Run session planner — editable grid sessions (Speed / COD / Block / Recovery)."""
import json
import uuid
from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/run-session-plans", tags=["run-session-plans"])

DATA_PATH = Path(__file__).parent.parent.parent.parent / "data" / "run_session_plans.json"

DEFAULT_COLUMNS = [
    {"id": "speed",   "label": "Speed",              "color": "amber"},
    {"id": "cod",     "label": "C.O.D",              "color": "red"},
    {"id": "block1",  "label": "Block 1",            "color": "neutral"},
    {"id": "rc1",     "label": "Recovery/Contact",   "color": "blue"},
    {"id": "block2",  "label": "Block 2",            "color": "neutral"},
    {"id": "rc2",     "label": "Recovery/Contact",   "color": "blue"},
    {"id": "block3",  "label": "Block 3",            "color": "purple"},
    {"id": "rc3",     "label": "Recovery/Contact",   "color": "blue"},
]


def _load() -> dict:
    try:
        return json.loads(DATA_PATH.read_text())
    except Exception:
        return {"sessions": []}


def _save(data: dict):
    tmp = DATA_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(DATA_PATH)


@router.get("/")
def list_sessions():
    data = _load()
    return [{"id": s["id"], "title": s["title"]} for s in data["sessions"]]


@router.post("/")
def create_session(body: dict):
    data = _load()
    session = {
        "id": str(uuid.uuid4())[:8],
        "title": body.get("title", "New Session"),
        "columns": DEFAULT_COLUMNS[:],
        "athletes": [],
    }
    data["sessions"].append(session)
    _save(data)
    return session


@router.get("/{session_id}")
def get_session(session_id: str):
    data = _load()
    s = next((s for s in data["sessions"] if s["id"] == session_id), None)
    if not s:
        raise HTTPException(404, "Session not found")
    return s


@router.put("/{session_id}")
def update_session(session_id: str, body: dict):
    data = _load()
    idx = next((i for i, s in enumerate(data["sessions"]) if s["id"] == session_id), None)
    if idx is None:
        raise HTTPException(404, "Session not found")
    data["sessions"][idx] = {**data["sessions"][idx], **body, "id": session_id}
    _save(data)
    return data["sessions"][idx]


@router.delete("/{session_id}")
def delete_session(session_id: str):
    data = _load()
    data["sessions"] = [s for s in data["sessions"] if s["id"] != session_id]
    _save(data)
    return {"ok": True}
