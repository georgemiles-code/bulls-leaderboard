"""GPS API — squad load overview, ACWR, per-athlete session history."""
import json
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

from fastapi import APIRouter

DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"
router = APIRouter(prefix="/gps", tags=["gps"])

NZT = timezone(timedelta(hours=12))


# ── Helpers ────────────────────────────────────────────────────────────────────

def _load_json(name: str, default=None):
    p = DATA_DIR / name
    try:
        return json.loads(p.read_text()) if p.exists() else default
    except Exception:
        return default


def _parse_date(s: str) -> Optional[datetime]:
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except (ValueError, TypeError):
            pass
    return None


def _acwr(sessions: list[dict], reference_date: Optional[datetime] = None) -> dict:
    """Compute ACWR and supporting load metrics relative to reference_date (default: today)."""
    ref = reference_date or datetime.now(NZT).replace(tzinfo=None)
    dated = [(s, _parse_date(s.get("date", ""))) for s in sessions]
    dated = [(s, d) for s, d in dated if d]
    if not dated:
        return {"acwr": None, "acute_avg": None, "chronic_avg": None,
                "sessions_7d": 0, "sessions_28d": 0, "total_dist_7d": None}

    acute_sessions  = [s for s, d in dated if (ref - d).days <= 7]
    chronic_sessions = [s for s, d in dated if (ref - d).days <= 28]

    acute_dist  = sum(s.get("total_dist", 0) or 0 for s in acute_sessions)
    chronic_dist = sum(s.get("total_dist", 0) or 0 for s in chronic_sessions)

    # Rolling daily averages (denominator = days in window, not session count)
    acute_avg   = acute_dist  / 7
    chronic_avg = chronic_dist / 28

    acwr = round(acute_avg / chronic_avg, 2) if chronic_avg > 0 else None
    return {
        "acwr":            acwr,
        "acute_avg":       round(acute_avg),
        "chronic_avg":     round(chronic_avg),
        "sessions_7d":     len(acute_sessions),
        "sessions_28d":    len(chronic_sessions),
        "total_dist_7d":   round(acute_dist),
    }


def _acwr_zone(acwr: Optional[float]) -> str:
    if acwr is None:     return "no_data"
    if acwr < 0.8:       return "under"
    if acwr <= 1.3:      return "optimal"
    if acwr <= 1.5:      return "elevated"
    return "danger"


def _session_type_label(raw: str) -> str:
    raw = (raw or "").strip().lower()
    if "match" in raw or "game" in raw:    return "match"
    if "gym" in raw or "weights" in raw:   return "gym"
    if "recovery" in raw or "rehab" in raw: return "recovery"
    return "training"


# ── Rolling 28-day ACWR history (daily snapshots, 1 per day) ──────────────────

def _acwr_history(sessions: list[dict], days: int = 28) -> list[dict]:
    """Return daily ACWR values for the last `days` days ending today."""
    today = datetime.now(NZT).replace(tzinfo=None, hour=0, minute=0, second=0, microsecond=0)
    result = []
    for i in range(days, -1, -1):
        ref = today - timedelta(days=i)
        a = _acwr(sessions, reference_date=ref)
        if a["acwr"] is not None or a["sessions_28d"] > 0:
            result.append({
                "date": ref.strftime("%Y-%m-%d"),
                "acwr": a["acwr"],
                "zone": _acwr_zone(a["acwr"]),
                "sessions_7d": a["sessions_7d"],
            })
    return result


# ── Endpoints ──────────────────────────────────────────────────────────────────

def _norm(name: str) -> str:
    return (name or "").lower().replace(" ", "").replace("-", "").replace("'", "")


def _gps_for_athlete(athlete: dict, gps_data: dict) -> list:
    """Look up GPS sessions by athlete name (GPS data is name-keyed, not ID-keyed)."""
    name = athlete.get("name", "")
    # Exact match first
    if name in gps_data:
        return gps_data[name]
    # Normalised match
    norm = _norm(name)
    for key, sessions in gps_data.items():
        if _norm(key) == norm:
            return sessions
    return []


@router.get("/squad")
def gps_squad(squad: str = "academy"):
    athletes    = _load_json("athletes.json", [])
    gps_data    = _load_json("gps.json", {})
    squad_aths  = [a for a in athletes if a.get("squad") == squad]

    rows = []
    for a in squad_aths:
        sessions = _gps_for_athlete(a, gps_data)
        # Compute ACWR relative to athlete's last session date so stale data
        # still shows a meaningful value rather than collapsing to no_data.
        last_dt = None
        if sessions:
            dated = [(s, _parse_date(s.get("date", ""))) for s in sessions]
            dated = [(s, d) for s, d in dated if d]
            if dated:
                last_dt = max(d for _, d in dated)
        load = _acwr(sessions, reference_date=last_dt)

        latest_session = None
        if sessions:
            dated = [(s, _parse_date(s.get("date", ""))) for s in sessions]
            dated = [(s, d) for s, d in dated if d]
            if dated:
                dated.sort(key=lambda x: x[1], reverse=True)
                ls, ld = dated[0]
                latest_session = {
                    "date":       ld.strftime("%Y-%m-%d"),
                    "total_dist": ls.get("total_dist"),
                    "hsr":        ls.get("hsr"),
                    "session_type": _session_type_label(ls.get("session_type", "")),
                    "drill":      ls.get("drill", ""),
                }

        rows.append({
            "id":             a["id"],
            "name":           a["name"],
            "initials":       a.get("initials", a["name"][:2].upper()),
            "position_group": a.get("positionGroup", ""),
            "position":       a.get("position", ""),
            "status":         a.get("status", "Full Contact"),
            "has_gps":        len(sessions) > 0,
            "total_sessions": len(sessions),
            "acwr":           load["acwr"],
            "acwr_zone":      _acwr_zone(load["acwr"]),
            "acute_avg":      load["acute_avg"],
            "chronic_avg":    load["chronic_avg"],
            "sessions_7d":    load["sessions_7d"],
            "total_dist_7d":  load["total_dist_7d"],
            "latest_session": latest_session,
        })

    # Sort: has_gps first, then by ACWR zone severity
    zone_order = {"danger": 0, "elevated": 1, "no_data": 2, "optimal": 3, "under": 4}
    rows.sort(key=lambda r: (0 if r["has_gps"] else 1, zone_order.get(r["acwr_zone"], 5)))

    # Zone counts
    zone_counts = {"danger": 0, "elevated": 0, "optimal": 0, "under": 0, "no_data": 0}
    for r in rows:
        z = r["acwr_zone"]
        if z in zone_counts:
            zone_counts[z] += 1

    return {
        "squad": squad,
        "total": len(rows),
        "with_gps": sum(1 for r in rows if r["has_gps"]),
        "zone_counts": zone_counts,
        "athletes": rows,
    }


@router.get("/athlete/{athlete_id}")
def gps_athlete(athlete_id: int, squad: str = "academy"):
    athletes = _load_json("athletes.json", [])
    gps_data = _load_json("gps.json", {})

    a = next((x for x in athletes if x["id"] == athlete_id), None)
    if not a:
        from fastapi import HTTPException
        raise HTTPException(404, f"Athlete {athlete_id} not found")

    sessions = _gps_for_athlete(a, gps_data)
    dated = [(s, _parse_date(s.get("date", ""))) for s in sessions]
    dated = [(s, d) for s, d in dated if d]
    dated.sort(key=lambda x: x[1], reverse=True)

    session_list = [
        {
            "date":         d.strftime("%Y-%m-%d"),
            "total_dist":   s.get("total_dist"),
            "hsr":          s.get("hsr"),
            "sprint_dist":  s.get("sprint_dist"),
            "sprints":      s.get("sprints"),
            "max_speed":    s.get("max_speed"),
            "accelerations": s.get("accelerations"),
            "session_type": _session_type_label(s.get("session_type", "")),
            "drill":        s.get("drill", ""),
        }
        for s, d in dated
    ]

    load    = _acwr(sessions)
    history = _acwr_history(sessions, days=42)

    return {
        "id":             a["id"],
        "name":           a["name"],
        "position_group": a.get("positionGroup", ""),
        "acwr":           load["acwr"],
        "acwr_zone":      _acwr_zone(load["acwr"]),
        "acute_avg":      load["acute_avg"],
        "chronic_avg":    load["chronic_avg"],
        "sessions_7d":    load["sessions_7d"],
        "total_sessions": len(sessions),
        "sessions":       session_list,
        "acwr_history":   history,
    }


@router.get("/sessions")
def gps_sessions(squad: str = "academy"):
    """All unique session dates with squad-level totals."""
    athletes = _load_json("athletes.json", [])
    gps_data = _load_json("gps.json", {})
    squad_names = {_norm(a["name"]) for a in athletes if a.get("squad") == squad}

    by_date: dict[str, list] = {}
    for key, sessions in gps_data.items():
        if _norm(key) not in squad_names:
            continue
        for s in sessions:
            d = _parse_date(s.get("date", ""))
            if not d:
                continue
            key = d.strftime("%Y-%m-%d")
            by_date.setdefault(key, []).append(s)

    result = []
    for date_str, day_sessions in sorted(by_date.items(), reverse=True):
        athletes_tested = len(day_sessions)
        avg_dist = sum(s.get("total_dist", 0) or 0 for s in day_sessions) / athletes_tested
        session_type = _session_type_label(day_sessions[0].get("session_type", ""))
        result.append({
            "date": date_str,
            "athletes": athletes_tested,
            "avg_dist": round(avg_dist),
            "session_type": session_type,
            "drill": day_sessions[0].get("drill", ""),
        })

    return {"sessions": result, "total_days": len(result)}


@router.get("/rehab-report/{athlete_id}")
def rehab_report(athlete_id: int, squad: str = "academy", rehab_only: bool = False):
    """Return all GPS sessions for an athlete formatted for the rehab running report."""
    athletes = _load_json("athletes.json", [])
    gps_data = _load_json("gps.json", {})

    a = next((x for x in athletes if x["id"] == athlete_id), None)
    if not a:
        from fastapi import HTTPException
        raise HTTPException(404, f"Athlete {athlete_id} not found")

    sessions = _gps_for_athlete(a, gps_data)
    pool = [s for s in sessions if _parse_date(s.get("date", ""))]
    if rehab_only:
        pool = [s for s in pool if s.get("rehab_running")]
    sessions_sorted = sorted(pool, key=lambda s: _parse_date(s["date"]))

    def fmt(s):
        d = _parse_date(s.get("date", ""))
        return {
            "date":          d.strftime("%Y-%m-%d") if d else s.get("date"),
            "total_dist":    s.get("total_dist"),
            "hml_dist":      s.get("hml_dist"),
            "hsr":           s.get("hsr"),
            "max_speed":     s.get("max_speed"),
            "avg_speed":     s.get("avg_speed"),
            "sprints":       s.get("sprints"),
            "sprint_dist":   s.get("sprint_dist"),
            "accelerations": s.get("accelerations"),
            "decelerations": s.get("decelerations"),
            "max_accel":     s.get("max_accel"),
            "max_decel":     s.get("max_decel"),
            "running_dist":  s.get("running_dist"),
            "explosive_dist":s.get("explosive_dist"),
            "dsl":           s.get("dsl"),
            "energy_kcal":   s.get("energy_kcal"),
            "max_hr":        s.get("max_hr"),
            "avg_hr":        s.get("avg_hr"),
            "total_min":     s.get("total_min"),
            "session_type":  s.get("session_type", "General"),
            "drill":         s.get("drill", ""),
            "rehab_running": s.get("rehab_running", False),
        }

    formatted = [fmt(s) for s in sessions_sorted]

    # Compute progression deltas vs first session
    def delta(sessions, key):
        first = next((s[key] for s in sessions if s[key] is not None), None)
        if first is None or first == 0:
            return [None] * len(sessions)
        return [round((s[key] - first) / first * 100, 1) if s[key] is not None else None for s in sessions]

    player_max = a.get("pb") or max((s.get("max_speed") or 0 for s in formatted), default=None)

    return {
        "athlete": {
            "id":       a["id"],
            "name":     a["name"],
            "initials": a.get("initials", a["name"][:2].upper()),
            "position": a.get("position", ""),
            "status":   a.get("status", "Full Contact"),
            "photo":    a.get("photo"),
            "player_max_speed": player_max,
        },
        "sessions": formatted,
        "session_count": len(formatted),
        "deltas": {
            "running_dist":  delta(formatted, "running_dist"),
            "hml_dist":      delta(formatted, "hml_dist"),
            "hsr":           delta(formatted, "hsr"),
            "max_speed":     delta(formatted, "max_speed"),
            "accelerations": delta(formatted, "accelerations"),
        },
    }
