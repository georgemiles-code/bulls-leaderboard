"""Sync route — manual triggers + auto-scheduler for all data sources."""
import json
import os
import sys
import threading
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

from fastapi import APIRouter
from pydantic import BaseModel

router = APIRouter(prefix="/sync", tags=["sync"])

# sync_agent.py lives two levels up from this file (sports-dashboard/sync_agent.py)
# in the dev repo. Same resolution as force_lab.py — must check BULLS_DATA_DIR
# first. In the bundled .app, `_REPO_ROOT` (relative to this file's location
# inside Contents/Resources/api/routes/) points nowhere near either the real
# data dir or the real sync_agent.py, since only v2/api is bundled as a
# resource — the repo root one level above it isn't. That broke two things:
# every sync write raised (nonexistent data dir), which killed the background
# thread before it could clear its own in-flight flag, permanently wedging it
# as "already running"; and even once that's fixed, `import sync_agent` itself
# fails ("No module named 'sync_agent'") because it was never on sys.path.
# BULLS_DATA_DIR's parent is the real repo root — that's where both the real
# data/ dir and sync_agent.py actually live on this machine.
_REPO_ROOT = Path(__file__).parent.parent.parent.parent
_data_env = os.environ.get("BULLS_DATA_DIR", "")
if _data_env:
    DATA_DIR = Path(_data_env)
    _REPO_ROOT = DATA_DIR.parent
else:
    DATA_DIR = _REPO_ROOT / "data"
sys.path.insert(0, str(_REPO_ROOT))
CONFIG_PATH = DATA_DIR / "sync_config.json"
STATUS_PATH = DATA_DIR / "sync_status.json"

_lock = threading.Lock()
_inflight: set[str] = set()

SOURCES = ["vald", "vald_live", "teambuildr", "teambuildr_wellness", "statsports", "smartabase", "gymaware", "gymaware_live"]


# ── Credentials ────────────────────────────────────────────────────────────────

def _reload_env():
    env_file = _REPO_ROOT / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                k, v = k.strip(), v.strip()
                if v:
                    os.environ[k] = v

def _build_creds(source: str) -> dict:
    _reload_env()
    creds = {
        "token_url":     os.getenv("VALD_TOKEN_URL", "https://auth.prd.vald.com/oauth/token"),
        "audience":      os.getenv("VALD_AUDIENCE", "vald-api-external"),
        "client_id":     os.getenv("VALD_CLIENT_ID", ""),
        "client_secret": os.getenv("VALD_CLIENT_SECRET", ""),
        "api_base":      "https://prd-aue-api-extforcedecks.valdperformance.com",
        "vald_username": os.getenv("VALD_USERNAME", ""),
        "vald_password": os.getenv("VALD_PASSWORD", ""),
        "api_key":       "",
        "team_id":       "",
        "base_url":      os.getenv("SMARTABASE_URL", "").split("/?")[0].split("/#")[0].rstrip("/"),
        "username":      os.getenv("SMARTABASE_USERNAME", ""),
        "password":      os.getenv("SMARTABASE_PASSWORD", ""),
    }
    if source == "teambuildr":
        creds["api_key"] = os.getenv("TEAMBUILDR_API_KEY", "")
        creds["team_id"] = os.getenv("TEAMBUILDR_TEAM_ID", "")
        creds["username"] = os.getenv("TEAMBUILDR_USERNAME", "")
        creds["password"] = os.getenv("TEAMBUILDR_PASSWORD", "")
    elif source == "statsports":
        creds["api_key"] = os.getenv("STATSPORTS_API_KEY", "") or os.getenv("SONRA_API_KEY", "")
        creds["team_id"] = os.getenv("STATSPORTS_TEAM_ID", "") or os.getenv("SONRA_TEAM_ID", "")
        creds["username"] = os.getenv("SONRA_USERNAME", "")
        creds["password"] = os.getenv("SONRA_PASSWORD", "")
    elif source == "teambuildr_wellness":
        creds["username"] = os.getenv("TEAMBUILDR_USERNAME", "")
        creds["password"] = os.getenv("TEAMBUILDR_PASSWORD", "")
    elif source in ("gymaware", "gymaware_live"):
        creds["account_id"] = os.getenv("GYMAWARE_ACCOUNT_ID", "")
        creds["api_token"]  = os.getenv("GYMAWARE_API_TOKEN", "")
    return creds


# ── Config helpers ─────────────────────────────────────────────────────────────

def _load_config() -> dict:
    if CONFIG_PATH.exists():
        try:
            return json.loads(CONFIG_PATH.read_text())
        except Exception:
            pass
    return {}


def _save_config(cfg: dict):
    CONFIG_PATH.write_text(json.dumps(cfg, indent=2))


def _load_status() -> dict:
    if STATUS_PATH.exists():
        try:
            return json.loads(STATUS_PATH.read_text())
        except Exception:
            pass
    return {}


def _save_status(status: dict):
    STATUS_PATH.write_text(json.dumps(status, indent=2))


# ── Background sync runner ─────────────────────────────────────────────────────

def _run_sync_bg(source: str, squad: str = None):
    # _inflight.discard(source) must always run no matter what fails above it —
    # otherwise a single bad write (bad path, disk full, whatever) permanently
    # wedges this source as "already running" until the process is restarted.
    try:
        try:
            from sync_agent import run_sync
            result = run_sync(
                source,
                _build_creds(source),
                anthropic_key=os.getenv("ANTHROPIC_API_KEY", ""),
                squad=squad,
            )
        except Exception as e:
            result = {"success": False, "message": str(e), "records": 0}

        now = datetime.utcnow().isoformat()

        with _lock:
            cfg = _load_config()
            if source not in cfg:
                cfg[source] = {}
            cfg[source]["last_sync"] = now
            cfg[source]["last_result"] = result
            _save_config(cfg)

            status = _load_status()
            status[source] = {
                "lastSync": now + "Z",
                "success": result.get("success", False),
                "message": result.get("message", ""),
                "records": result.get("records", 0),
                "inFlight": False,
            }
            _save_status(status)
    finally:
        _inflight.discard(source)


def _trigger(source: str, squad: str = None) -> bool:
    """Start a background sync for source. Returns False if already in flight."""
    with _lock:
        if source in _inflight:
            return False
        _inflight.add(source)
        status = _load_status()
        if source not in status:
            status[source] = {}
        status[source]["inFlight"] = True
        _save_status(status)

    threading.Thread(target=_run_sync_bg, args=(source, squad), daemon=True).start()
    return True


# ── Auto-scheduler ─────────────────────────────────────────────────────────────

WELLNESS_FAST_INTERVAL_S = 30  # sync wellness from TeamBuildr every 30 s


def start_scheduler():
    """Called once at API startup. Runs two loops:
    - Main loop: checks every 60 s whether any source is due per its interval_hours config.
    - Wellness fast loop: syncs teambuildr_wellness every 30 s when enabled.
    """
    import time

    def loop():
        while True:
            time.sleep(60)
            with _lock:
                cfg = _load_config()
            now = datetime.utcnow()
            for source in SOURCES:
                sc = cfg.get(source, {})
                if not sc.get("enabled"):
                    continue
                with _lock:
                    if source in _inflight:
                        continue
                interval_s = sc.get("interval_hours", 24) * 3600
                last = sc.get("last_sync")
                if last:
                    try:
                        elapsed = (now - datetime.fromisoformat(last)).total_seconds()
                        if elapsed < interval_s:
                            continue
                    except Exception:
                        pass
                _trigger(source)

    def wellness_loop():
        """Polls TeamBuildr wellness every WELLNESS_FAST_INTERVAL_S seconds when enabled."""
        time.sleep(10)  # short startup delay so the main process is ready
        while True:
            with _lock:
                cfg = _load_config()
                enabled = cfg.get("teambuildr_wellness", {}).get("enabled", False)
                inflight = "teambuildr_wellness" in _inflight
            if enabled and not inflight:
                last = cfg.get("teambuildr_wellness", {}).get("last_sync")
                if last:
                    try:
                        elapsed = (datetime.utcnow() - datetime.fromisoformat(last)).total_seconds()
                        if elapsed >= WELLNESS_FAST_INTERVAL_S:
                            _trigger("teambuildr_wellness")
                    except Exception:
                        pass
                else:
                    _trigger("teambuildr_wellness")
            time.sleep(WELLNESS_FAST_INTERVAL_S)

    threading.Thread(target=loop, daemon=True, name="sync-scheduler").start()
    threading.Thread(target=wellness_loop, daemon=True, name="wellness-fast-sync").start()


# ── Endpoints ──────────────────────────────────────────────────────────────────

class SyncStatus(BaseModel):
    lastSync: Optional[str] = None
    success: Optional[bool] = None
    message: Optional[str] = None
    records: Optional[int] = None
    inFlight: bool = False


@router.get("/status")
def get_status():
    status = _load_status()
    with _lock:
        for src in _inflight:
            if src in status:
                status[src]["inFlight"] = True
    return status


@router.get("/config")
def get_config():
    return _load_config()


@router.post("/run/{source}")
def run_source(source: str, squad: Optional[str] = None):
    if source not in SOURCES:
        return {"ok": False, "error": f"Unknown source '{source}'"}
    started = _trigger(source, squad)
    return {"ok": True, "started": started, "already_running": not started}


@router.post("/import-vald-csv")
def import_vald_csv():
    """Process any unprocessed VALD CSV exports in imports/vald/ → force_results.json."""
    try:
        import importlib.util, pathlib
        script = _REPO_ROOT / "import_vald_csv.py"
        spec   = importlib.util.spec_from_file_location("import_vald_csv", script)
        mod    = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(mod)
        log_lines: list[str] = []
        count = mod.run(paths=None, log=log_lines.append)
        return {"ok": True, "records": count, "log": log_lines}
    except Exception as e:
        return {"ok": False, "error": str(e), "records": 0}


@router.get("/vald-csv-status")
def vald_csv_status():
    """List VALD CSV files in imports/vald/ and whether each has been processed."""
    import_dir = _REPO_ROOT / "imports" / "vald"
    imported_log = DATA_DIR / "imported_vald_csvs.json"
    try:
        imported: set[str] = set(json.loads(imported_log.read_text()).get("files", [])) if imported_log.exists() else set()
    except Exception:
        imported = set()
    files = []
    if import_dir.exists():
        for p in sorted(import_dir.glob("*.csv")):
            files.append({"name": p.name, "imported": p.name in imported})
    return {"files": files, "import_dir": str(import_dir)}
