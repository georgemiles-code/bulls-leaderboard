"""Strength API — 1RM trends, PRs, squad leaderboard by lift."""
import json
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException

DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"
router = APIRouter(prefix="/strength", tags=["strength"])

NZT = timezone(timedelta(hours=12))

# Canonical primary lifts shown in the UI (subset of all tracked)
PRIMARY_LIFTS = ["BackSquat_kg", "TrapBar_kg", "BenchPress_kg", "RDL_kg", "ChinUp_kg"]
LIFT_LABELS = {
    "BackSquat_kg":   "Back Squat",
    "TrapBar_kg":     "Trap Bar DL",
    "BenchPress_kg":  "Bench Press",
    "RDL_kg":         "RDL",
    "ChinUp_kg":      "Chin-up (+kg)",
    "FrontSquat_kg":  "Front Squat",
    "BenchPull_kg":   "Bench Pull",
    "BoxSquat_kg":    "Box Squat",
    "BulgarianSS_kg": "Bulgarian SS",
    "DBBenchPress_kg":"DB Bench Press",
    "FloorPress_kg":  "Floor Press",
    "MilitaryPress_kg":"Military Press",
    "PushPress_kg":   "Push Press",
}


def _load_athletes():
    p = DATA_DIR / "athletes.json"
    try:
        return json.loads(p.read_text())
    except Exception:
        return []


def _load_strength():
    p = DATA_DIR / "strength.json"
    try:
        return json.loads(p.read_text())
    except Exception:
        return {}


def _parse_date(s: str) -> Optional[datetime]:
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except (ValueError, TypeError):
            pass
    return None


def _norm(name: str) -> str:
    return (name or "").lower().replace(" ", "").replace("-", "").replace("'", "")


def _strength_for_athlete(athlete: dict, strength_data: dict) -> list:
    name = athlete.get("name", "")
    if name in strength_data:
        return strength_data[name]
    norm = _norm(name)
    for key, sessions in strength_data.items():
        if _norm(key) == norm:
            return sessions
    return []


def _compute_pr_map(sessions: list) -> dict[str, dict]:
    """Return {lift: {value, date}} for each lift's all-time best."""
    prs: dict[str, dict] = {}
    for s in sessions:
        d = _parse_date(s.get("date", ""))
        if not d:
            continue
        for lift, v in s.items():
            if lift == "date" or not isinstance(v, (int, float)):
                continue
            if lift not in prs or v > prs[lift]["value"]:
                prs[lift] = {"value": v, "date": d.strftime("%Y-%m-%d")}
    return prs


def _lift_trend(sessions: list, lift: str, limit: int = 20) -> list[dict]:
    """Chronological list of {date, value} for a given lift."""
    points = []
    for s in sessions:
        v = s.get(lift)
        if not isinstance(v, (int, float)):
            continue
        d = _parse_date(s.get("date", ""))
        if not d:
            continue
        points.append({"date": d.strftime("%Y-%m-%d"), "value": v})
    points.sort(key=lambda x: x["date"])
    return points[-limit:]


def _days_since_pr(pr: Optional[dict]) -> Optional[int]:
    if not pr:
        return None
    d = _parse_date(pr["date"])
    if not d:
        return None
    return (datetime.now(NZT).replace(tzinfo=None) - d).days


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.get("/squad")
def strength_squad(squad: str = "academy"):
    athletes = _load_athletes()
    strength_data = _load_strength()
    squad_aths = [a for a in athletes if a.get("squad") == squad]

    rows = []
    for a in squad_aths:
        sessions = _strength_for_athlete(a, strength_data)
        pr_map = _compute_pr_map(sessions)

        # Summary: PRs for the 5 primary lifts
        primary = {}
        for lift in PRIMARY_LIFTS:
            pr = pr_map.get(lift)
            primary[lift] = {
                "label": LIFT_LABELS.get(lift, lift),
                "pr": pr["value"] if pr else None,
                "pr_date": pr["date"] if pr else None,
                "days_since_pr": _days_since_pr(pr),
            }

        # Last session date
        last_date = None
        dated = [(s, _parse_date(s.get("date", ""))) for s in sessions]
        dated = [(s, d) for s, d in dated if d]
        if dated:
            last_date = max(d for _, d in dated).strftime("%Y-%m-%d")

        rows.append({
            "id":             a["id"],
            "name":           a["name"],
            "initials":       a.get("initials", a["name"][:2].upper()),
            "position_group": a.get("positionGroup", ""),
            "position":       a.get("position", ""),
            "status":         a.get("status", "Full Contact"),
            "has_strength":   len(sessions) > 0,
            "total_sessions": len(sessions),
            "last_date":      last_date,
            "primary_lifts":  primary,
        })

    rows.sort(key=lambda r: (0 if r["has_strength"] else 1, r["position_group"], r["name"]))

    return {
        "squad":       squad,
        "total":       len(rows),
        "with_data":   sum(1 for r in rows if r["has_strength"]),
        "lifts":       PRIMARY_LIFTS,
        "lift_labels": LIFT_LABELS,
        "athletes":    rows,
    }


@router.get("/athlete/{athlete_id}")
def strength_athlete(athlete_id: int):
    athletes = _load_athletes()
    strength_data = _load_strength()

    a = next((x for x in athletes if x["id"] == athlete_id), None)
    if not a:
        raise HTTPException(404, f"Athlete {athlete_id} not found")

    sessions = _strength_for_athlete(a, strength_data)
    pr_map = _compute_pr_map(sessions)

    # Trends for all lifts that have at least 2 data points
    trends: dict[str, list] = {}
    all_lifts = set()
    for s in sessions:
        all_lifts.update(k for k in s if k != "date")

    for lift in all_lifts:
        trend = _lift_trend(sessions, lift)
        if len(trend) >= 2:
            trends[lift] = trend

    # Full PR map with labels
    prs = {}
    for lift, pr in pr_map.items():
        prs[lift] = {
            "label":       LIFT_LABELS.get(lift, lift),
            "value":       pr["value"],
            "date":        pr["date"],
            "days_since":  _days_since_pr(pr),
        }

    # Recent sessions (last 10, newest first)
    dated = [(s, _parse_date(s.get("date", ""))) for s in sessions]
    dated = [(s, d) for s, d in dated if d]
    dated.sort(key=lambda x: x[1], reverse=True)
    recent = []
    for s, d in dated[:10]:
        lifts_done = {k: v for k, v in s.items() if k != "date" and isinstance(v, (int, float))}
        recent.append({"date": d.strftime("%Y-%m-%d"), "lifts": lifts_done})

    return {
        "id":             a["id"],
        "name":           a["name"],
        "position_group": a.get("positionGroup", ""),
        "total_sessions": len(sessions),
        "prs":            prs,
        "trends":         trends,
        "recent":         recent,
        "primary_lifts":  PRIMARY_LIFTS,
    }


@router.get("/leaderboard")
def strength_leaderboard(lift: str = "BackSquat_kg", squad: str = "academy"):
    if lift not in LIFT_LABELS:
        raise HTTPException(400, f"Unknown lift: {lift}")

    athletes = _load_athletes()
    strength_data = _load_strength()
    squad_aths = [a for a in athletes if a.get("squad") == squad]

    entries = []
    for a in squad_aths:
        sessions = _strength_for_athlete(a, strength_data)
        pr_map = _compute_pr_map(sessions)
        pr = pr_map.get(lift)
        if not pr:
            continue
        entries.append({
            "id":             a["id"],
            "name":           a["name"],
            "initials":       a.get("initials", a["name"][:2].upper()),
            "position_group": a.get("positionGroup", ""),
            "position":       a.get("position", ""),
            "value":          pr["value"],
            "date":           pr["date"],
            "days_since":     _days_since_pr(pr),
        })

    entries.sort(key=lambda e: e["value"], reverse=True)
    for i, e in enumerate(entries):
        e["rank"] = i + 1

    return {
        "lift":       lift,
        "lift_label": LIFT_LABELS[lift],
        "squad":      squad,
        "entries":    entries,
        "count":      len(entries),
    }
