"""Periodisation — group calendar programming, key dates, AI week generation."""
import json
import os
import uuid
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import anthropic
import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/periodisation", tags=["periodisation"])

DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"
KEY_DATES_PATH    = DATA_DIR / "key_dates.json"
BLOCKS_PATH       = DATA_DIR / "training_blocks.json"
GROUP_PROGS_PATH  = DATA_DIR / "group_programs.json"
TB_HISTORY_PATH   = DATA_DIR / "tb_history.json"
PROGRAMS_PATH     = DATA_DIR / "rehab_programs.json"

TB_BASE         = "https://api.teambuildr.com"
TB_TOKEN_URL    = f"{TB_BASE}/oauth/token"
TB_CLIENT_ID    = "xBLi9kmYnG6i586"
TB_CLIENT_SECRET = "xWlwYjVPKCyOkSk"
TB_ACCOUNT_CODE = 5292

TB_CALENDARS_KNOWN = [
    {"id": 199612, "name": "Academy - Strength", "group": "TRFU Mens Academy", "members": 15},
    {"id": 208484, "name": "Academy - Year 1",   "group": "TRFU Mens Academy", "members": 10},
]

TB_GROUPS_KNOWN = [
    {"id": 12337,  "name": "Academy",           "members": 32},
    {"id": 12338,  "name": "Bulls HP",           "members": 39},
    {"id": 6349,   "name": "NPC 2026",           "members": 29},
    {"id": 76257,  "name": "FPC Squad",          "members": None},
    {"id": 11146,  "name": "Whio Academy",       "members": None},
    {"id": 125854, "name": "Bulls Development",  "members": None},
]

# All exercises with TB IDs (must stay in sync with programming.py)
TB_EXERCISE_IDS: dict[str, int] = {
    "Band Pull Apart": 2291775,
    "DB Single Arm External Rotation": 2614840,
    "Serratus Wall Slides": 3922179,
    "Banded Y-T-A": 33055076,
    "nzr_bb bench press": 14918540,
    "BB Push Press": 1296715,
    "Incline DB Bench Press": 1279646,
    "Alternating Incline DB Bench Press": 2122239,
    "L-Sit DB Press": 28790571,
    "nzr_bench pull": 14918546,
    "nzr_weighted chin": 14918544,
    "Lat Pull Down Wide Grip": 9603847,
    "Single Arm Dumbbell Row": 1279530,
    "1/2 Kneeling Cable Face Pull": 1280030,
    "Tricep Pushdown": 2410163,
    "DB Bicep Curl": 1383388,
    "4 Way Neck Isometric": 10694560,
    "Kneeling Pallof Press": 1279637,
    "Bent Knee Copenhagen Plank": 15041581,
    "Spanish Squat ISO": 32506364,
    "Leg Press": 2615934,
    "BB Hip Thrust": 3453958,
    "BW Bulgarian Split Squat": 9115607,
    "B Stance DB RDL": 10069899,
    "Banded TKE Step Up": 30124273,
    "Bent knee single leg calf raise": 5365082,
    "nzr_box squat": 14918527,
    "2:1 Calf Raise": 5997700,
    "DB Step Up": 1819690,
    "Y Balance": 29119665,
    "DB Shoulder Press": 1370992,
    "Pallof Press Rotations": 1279637,
    "Bench Medball Leg Lowers": 3453958,
    "Seated DB Calf Raise": 5997700,
    "1/2 Kneeling Banded Face Pull": 1280030,
    "Leg Press Calf Raises": 5365082,
    "DB Hammer Curl": 1383388,
    "DB RDL": 10069899,
    "Banded TKE": 30124273,
    "Bulgarian Split Squat": 9115607,
    "Side-Lying Hip Abduction": 29622425,
    "Banded Hip Abduction": 28742172,
    "SL Calf Raise": 2559011,
    "SL Seated DB Calf Raise": 2236733,
    "DL Pogos on Weight Plate": 31160692,
    "SL Balance": 5838910,
    "Star Excursion Balance": 5838910,
    "Bosu Lateral Up and Overs": 18569796,
    "Incline IYT": 9073028,
    "1/2 Kneeling T-Spine Rotation": 23057500,
    "Adductor Rock Back": 33057115,
    "nzr_bb step up": 14918529,
    "Double leg broad jump to SL land": 1279728,
    "Lateral hop and hold": 12323765,
    "SL depth drop to SL land": 3502221,
    "Banded ankle dorsiflexion": 31780583,
    "Banded ankle eversion": 31534898,
    "Standing SL Calf Raise": 2559011,
    "Seated SL Calf Raise": 5418290,
    "Lateral hip lock step up": 28937173,
    "DB Chest Fly": 3278797,
    "Barbell Bent Over Row": 2236702,
    "1/2 Kneeling DB Shoulder Press": 28790505,
    "Banded Front Neck Iso + Plyo": 3453950,
    "Wattbike": 1475722,
    "Leg Extension": 4571964,
    "Hamstring Single leg machine curl": 11024814,
    "Wide Grip Seated Row": 1298141,
    "DB Rear Delt Fly": 1279527,
    "Seated Row": 1279649,
    "Isometric Adductor Squeeze": 24634732,
    "Glute Bridge": 1279689,
    "Glute Clams": 9177886,
    "Overcoming Isometric Calf Raise": 24389186,
    "Banded Ankle Eversion": 31534898,
    "Single Leg Hip Thrust": 1280729,
    "Alternating DB Shoulder Press": 1298648,
    "Neutral Grip Chin Ups": 2378025,
    "Long Sitting Hip Flexor Lift": 14988755,
}

BLOCK_PHASES = ["Accumulation", "Intensification", "Realisation", "Taper"]


def _load(path: Path, default):
    try:
        return json.loads(path.read_text()) if path.exists() else default
    except Exception:
        return default


def _save(path: Path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(path)


async def _tb_token() -> str:
    username = os.getenv("TEAMBUILDR_USERNAME", "george@trfu.co.nz")
    password = os.getenv("TEAMBUILDR_PASSWORD", "Gothebulls1885")
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(TB_TOKEN_URL, data={
            "grant_type": "password",
            "client_id": TB_CLIENT_ID,
            "client_secret": TB_CLIENT_SECRET,
            "username": username,
            "password": password,
        })
        if r.status_code not in (200, 201):
            raise HTTPException(502, f"TB auth failed: {r.status_code}")
        return r.json()["access_token"]


# ── Key dates ─────────────────────────────────────────────────────────────────

class KeyDateBody(BaseModel):
    type: str  # competition / test / camp / block_start / block_end
    date: str  # YYYY-MM-DD
    label: str
    priority: str = "normal"  # high / normal / low
    notes: str = ""


@router.get("/key-dates")
def list_key_dates():
    dates = _load(KEY_DATES_PATH, [])
    today = datetime.now().strftime("%Y-%m-%d")
    for d in dates:
        target = datetime.strptime(d["date"], "%Y-%m-%d")
        d["weeks_away"] = max(0, round((target - datetime.now()).days / 7, 1))
        d["is_past"] = d["date"] < today
    dates.sort(key=lambda d: d["date"])
    return {"key_dates": dates}


@router.post("/key-dates")
def add_key_date(body: KeyDateBody):
    dates = _load(KEY_DATES_PATH, [])
    entry = {"id": str(uuid.uuid4())[:8], **body.dict()}
    dates.append(entry)
    _save(KEY_DATES_PATH, dates)
    return {"ok": True, "id": entry["id"]}


@router.delete("/key-dates/{date_id}")
def delete_key_date(date_id: str):
    dates = _load(KEY_DATES_PATH, [])
    dates = [d for d in dates if d["id"] != date_id]
    _save(KEY_DATES_PATH, dates)
    return {"ok": True}


# ── Training blocks ───────────────────────────────────────────────────────────

class BlockBody(BaseModel):
    name: str
    phase: str  # Accumulation / Intensification / Realisation / Taper
    start_date: str
    end_date: str
    sessions_per_week: int = 3
    key_date_id: Optional[str] = None  # ref to competition key date
    targets: dict = {}  # {volume: "high", intensity: "moderate", notes: "..."}
    notes: str = ""


@router.get("/blocks")
def list_blocks():
    blocks = _load(BLOCKS_PATH, [])
    today = datetime.now().strftime("%Y-%m-%d")
    for b in blocks:
        start = datetime.strptime(b["start_date"], "%Y-%m-%d")
        end = datetime.strptime(b["end_date"], "%Y-%m-%d")
        total_weeks = max(1, round((end - start).days / 7))
        weeks_done = max(0, round((datetime.now() - start).days / 7))
        b["total_weeks"] = total_weeks
        b["week_number"] = min(weeks_done + 1, total_weeks)
        b["is_active"] = b["start_date"] <= today <= b["end_date"]
        b["is_past"] = today > b["end_date"]
    blocks.sort(key=lambda b: b["start_date"], reverse=True)
    return {"blocks": blocks}


@router.post("/blocks")
def save_block(body: BlockBody):
    blocks = _load(BLOCKS_PATH, [])
    existing_idx = next((i for i, b in enumerate(blocks) if b.get("name") == body.name), None)
    entry = {"id": str(uuid.uuid4())[:8], **body.dict()}
    if existing_idx is not None:
        entry["id"] = blocks[existing_idx]["id"]
        blocks[existing_idx] = entry
    else:
        blocks.append(entry)
    _save(BLOCKS_PATH, blocks)
    return {"ok": True, "id": entry["id"]}


@router.delete("/blocks/{block_id}")
def delete_block(block_id: str):
    blocks = _load(BLOCKS_PATH, [])
    blocks = [b for b in blocks if b["id"] != block_id]
    _save(BLOCKS_PATH, blocks)
    return {"ok": True}


# ── TB Calendars / Groups ─────────────────────────────────────────────────────

@router.get("/calendars")
def list_calendars():
    return {"calendars": TB_CALENDARS_KNOWN, "groups": TB_GROUPS_KNOWN}


# ── TB History sync ───────────────────────────────────────────────────────────

@router.post("/sync-history")
async def sync_calendar_history(calendar_id: int = 518119, weeks: int = 6):
    token = await _tb_token()
    headers = {"Authorization": f"Bearer {token}"}

    end = datetime.now()
    start = end - timedelta(weeks=weeks)

    async with httpx.AsyncClient(timeout=20) as client:
        r = await client.get(
            f"{TB_BASE}/accounts/{TB_ACCOUNT_CODE}/calendars/programming",
            params={
                "calendarId": calendar_id,
                "startDate": start.strftime("%Y-%m-%d"),
                "endDate": end.strftime("%Y-%m-%d"),
            },
            headers=headers,
        )

    if r.status_code not in (200, 201):
        raise HTTPException(502, f"TB history fetch failed: {r.status_code} {r.text[:200]}")

    data = r.json()
    assignments = data.get("assignments", []) if isinstance(data, dict) else data

    history = _load(TB_HISTORY_PATH, {})
    history[str(calendar_id)] = {
        "synced_at": datetime.now().isoformat(),
        "weeks": weeks,
        "assignments": assignments,
    }
    _save(TB_HISTORY_PATH, history)

    return {
        "ok": True,
        "calendar_id": calendar_id,
        "synced_at": history[str(calendar_id)]["synced_at"],
        "assignments_count": len(assignments),
    }


@router.get("/history/{calendar_id}")
def get_history(calendar_id: int):
    history = _load(TB_HISTORY_PATH, {})
    cal_data = history.get(str(calendar_id))
    if not cal_data:
        return {"synced": False, "assignments": []}
    return {
        "synced": True,
        "synced_at": cal_data.get("synced_at"),
        "assignments": cal_data.get("assignments", []),
    }


# ── AI week generation ────────────────────────────────────────────────────────

_GROUP_WEEK_TOOL = {
    "name": "propose_group_week",
    "description": "Propose a full week of group programming for review before pushing to TeamBuildr",
    "input_schema": {
        "type": "object",
        "properties": {
            "week_label": {"type": "string", "description": "Short label e.g. 'Accumulation Wk3'"},
            "reasoning": {
                "type": "string",
                "description": "Full periodisation rationale — why these exercises, loads, and structure for this phase/week",
            },
            "days": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "slot": {
                            "type": "string",
                            "enum": ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday"],
                        },
                        "label": {"type": "string", "description": "e.g. 'Upper Body Strength'"},
                        "focus": {"type": "string", "description": "Primary training goal for this session"},
                        "exercises": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name": {"type": "string"},
                                    "sets": {"type": "integer"},
                                    "reps": {"type": "string"},
                                    "load": {
                                        "type": "string",
                                        "description": "e.g. '75%1RM', 'RPE 7', 'BW', '70kg'",
                                    },
                                    "note": {"type": "string"},
                                    "superset_group": {"type": "string"},
                                    "type": {"type": "string", "enum": ["lift", "session_break"]},
                                    "label": {"type": "string", "description": "For session_break items only"},
                                },
                                "required": ["name", "sets", "reps"],
                            },
                        },
                    },
                    "required": ["slot", "label", "focus", "exercises"],
                },
            },
        },
        "required": ["week_label", "reasoning", "days"],
    },
}


def _build_history_summary(assignments: list) -> str:
    """Compress TB assignment history into a readable summary for the AI."""
    by_date: dict[str, list] = {}
    for a in assignments:
        date = a.get("date", "?")
        by_date.setdefault(date, []).append(a)

    lines = []
    for date in sorted(by_date.keys()):
        day_assignments = by_date[date]
        dt = datetime.strptime(date, "%Y-%m-%d")
        day_name = dt.strftime("%a %d %b")
        exercises = []
        for a in day_assignments:
            if a.get("type") == "session_break":
                continue
            ex = a.get("exercise", {})
            ex_name = ex.get("name", "?")
            sets = a.get("sets", [])
            set_count = len(sets)
            reps = sets[0].get("reps", "?") if sets else "?"
            exercises.append(f"{ex_name} {set_count}×{reps}")
        if exercises:
            lines.append(f"  {day_name}: {', '.join(exercises)}")
    return "\n".join(lines) if lines else "  No history available"


def _build_ai_system(block: Optional[dict], key_dates: list, history_summary: str) -> str:
    today = datetime.now()
    today_str = today.strftime("%A %d %B %Y")

    # Nearest upcoming competition
    upcoming_comp = None
    for kd in sorted(key_dates, key=lambda d: d["date"]):
        if kd["date"] >= today.strftime("%Y-%m-%d") and kd["type"] == "competition":
            upcoming_comp = kd
            break

    comp_info = ""
    if upcoming_comp:
        weeks_away = round((datetime.strptime(upcoming_comp["date"], "%Y-%m-%d") - today).days / 7, 1)
        comp_info = f"\nNEXT COMPETITION: {upcoming_comp['label']} on {upcoming_comp['date']} ({weeks_away} weeks away)"

    block_info = ""
    if block:
        start = datetime.strptime(block["start_date"], "%Y-%m-%d")
        week_num = max(1, round((today - start).days / 7) + 1)
        total_weeks = max(1, round((datetime.strptime(block["end_date"], "%Y-%m-%d") - start).days / 7))
        block_info = f"""
CURRENT TRAINING BLOCK:
  Name: {block['name']}
  Phase: {block['phase']}
  Week: {week_num} of {total_weeks}
  Sessions/week: {block.get('sessions_per_week', 3)}
  Targets: {json.dumps(block.get('targets', {}))}
  Notes: {block.get('notes', '')}"""

    phase_guidelines = {
        "Accumulation": "Higher volume (3-4×8-12), moderate intensity (RPE 7-8), broad exercise selection, hypertrophy focus. Emphasise exercise variety and technical development.",
        "Intensification": "Moderate volume (3-5×4-6), higher intensity (RPE 8-9), compound-focused. Strength emphasis. Begin reducing exercise variation.",
        "Realisation": "Lower volume (2-3×2-4), peak intensity (RPE 9-10). Very specific to competition demands. Max strength / power expression.",
        "Taper": "Very low volume (2-3×2-3), maintained or slightly reduced intensity. Neuromuscular priming. Maintain stimulus, eliminate fatigue.",
    }
    phase_guide = ""
    if block:
        phase_guide = f"\nPHASE GUIDELINES — {block['phase']}:\n{phase_guidelines.get(block['phase'], '')}"

    return f"""You are an elite S&C periodisation coach for Taranaki Bulls professional rugby (New Zealand).
Today: {today_str}{comp_info}{block_info}{phase_guide}

LAST {round(len(history_summary.split(chr(10))) / 1.5) if history_summary.strip() else 0} WEEKS OF GROUP PROGRAMMING:
{history_summary}

AVAILABLE EXERCISES (use ONLY these exact names — they have TeamBuildr IDs):
{json.dumps(sorted(TB_EXERCISE_IDS.keys()), indent=2)}

RUGBY S&C PRINCIPLES:
- Upper body: Push/pull balance, shoulder health is non-negotiable (face pulls, Y-T-A, external rotation)
- Lower body: Posterior chain emphasis (hip hinge, glutes), single leg work for athletic asymmetry
- Neck work every upper session (rugby contact)
- Core anti-rotation (Pallof) beats crunches
- Power: Box squats, push press, broad jumps, step ups
- Session structure: Activation → Main lifts (A/B supersets) → Accessories → Conditioning if needed
- Avoid repeating same exercise in same position >2 consecutive weeks
- Volume progression: +5-10% total sets per week within a block phase
- For session_break items: use type='session_break', label='Section Name' (e.g. 'ACTIVATION', 'MAIN LIFTS', 'ACCESSORIES')
- For exercises: use type='lift', include sets/reps/load/superset_group

Generate a training week appropriate for the current block phase and progression from the history above.
Always call propose_group_week with your complete week plan."""


class GenerateWeekBody(BaseModel):
    calendar_id: int = 518119
    calendar_name: str = "Bulls NPC Transition"
    week_start: str  # YYYY-MM-DD (must be a Monday)
    message: Optional[str] = None  # optional extra instructions from coach


@router.post("/ai/generate-week")
async def ai_generate_week(body: GenerateWeekBody):
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        raise HTTPException(500, "ANTHROPIC_API_KEY not set")

    blocks = _load(BLOCKS_PATH, [])
    key_dates = _load(KEY_DATES_PATH, [])
    history_data = _load(TB_HISTORY_PATH, {})

    today = datetime.now().strftime("%Y-%m-%d")
    active_block = next(
        (b for b in blocks if b["start_date"] <= today <= b["end_date"]),
        blocks[0] if blocks else None,
    )

    cal_history = history_data.get(str(body.calendar_id), {})
    assignments = cal_history.get("assignments", [])
    history_summary = _build_history_summary(assignments)

    system = _build_ai_system(active_block, key_dates, history_summary)

    user_msg = f"Generate a complete training week for {body.calendar_name} starting {body.week_start}."
    if body.message:
        user_msg += f" Additional instructions: {body.message}"

    client = anthropic.Anthropic(api_key=key)
    response = client.messages.create(
        model="claude-fable-5",
        max_tokens=8000,
        system=system,
        tools=[_GROUP_WEEK_TOOL],
        messages=[{"role": "user", "content": user_msg}],
    )

    text = ""
    proposed = None
    for block_content in response.content:
        if hasattr(block_content, "text"):
            text = block_content.text
        elif getattr(block_content, "type", None) == "tool_use" and block_content.name == "propose_group_week":
            proposed = block_content.input

    if not proposed:
        return {"ok": False, "message": text or "AI did not produce a week plan", "proposed": None}

    # Store as a pending group program
    group_progs = _load(GROUP_PROGS_PATH, [])
    pending_id = str(uuid.uuid4())[:8]
    entry = {
        "id": pending_id,
        "calendar_id": body.calendar_id,
        "calendar_name": body.calendar_name,
        "week_start": body.week_start,
        "week_label": proposed.get("week_label", ""),
        "generated_at": datetime.now().isoformat(),
        "reviewed": False,
        "pushed": False,
        "days": proposed.get("days", []),
        "reasoning": proposed.get("reasoning", ""),
        "block_name": active_block["name"] if active_block else None,
        "block_phase": active_block["phase"] if active_block else None,
    }
    group_progs.append(entry)
    _save(GROUP_PROGS_PATH, group_progs)

    return {
        "ok": True,
        "pending_id": pending_id,
        "message": text,
        "proposed": proposed,
    }


# ── Group programs (pending review) ──────────────────────────────────────────

@router.get("/group-programs")
def list_group_programs():
    progs = _load(GROUP_PROGS_PATH, [])
    progs.sort(key=lambda p: p.get("generated_at", ""), reverse=True)
    return {"programs": progs}


@router.delete("/group-programs/{prog_id}")
def delete_group_program(prog_id: str):
    progs = _load(GROUP_PROGS_PATH, [])
    progs = [p for p in progs if p["id"] != prog_id]
    _save(GROUP_PROGS_PATH, progs)
    return {"ok": True}


# ── Push group week to TeamBuildr ─────────────────────────────────────────────

class PushGroupWeekBody(BaseModel):
    pending_id: str
    week_start: str  # Monday YYYY-MM-DD


SLOT_TO_OFFSET = {
    "monday": 0, "tuesday": 1, "wednesday": 2,
    "thursday": 3, "friday": 4, "saturday": 5, "sunday": 6,
}


@router.post("/push-group-week")
async def push_group_week(body: PushGroupWeekBody):
    progs = _load(GROUP_PROGS_PATH, [])
    prog = next((p for p in progs if p["id"] == body.pending_id), None)
    if not prog:
        raise HTTPException(404, f"No pending program '{body.pending_id}'")

    calendar_id = prog["calendar_id"]
    monday = datetime.strptime(body.week_start, "%Y-%m-%d")

    token = await _tb_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    import re
    all_results = []
    all_errors = []

    async with httpx.AsyncClient(timeout=30) as client:
        for day in prog["days"]:
            slot = day.get("slot", "monday")
            day_date = (monday + timedelta(days=SLOT_TO_OFFSET.get(slot, 0))).strftime("%Y-%m-%d")

            letter_code = ord("A")
            group_letter_map: dict[str, str] = {}
            order = 0

            for item in day.get("exercises", []):
                order += 1

                if item.get("type") == "session_break" or "label" in item and "name" not in item:
                    payload = {
                        "type": "session_break",
                        "calendarId": calendar_id,
                        "date": day_date,
                        "order": order,
                        "title": item.get("label", item.get("name", "")),
                        "showSessionBreakItems": True,
                    }
                    r = await client.post(
                        f"{TB_BASE}/accounts/{TB_ACCOUNT_CODE}/calendars/programming",
                        headers=headers, json=payload,
                    )
                    all_results.append({
                        "date": day_date, "slot": slot,
                        "exercise": f"[break] {item.get('label', '')}",
                        "status": r.status_code, "created": r.status_code == 201,
                    })
                    continue

                ex_name = item.get("name", "")
                ex_id = TB_EXERCISE_IDS.get(ex_name)
                if not ex_id:
                    all_errors.append(f"{day_date} — No TB ID for '{ex_name}'")
                    continue

                sg = item.get("superset_group")
                if sg:
                    if sg not in group_letter_map:
                        group_letter_map[sg] = chr(letter_code)
                        letter_code += 1
                    gl = group_letter_map[sg]
                else:
                    gl = chr(letter_code)
                    letter_code += 1

                sets_count = item.get("sets", 3)
                reps_raw = str(item.get("reps", "8"))
                reps_match = re.search(r"\d+", reps_raw)
                reps = int(reps_match.group()) if reps_match else 8

                payload = {
                    "exerciseId": ex_id,
                    "type": "lift",
                    "calendarId": calendar_id,
                    "date": day_date,
                    "order": order,
                    "groupingLetter": gl,
                    "repType": "reps",
                    "repsOnly": False,
                    "eachSide": False,
                    "sets": [
                        {"setNumber": s + 1, "reps": reps, "prescribedValue": item.get("load", "")}
                        for s in range(sets_count)
                    ],
                    "additionalInfo": item.get("note", ""),
                }

                r = await client.post(
                    f"{TB_BASE}/accounts/{TB_ACCOUNT_CODE}/calendars/programming",
                    headers=headers, json=payload,
                )
                all_results.append({
                    "date": day_date, "slot": slot, "exercise": ex_name,
                    "tb_id": ex_id, "status": r.status_code, "created": r.status_code == 201,
                })

    # Mark as pushed
    for p in progs:
        if p["id"] == body.pending_id:
            p["pushed"] = True
            p["pushed_at"] = datetime.now().isoformat()
            p["pushed_week_start"] = body.week_start
    _save(GROUP_PROGS_PATH, progs)

    created = sum(1 for r in all_results if r.get("created"))
    return {
        "ok": True,
        "calendar_id": calendar_id,
        "week_start": body.week_start,
        "created": created,
        "skipped": len(all_errors),
        "results": all_results,
        "errors": all_errors,
    }


# ── AI comprehensive review ───────────────────────────────────────────────────

@router.post("/ai/review")
async def ai_review_program(calendar_id: int = 518119):
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        raise HTTPException(500, "ANTHROPIC_API_KEY not set")

    blocks = _load(BLOCKS_PATH, [])
    key_dates = _load(KEY_DATES_PATH, [])
    history_data = _load(TB_HISTORY_PATH, {})

    today = datetime.now().strftime("%Y-%m-%d")
    active_block = next(
        (b for b in blocks if b["start_date"] <= today <= b["end_date"]),
        blocks[0] if blocks else None,
    )

    cal_history = history_data.get(str(calendar_id), {})
    assignments = cal_history.get("assignments", [])
    history_summary = _build_history_summary(assignments)

    prompt = f"""Review the recent group programming history below and provide a comprehensive analysis.

RECENT PROGRAMMING:
{history_summary}

Analyse and provide specific, actionable recommendations on:
1. EXERCISE SELECTION — variety, exercise rotation, any overused patterns
2. VOLUME PROGRESSION — sets/week trajectory, appropriate loading
3. MUSCLE BALANCE — push/pull ratio, anterior/posterior balance, unilateral work
4. PERIODISATION ADHERENCE — does the programming match the block phase?
5. SHOULDER HEALTH — are we doing enough face pulls, Y-T-A, external rotation?
6. MISSING ELEMENTS — what's absent that should be there for rugby performance?
7. TOP 3 PRIORITY IMPROVEMENTS — what to change first

Be direct and specific. Name the actual exercises. Give this like a real S&C review."""

    client = anthropic.Anthropic(api_key=key)
    response = client.messages.create(
        model="claude-fable-5",
        max_tokens=4096,
        system=_build_ai_system(active_block, key_dates, history_summary),
        messages=[{"role": "user", "content": prompt}],
    )

    text = ""
    for block_content in response.content:
        if hasattr(block_content, "text"):
            text += block_content.text

    return {
        "ok": True,
        "review": text,
        "history_weeks": cal_history.get("weeks", 0),
        "synced_at": cal_history.get("synced_at"),
    }
