"""Rehab gym programs — phase tracking, 4-day programs, equipment config, TB exercise library."""
import json
import threading
from pathlib import Path
from typing import Optional

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/rehab-programs", tags=["rehab-programs"])

DATA_DIR = Path(__file__).parent.parent.parent.parent / "data"
PROGRAMS_PATH = DATA_DIR / "rehab_programs.json"
EQUIPMENT_PATH = DATA_DIR / "equipment.json"
EXERCISES_PATH = DATA_DIR / "tb_exercises.json"
_lock = threading.Lock()

PHASES = {
    "1": {"label": "Protection & Early Loading", "color": "#6B7280"},
    "2": {"label": "Strength",                   "color": "#3B82F6"},
    "2-3": {"label": "Strength → Advanced",      "color": "#8B5CF6"},
    "3": {"label": "Advanced Strengthening",     "color": "#F59E0B"},
    "4": {"label": "Power & Rugby Prep",          "color": "#EF4444"},
    "5": {"label": "Return to Play",              "color": "#10B981"},
}


def _load(path: Path, default):
    try:
        return json.loads(path.read_text()) if path.exists() else default
    except Exception:
        return default


def _save(path: Path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(path)


# ── Equipment ──────────────────────────────────────────────────────────────────

@router.get("/equipment")
def get_equipment():
    return _load(EQUIPMENT_PATH, {"items": []})


class EquipmentBody(BaseModel):
    items: list

@router.post("/equipment")
def save_equipment(body: EquipmentBody):
    with _lock:
        _save(EQUIPMENT_PATH, {"items": body.items})
    return {"ok": True}


# ── Exercise library ───────────────────────────────────────────────────────────

@router.get("/exercises")
def get_exercises(q: Optional[str] = None, type: Optional[str] = None):
    exs = _load(EXERCISES_PATH, [])
    if type:
        exs = [e for e in exs if e.get("type") == type]
    if q:
        ql = q.lower()
        exs = [e for e in exs if ql in e.get("name", "").lower()]
    return {"exercises": exs, "count": len(exs)}


# ── Programs ───────────────────────────────────────────────────────────────────

@router.get("/")
def list_programs():
    data = _load(PROGRAMS_PATH, {})
    return {
        name: {
            "injury": p.get("injury"),
            "phase":  p.get("phase"),
            "notes":  p.get("notes"),
            "surgeon": p.get("surgeon"),
            "phase_meta": PHASES.get(str(p.get("phase", "")), {}),
        }
        for name, p in data.items()
    }


@router.get("/{athlete_name}")
def get_program(athlete_name: str):
    data = _load(PROGRAMS_PATH, {})
    p = data.get(athlete_name)
    if not p:
        raise HTTPException(404, f"No program for '{athlete_name}'")
    return {**p, "phase_meta": PHASES.get(str(p.get("phase", "")), {})}


class ProgramBody(BaseModel):
    injury: Optional[str] = None
    phase: Optional[str] = None
    doi: Optional[str] = None
    surgeon: Optional[str] = None
    notes: Optional[str] = None
    program: Optional[dict] = None

@router.post("/{athlete_name}")
def save_program(athlete_name: str, body: ProgramBody):
    with _lock:
        data = _load(PROGRAMS_PATH, {})
        existing = data.get(athlete_name, {})
        existing.update({k: v for k, v in body.dict().items() if v is not None})
        data[athlete_name] = existing
        _save(PROGRAMS_PATH, data)
    return {"ok": True}


class ExerciseUpdate(BaseModel):
    day_index: int
    exercises: list

@router.patch("/{athlete_name}/day")
def update_day(athlete_name: str, body: ExerciseUpdate):
    with _lock:
        data = _load(PROGRAMS_PATH, {})
        p = data.get(athlete_name)
        if not p:
            raise HTTPException(404, f"No program for '{athlete_name}'")
        days = p.get("program", {}).get("days", [])
        if body.day_index >= len(days):
            raise HTTPException(400, "day_index out of range")
        days[body.day_index]["exercises"] = body.exercises
        p["program"]["days"] = days
        data[athlete_name] = p
        _save(PROGRAMS_PATH, data)
    return {"ok": True}
