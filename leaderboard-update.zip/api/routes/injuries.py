"""Injury tracking — log, phase advancement, restrictions, notes, resolve."""
import json
import os
import threading
import uuid
from datetime import datetime, timezone, timedelta
from pathlib import Path
from typing import Optional

import anthropic
from fastapi import APIRouter, HTTPException, BackgroundTasks
from pydantic import BaseModel

NZT = timezone(timedelta(hours=12))

router = APIRouter(prefix="/injuries", tags=["injuries"])

DATA_DIR         = Path(__file__).parent.parent.parent.parent / "data"
INJURIES_PATH    = DATA_DIR / "injuries.json"
ATHLETES_PATH    = DATA_DIR / "athletes.json"
AGENT_CONFIG_PATH = DATA_DIR / "agent_config.json"


def _today() -> str:
    return datetime.now(NZT).strftime("%Y-%m-%d")


def _load(path: Path, default):
    if not path.exists():
        return default
    try:
        return json.loads(path.read_text())
    except Exception:
        return default


def _save(path: Path, data) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(path)


def _days_since(date_str: str) -> int:
    try:
        d = datetime.strptime(date_str, "%Y-%m-%d")
        return (datetime.now(NZT).replace(tzinfo=None) - d).days
    except Exception:
        return 0


def _restrictions_summary(record: dict) -> str:
    r = record.get("restrictions", [])
    c = record.get("cleared_for", [])
    parts = []
    if r:
        parts.append("Restricted: " + ", ".join(r))
    if c:
        parts.append("Cleared: " + ", ".join(c))
    return ". ".join(parts) if parts else ""


def _sync_athlete_notes(name: str, record: dict) -> None:
    athletes = _load(ATHLETES_PATH, [])
    for a in athletes:
        if a.get("name") == name:
            summary = _restrictions_summary(record)
            injury_note = f"Phase {record.get('phase',1)} — {record.get('body_part','')} {record.get('side','')}.".strip()
            if summary:
                injury_note += " " + summary
            a["injury_notes"] = injury_note
            break
    _save(ATHLETES_PATH, athletes)


# ── Models ────────────────────────────────────────────────────────────────────

class NewInjuryBody(BaseModel):
    date_of_injury: str
    body_part: str
    side: str = "N/A"
    mechanism: str
    severity: str
    diagnosis: str = ""
    restrictions: list = []
    cleared_for: list = []
    target_rtp: str = ""
    physio: str = ""
    initial_note: str = ""

class NoteBody(BaseModel):
    text: str
    author: str = "George"

class PhaseBody(BaseModel):
    phase: int

class RestrictionsBody(BaseModel):
    restrictions: list
    cleared_for: list

class ResolveBody(BaseModel):
    outcome: str = "Full Recovery"
    note: str = ""


# ── Helpers ───────────────────────────────────────────────────────────────────

def _get_record(injuries: dict, name: str) -> Optional[dict]:
    entry = injuries.get(name, {})
    return entry.get("active")


def _enrich(name: str, record: dict) -> dict:
    return {
        **record,
        "athlete_name": name,
        "days_since_injury": _days_since(record.get("date_of_injury", record.get("date_logged", ""))),
    }


# ── Endpoints ─────────────────────────────────────────────────────────────────

@router.get("")
def list_injuries():
    injuries = _load(INJURIES_PATH, {})
    athletes = _load(ATHLETES_PATH, [])
    athlete_map = {a["name"]: a for a in athletes}

    active = []
    for name, entry in injuries.items():
        rec = entry.get("active")
        if rec:
            a = athlete_map.get(name, {})
            active.append({
                **_enrich(name, rec),
                "position": a.get("position", ""),
                "status": a.get("status", ""),
                "photo": a.get("photo", ""),
            })

    active.sort(key=lambda x: (x.get("phase", 1), x.get("days_since_injury", 0)))
    return {"injuries": active, "count": len(active)}


@router.get("/{name}")
def get_injury(name: str):
    injuries = _load(INJURIES_PATH, {})
    entry = injuries.get(name, {})
    active = entry.get("active")
    history = entry.get("history", [])
    if not active and not history:
        raise HTTPException(404, f"No injury records for {name}")
    return {
        "athlete_name": name,
        "active": _enrich(name, active) if active else None,
        "history": history,
    }


@router.post("/{name}")
def log_injury(name: str, body: NewInjuryBody, background_tasks: BackgroundTasks):
    athletes = _load(ATHLETES_PATH, [])
    athlete = next((a for a in athletes if a.get("name") == name), None)
    if not athlete:
        raise HTTPException(404, f"Athlete '{name}' not found")

    injuries = _load(INJURIES_PATH, {})
    entry = injuries.get(name, {"active": None, "history": []})

    # Archive existing active injury if present
    if entry.get("active"):
        entry.setdefault("history", []).append({
            **entry["active"],
            "archived_at": _today(),
            "outcome": "Superseded",
        })

    notes = []
    if body.initial_note:
        notes.append({
            "id": str(uuid.uuid4())[:8],
            "date": _today(),
            "author": body.author if hasattr(body, "author") else "George",
            "text": body.initial_note,
        })

    record = {
        "id": str(uuid.uuid4())[:12],
        "date_logged": _today(),
        "date_of_injury": body.date_of_injury,
        "body_part": body.body_part,
        "side": body.side,
        "mechanism": body.mechanism,
        "severity": body.severity,
        "diagnosis": body.diagnosis,
        "phase": 1,
        "restrictions": body.restrictions,
        "cleared_for": body.cleared_for,
        "target_rtp": body.target_rtp,
        "physio": body.physio,
        "notes": notes,
    }
    entry["active"] = record

    injuries[name] = entry
    _save(INJURIES_PATH, injuries)

    # Sync to athletes.json and set status to Modified Training
    _sync_athlete_notes(name, record)

    old_status = athlete.get("status", "")
    if old_status not in ("Modified Training", "Rehab", "Out"):
        athlete["status"] = "Modified Training"
        _save(ATHLETES_PATH, athletes)
        # Fire Agent 1 to draft individual program
        if old_status != "Modified Training":
            from routes.programming import draft_individual_background
            background_tasks.add_task(
                draft_individual_background,
                name,
                _restrictions_summary(record),
                athlete.get("position", ""),
            )

    return {"ok": True, "id": record["id"], "athlete": name}


@router.post("/{name}/note")
def add_note(name: str, body: NoteBody):
    injuries = _load(INJURIES_PATH, {})
    record = _get_record(injuries, name)
    if not record:
        raise HTTPException(404, f"No active injury for {name}")

    note = {
        "id": str(uuid.uuid4())[:8],
        "date": _today(),
        "author": body.author,
        "text": body.text,
    }
    record.setdefault("notes", []).append(note)
    injuries[name]["active"] = record
    _save(INJURIES_PATH, injuries)
    return {"ok": True, "note": note}


@router.patch("/{name}/phase")
def set_phase(name: str, body: PhaseBody, background_tasks: BackgroundTasks):
    if body.phase not in (1, 2, 3, 4):
        raise HTTPException(422, "Phase must be 1–4")

    injuries = _load(INJURIES_PATH, {})
    record = _get_record(injuries, name)
    if not record:
        raise HTTPException(404, f"No active injury for {name}")

    old_phase = record.get("phase", 1)
    record["phase"] = body.phase

    # Auto-update restrictions based on phase
    if body.phase == 4:
        record["restrictions"] = []
        record["cleared_for"] = ["Full Training", "Contact"]

    injuries[name]["active"] = record
    _save(INJURIES_PATH, injuries)
    _sync_athlete_notes(name, record)

    # Re-draft program when phase changes
    athletes = _load(ATHLETES_PATH, [])
    athlete = next((a for a in athletes if a.get("name") == name), {})
    if old_phase != body.phase:
        from routes.programming import draft_individual_background
        background_tasks.add_task(
            draft_individual_background,
            name,
            _restrictions_summary(record) + f" Phase {body.phase}.",
            athlete.get("position", ""),
        )

    return {"ok": True, "phase": body.phase}


@router.patch("/{name}/restrictions")
def update_restrictions(name: str, body: RestrictionsBody, background_tasks: BackgroundTasks):
    injuries = _load(INJURIES_PATH, {})
    record = _get_record(injuries, name)
    if not record:
        raise HTTPException(404, f"No active injury for {name}")

    record["restrictions"] = body.restrictions
    record["cleared_for"] = body.cleared_for
    injuries[name]["active"] = record
    _save(INJURIES_PATH, injuries)
    _sync_athlete_notes(name, record)

    athletes = _load(ATHLETES_PATH, [])
    athlete = next((a for a in athletes if a.get("name") == name), {})
    from routes.programming import draft_individual_background
    background_tasks.add_task(
        draft_individual_background,
        name,
        _restrictions_summary(record),
        athlete.get("position", ""),
    )

    return {"ok": True}


@router.post("/{name}/resolve")
def resolve_injury(name: str, body: ResolveBody):
    injuries = _load(INJURIES_PATH, {})
    entry = injuries.get(name, {})
    record = entry.get("active")
    if not record:
        raise HTTPException(404, f"No active injury for {name}")

    if body.note:
        record.setdefault("notes", []).append({
            "id": str(uuid.uuid4())[:8],
            "date": _today(),
            "author": "George",
            "text": body.note,
        })

    record["resolved_at"] = _today()
    record["outcome"] = body.outcome
    entry.setdefault("history", []).append(record)
    entry["active"] = None
    injuries[name] = entry
    _save(INJURIES_PATH, injuries)

    # Set athlete back to Full Contact
    athletes = _load(ATHLETES_PATH, [])
    for a in athletes:
        if a.get("name") == name:
            a["status"] = "Full Contact"
            a["injury_notes"] = None
            break
    _save(ATHLETES_PATH, athletes)

    return {"ok": True, "resolved_at": record["resolved_at"]}


@router.delete("/{name}/active")
def clear_active_injury(name: str):
    injuries = _load(INJURIES_PATH, {})
    entry = injuries.get(name, {})
    if not entry.get("active"):
        raise HTTPException(404, f"No active injury for {name}")
    entry["active"] = None
    injuries[name] = entry
    _save(INJURIES_PATH, injuries)
    return {"ok": True}


# ── Injury Intel Agent ─────────────────────────────────────────────────────────

def _run_injury_research(name: str, record: dict) -> None:
    """Background task: creates a Managed Agent session to research the injury
    and generate an evidence-based RTP plan. Saves result to injuries.json."""
    try:
        config = _load(AGENT_CONFIG_PATH, {})
        agent_id = config.get("injury_intel_agent_id")
        env_id   = config.get("environment_id")
        if not agent_id or not env_id:
            raise ValueError("Agent config missing — run create_agents.py first")

        key = os.environ.get("ANTHROPIC_API_KEY", "")
        if not key:
            raise ValueError("ANTHROPIC_API_KEY not set")

        client = anthropic.Anthropic(api_key=key)

        body_part  = record.get("body_part", "Unknown")
        side       = record.get("side", "N/A")
        mechanism  = record.get("mechanism", "Unknown")
        severity   = record.get("severity", "moderate")
        position   = ""
        athletes   = _load(ATHLETES_PATH, [])
        athlete    = next((a for a in athletes if a.get("name") == name), {})
        position   = athlete.get("position", "")
        notes_text = " ".join(n.get("text", "") for n in record.get("notes", []))

        prompt = (
            f"Research the following rugby injury and generate a structured return-to-play plan:\n\n"
            f"Athlete: {name} ({position})\n"
            f"Injury: {body_part}{' (' + side + ')' if side != 'N/A' else ''}\n"
            f"Mechanism: {mechanism}\n"
            f"Severity: {severity}\n"
            f"Initial notes: {notes_text or 'None provided'}\n\n"
            f"Please research this injury type specifically in professional rugby players and provide:\n"
            f"1. Evidence-based RTP timeline (best/typical/worst case)\n"
            f"2. A detailed 4-phase RTP plan with specific durations, allowed activities, "
            f"restrictions, and objective criteria for progression\n"
            f"3. Position-specific considerations for a {position}\n"
            f"4. Red flags to watch for that would extend timeline\n"
            f"5. Key sources"
        )

        session = client.beta.sessions.create(
            agent=agent_id,
            environment_id=env_id,
            title=f"{name} — {body_part} RTP Research",
        )

        client.beta.sessions.events.send(
            session.id,
            events=[{
                "type": "user.message",
                "content": [{"type": "text", "text": prompt}],
            }],
        )

        response_parts = []
        with client.beta.sessions.events.stream(session.id) as stream:
            for event in stream:
                if hasattr(event, "type"):
                    if event.type == "agent.message":
                        for block in event.content:
                            if hasattr(block, "text"):
                                response_parts.append(block.text)
                    elif event.type in ("session.status_idle", "session.status_terminated"):
                        break

        rtp_plan_text = "\n\n".join(response_parts).strip()

        injuries = _load(INJURIES_PATH, {})
        active = injuries.get(name, {}).get("active")
        if active:
            active["rtp_plan"] = rtp_plan_text
            active["rtp_plan_status"] = "complete"
            active["rtp_plan_date"] = _today()
            active["rtp_session_id"] = session.id
            injuries[name]["active"] = active
            _save(INJURIES_PATH, injuries)
            print(f"[injury-intel] RTP plan saved for {name}")

    except Exception as e:
        print(f"[injury-intel] Error researching {name}: {e}")
        injuries = _load(INJURIES_PATH, {})
        active = injuries.get(name, {}).get("active")
        if active:
            active["rtp_plan_status"] = "error"
            active["rtp_plan_error"] = str(e)
            injuries[name]["active"] = active
            _save(INJURIES_PATH, injuries)


@router.post("/{name}/research")
def start_injury_research(name: str):
    injuries = _load(INJURIES_PATH, {})
    record = _get_record(injuries, name)
    if not record:
        raise HTTPException(404, f"No active injury for {name}")

    config = _load(AGENT_CONFIG_PATH, {})
    if not config.get("injury_intel_agent_id"):
        raise HTTPException(503, "Injury Intel Agent not configured — run create_agents.py first")

    if record.get("rtp_plan_status") == "researching":
        return {"ok": False, "message": "Research already in progress"}

    record["rtp_plan_status"] = "researching"
    record["rtp_plan"] = None
    injuries[name]["active"] = record
    _save(INJURIES_PATH, injuries)

    threading.Thread(
        target=_run_injury_research,
        args=(name, record),
        daemon=True,
        name=f"injury-research-{name}",
    ).start()

    return {"ok": True, "status": "researching"}
