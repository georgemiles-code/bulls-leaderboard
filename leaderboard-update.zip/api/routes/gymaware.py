"""GymAware API — VBT (velocity-based training) leaderboard, all-time rankings.

Parallels force_lab.py but for barbell velocity/power data synced from GymAware Cloud into
gymaware_results.json. Records are per-SET (a group of reps of one exercise); each carries a
full metric set, so the board can rank on a selectable metric (mean velocity by default, or
peak power / watts-per-kg) and filter by exercise (usually banded bench, but session-varying)
without any re-sync.
"""
from __future__ import annotations  # PEP 604 `X | None` hints work on the bundled Python 3.9
import json
from datetime import date
from pathlib import Path
import os as _os

from fastapi import APIRouter

_data_env = _os.environ.get("BULLS_DATA_DIR", "")
DATA_DIR = Path(_data_env) if _data_env else Path(__file__).parent.parent.parent.parent / "data"

router = APIRouter(prefix="/gymaware", tags=["gymaware"])


# ── Metrics ──────────────────────────────────────────────────────────────────────
# All are higher-is-better. `dec` = display/rounding precision; `min_sample` gates the
# all-time-record cinematic the same way ForceDecks does (a thin sample isn't a real record).
METRICS = {
    "mean_velocity":      {"label": "Mean Velocity",  "unit": "m/s",  "dec": 2},
    "peak_velocity":      {"label": "Peak Velocity",  "unit": "m/s",  "dec": 2},
    "mean_power":         {"label": "Mean Power",     "unit": "W",    "dec": 0},
    "peak_power":         {"label": "Peak Power",     "unit": "W",    "dec": 0},
    "mean_watts_per_kg":  {"label": "Mean W/kg",      "unit": "W/kg", "dec": 2},
    "peak_watts_per_kg":  {"label": "Peak W/kg",      "unit": "W/kg", "dec": 2},
}
DEFAULT_METRIC = "mean_velocity"
# GymAware's own exerciseName for banded bench is "Bench Press (Bands)" (the web app relabels
# it "Bench Press + Bands" in its dropdown, but the API returns the parenthesised form). The
# selector default is resolved by token match (bench + band) rather than this exact string so
# it still lands on banded bench even if the exact label varies session to session.
DEFAULT_EXERCISE = "Bench Press (Bands)"
MIN_ALLTIME_SAMPLE = 8
# Velocity PBs are inherently noisy — bar speed depends on load, and with thin history at a
# fixed load nearly everyone "PBs" on a good day. So a PB badge requires BOTH a clear margin
# over the prior best AND enough prior sessions to be a genuine baseline, not a first-week fluke.
PB_MARGIN = 1.03        # must beat prior best by ≥3%
PB_MIN_SESSIONS = 3     # must have ≥3 prior sessions on this lift


def _metric(metric: str) -> str:
    return metric if metric in METRICS else DEFAULT_METRIC


def _val(record: dict, metric: str) -> float:
    return float((record.get("metrics") or {}).get(metric) or 0)


# ── Helpers (mirror force_lab.py) ─────────────────────────────────────────────────

def _load_athletes():
    try:
        return json.loads((DATA_DIR / "athletes.json").read_text())
    except Exception:
        return []


def _load_results() -> dict:
    try:
        return json.loads((DATA_DIR / "gymaware_results.json").read_text())
    except Exception:
        return {}


def _squad_athlete_ids(squad: str) -> dict[str, dict]:
    allowed = {"academy", "npc", "wtg"} if squad == "male" else {squad}
    result = {}
    for a in _load_athletes():
        extra = set(a.get("extra_squads") or [])
        if a.get("squad") in allowed or extra & allowed:
            result[str(a["id"])] = a
    return result


def _norm_ex(s: str) -> str:
    return (s or "").strip().lower()


# Forwards/Backs classification from the roster (athletes.json `position`/`positionGroup`).
# Only a fraction of the roster is classified; anyone unmatched returns "" (untagged) rather
# than being forced into a group.
_FWD_GROUPS = {"front row", "second row", "loose forwards", "loose forward"}
_BCK_GROUPS = {"insides", "outsides"}
_FWD_POS = {"forward", "prop", "loosehead prop", "tighthead prop", "hooker", "lock",
            "second row", "blindside flanker", "openside flanker", "loose forward",
            "number 8", "no 8", "flanker", "front row"}
_BCK_POS = {"back", "halfback", "halfbacks", "first five", "second five", "centre", "center",
            "left wing", "right wing", "wing", "fullback", "full back"}

def _fwd_bck(a: dict) -> str:
    pg = (a.get("positionGroup") or "").strip().lower()
    pos = (a.get("position") or "").strip().lower()
    if pg in _FWD_GROUPS or pos in _FWD_POS:
        return "FWD"
    if pg in _BCK_GROUPS or pos in _BCK_POS:
        return "BCK"
    return ""


# ── Endpoints ──────────────────────────────────────────────────────────────────

@router.get("/exercises")
def gymaware_exercises(squad: str = "male", target_date: str = ""):
    """Exercises present in the data for a squad (optionally a single date), most-used first —
    populates the board's exercise selector. Defaults the selector toward banded bench."""
    squad_ids = _squad_athlete_ids(squad)
    results = _load_results()
    counts: dict[str, int] = {}
    labels: dict[str, str] = {}
    for aid, records in results.items():
        if aid not in squad_ids:
            continue
        for r in records:
            if target_date and r.get("date") != target_date:
                continue
            ex = r.get("exercise") or "Unknown"
            key = _norm_ex(ex)
            counts[key] = counts.get(key, 0) + 1
            labels[key] = ex
    ordered = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
    exercises = [{"name": labels[k], "sets": c} for k, c in ordered]
    # Default to banded bench by token match (handles "Bench Press (Bands)" / "Bench Press +
    # Bands" / any relabel); fall back to the most-used exercise if no banded bench present.
    default = next((e["name"] for e in exercises
                    if "bench" in _norm_ex(e["name"]) and "band" in _norm_ex(e["name"])),
                   exercises[0]["name"] if exercises else DEFAULT_EXERCISE)
    return {"exercises": exercises, "default": default}


@router.get("/dates")
def gymaware_dates(squad: str = "male", exercise: str = DEFAULT_EXERCISE):
    squad_ids = _squad_athlete_ids(squad)
    results = _load_results()
    ex = _norm_ex(exercise)
    dates: set[str] = set()
    for aid, records in results.items():
        if aid not in squad_ids:
            continue
        for r in records:
            if _norm_ex(r.get("exercise")) == ex and r.get("date"):
                dates.add(r["date"])
    return {"today": date.today().isoformat(), "dates": sorted(dates, reverse=True)}


@router.get("/leaderboard")
def gymaware_leaderboard(target_date: str, squad: str = "male",
                         exercise: str = DEFAULT_EXERCISE, metric: str = DEFAULT_METRIC):
    metric = _metric(metric)
    dec = METRICS[metric]["dec"]
    squad_ids = _squad_athlete_ids(squad)
    results = _load_results()
    ex = _norm_ex(exercise)

    best_by_athlete: dict[str, dict] = {}
    all_by_athlete: dict[str, list] = {}
    for aid, records in results.items():
        if aid not in squad_ids:
            continue
        for r in records:
            if _norm_ex(r.get("exercise")) != ex or r.get("date") != target_date:
                continue
            v = _val(r, metric)
            if not v:
                continue
            all_by_athlete.setdefault(aid, []).append(r)
            prev = best_by_athlete.get(aid)
            if not prev or v > _val(prev, metric):
                best_by_athlete[aid] = r

    # PB baseline = best of this metric+exercise from any PRIOR date (whole of today excluded),
    # plus how many prior sessions (distinct dates) the athlete has on this lift — a real PB
    # needs a genuine baseline, not one earlier session.
    def _historical(aid: str) -> tuple[float, int]:
        best = 0.0
        prior_dates: set[str] = set()
        for r in results.get(aid, []):
            if _norm_ex(r.get("exercise")) != ex or r.get("date") == target_date:
                continue
            prior_dates.add(r.get("date", ""))
            best = max(best, _val(r, metric))
        return best, len(prior_dates)

    # Best on the single most-recent PRIOR session, for the "vs last session" delta.
    def _last_session_best(aid: str) -> float | None:
        by_date: dict[str, float] = {}
        for r in results.get(aid, []):
            if _norm_ex(r.get("exercise")) != ex or r.get("date") == target_date:
                continue
            d = r.get("date", "")
            by_date[d] = max(by_date.get(d, 0.0), _val(r, metric))
        if not by_date:
            return None
        return by_date[max(by_date)]

    entries = []
    for aid, r in best_by_athlete.items():
        a = squad_ids[aid]
        primary = _val(r, metric)
        pb, prior_sessions = _historical(aid)
        is_pb = prior_sessions >= PB_MIN_SESSIONS and pb > 0 and primary > pb * PB_MARGIN
        last = _last_session_best(aid)
        delta_vs_last = round(primary - last, dec) if last is not None else None
        day = sorted(all_by_athlete.get(aid, []), key=lambda x: x.get("recorded_utc", ""))
        entries.append({
            "id": int(aid),
            "name": a["name"],
            "initials": a.get("initials", a["name"][:2].upper()),
            "position_group": a.get("positionGroup", ""),
            "position": a.get("position", ""),
            "fb": _fwd_bck(a),
            "status": a.get("status", "Full Contact"),
            "primary": round(primary, dec),
            "pb": round(pb, dec) if pb else None,
            "is_pb": is_pb,
            "delta_vs_pb": round(primary - pb, dec) if pb else None,
            "delta_vs_last": delta_vs_last,
            "exercise": r.get("exercise", exercise),
            "bar_weight_kg": r.get("bar_weight_kg"),
            "rep_count": r.get("rep_count"),
            "velocity_zone": r.get("velocity_zone"),
            "metrics": r.get("metrics", {}),
            "test_id": r.get("set_id", ""),
            "recorded_utc": r.get("recorded_utc", ""),
            "recent_jumps": [round(_val(x, metric), dec) for x in day[-3:]],
        })

    entries.sort(key=lambda e: e["primary"], reverse=True)
    for i, e in enumerate(entries):
        e["rank"] = i + 1

    return {
        "date": target_date, "squad": squad, "exercise": exercise, "metric": metric,
        "unit": METRICS[metric]["unit"], "entries": entries, "count": len(entries),
        "cinematics_ok": True,
    }


@router.get("/recent")
def gymaware_recent(squad: str = "male", exercise: str = DEFAULT_EXERCISE,
                    metric: str = DEFAULT_METRIC, target_date: str = "", limit: int = 8):
    """Most recent sets across the squad for this exercise — the live 'Off the Bar' feed:
    newest first, with time, athlete, load and the selected metric value."""
    metric = _metric(metric)
    dec = METRICS[metric]["dec"]
    squad_ids = _squad_athlete_ids(squad)
    results = _load_results()
    ex = _norm_ex(exercise)
    rows = []
    for aid, records in results.items():
        if aid not in squad_ids:
            continue
        a = squad_ids[aid]
        for r in records:
            if _norm_ex(r.get("exercise")) != ex:
                continue
            if target_date and r.get("date") != target_date:
                continue
            v = _val(r, metric)
            if not v:
                continue
            rows.append({
                "id": int(aid), "name": a["name"], "initials": a.get("initials", a["name"][:2].upper()),
                "value": round(v, dec), "bar_weight_kg": r.get("bar_weight_kg"),
                "rep_count": r.get("rep_count"), "recorded_utc": r.get("recorded_utc", ""),
            })
    rows.sort(key=lambda x: x["recorded_utc"], reverse=True)
    return {"rows": rows[:limit], "unit": METRICS[metric]["unit"]}


@router.get("/athlete-history")
def gymaware_athlete_history(id: int, exercise: str = DEFAULT_EXERCISE,
                            metric: str = DEFAULT_METRIC, limit: int = 12):
    """An athlete's best value per session (date) for this exercise+metric, oldest→newest —
    powers the spotlight's progression sparkline."""
    metric = _metric(metric)
    dec = METRICS[metric]["dec"]
    ex = _norm_ex(exercise)
    by_date: dict[str, float] = {}
    for r in _load_results().get(str(id), []):
        if _norm_ex(r.get("exercise")) != ex:
            continue
        v = _val(r, metric)
        if not v:
            continue
        d = r.get("date", "")
        by_date[d] = max(by_date.get(d, 0.0), v)
    pts = [{"date": d, "value": round(by_date[d], dec)} for d in sorted(by_date)][-limit:]
    return {"points": pts}


@router.get("/all-time")
def gymaware_all_time(squad: str = "male", limit: int = 5,
                      exercise: str = DEFAULT_EXERCISE, metric: str = DEFAULT_METRIC):
    metric = _metric(metric)
    dec = METRICS[metric]["dec"]
    squad_ids = _squad_athlete_ids(squad)
    results = _load_results()
    ex = _norm_ex(exercise)

    best_by_athlete: dict[str, dict] = {}
    for aid, records in results.items():
        if aid not in squad_ids:
            continue
        for r in records:
            if _norm_ex(r.get("exercise")) != ex:
                continue
            v = _val(r, metric)
            if not v:
                continue
            prev = best_by_athlete.get(aid)
            if not prev or v > _val(prev, metric):
                best_by_athlete[aid] = r

    entries = []
    for aid, r in best_by_athlete.items():
        a = squad_ids[aid]
        entries.append({
            "id": int(aid),
            "name": a["name"],
            "initials": a.get("initials", a["name"][:2].upper()),
            "position_group": a.get("positionGroup", ""),
            "squad": a.get("squad", ""),
            "primary": round(_val(r, metric), dec),
            "exercise": r.get("exercise", exercise),
            "date": r.get("date", ""),
            "test_id": r.get("set_id", ""),
        })
    entries.sort(key=lambda e: e["primary"], reverse=True)
    for i, e in enumerate(entries):
        e["rank"] = i + 1

    return {
        "entries": entries[:limit], "total_athletes": len(entries),
        "exercise": exercise, "metric": metric, "unit": METRICS[metric]["unit"],
        "cinematics_ok": len(entries) >= MIN_ALLTIME_SAMPLE,
    }
