"""S&C Programming — Fable 5 directed rugby periodisation."""
import asyncio
import json
import os
import re
from datetime import datetime, timedelta
from pathlib import Path
from typing import Optional

import anthropic
import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/s_and_c", tags=["s_and_c"])

DATA_DIR      = Path(__file__).parent.parent.parent.parent / "data"
SQUADS_PATH   = DATA_DIR / "squads.json"
SESSIONS_PATH = DATA_DIR / "sc_sessions.json"

TB_BASE          = "https://api.teambuildr.com"
TB_TOKEN_URL     = f"{TB_BASE}/oauth/token"
TB_CLIENT_ID     = "xBLi9kmYnG6i586"
TB_CLIENT_SECRET = "xWlwYjVPKCyOkSk"
TB_ACCOUNT_CODE  = 5292

SYSTEM_PROMPT = """You are an ASCA-accredited (Level 3) S&C coach working with a New Zealand provincial rugby union academy (U20s). Your programming is grounded in ASCA's evidence-based framework, block periodisation, and the specific physical demands of rugby union.

═══════════════════════════════════════════════════════════════
NEEDS ANALYSIS — RUGBY UNION
═══════════════════════════════════════════════════════════════
Rugby union is an intermittent collision sport requiring:
  • Repeated high-intensity efforts (5-10s sprints, 20-60s recovery)
  • Collision force production AND absorption (tackles, scrums, mauls)
  • Isometric strength — scrum engagement, ruck body position
  • Reactive agility — breakdown decisions, line defence
  • Posterior chain dominance — acceleration, contact, jackal position
  • Upper body push/pull for tackle, cleanout, lineout

PRIMARY INJURY RISKS (must address in every training block):
  • Hamstrings — #1 muscle strain in rugby; eccentric deficit is the mechanism
  • ACL — landing mechanics, deceleration, fatigue-related
  • Shoulder — rotator cuff, AC joint; tackle and contact mechanics
  • Neck — contact loading; U20 neck structures still developing
  • Ankles — proprioceptive deficit post-sprain

KEY PHYSICAL QUALITIES (in order of priority for U20 development):
  1. Absolute strength — force production ceiling raises everything else
  2. Rate of force development (RFD) — how fast they access strength
  3. Posterior chain resilience — hamstring, glute, hip hinge
  4. Single-leg stability — transfer to on-field deceleration and collision
  5. Aerobic base — supports recovery between sets and between games

═══════════════════════════════════════════════════════════════
PERIODISATION FRAMEWORK — BLOCK MODEL (Issurin / ASCA Level 2)
═══════════════════════════════════════════════════════════════
ACCUMULATION (high volume, moderate intensity — build structural fitness):
  Target: muscular endurance of primary movers, movement quality, tendon loading
  Rep ranges: Power 5×5 | Strength 4×6-8 | Auxiliary 3×10-12
  Intensity: RPE 7-8, ~70-80% TM for main compounds
  Rest: 2-3 min between compound sets, 60-90s between auxiliary

INTENSIFICATION (moderate volume, high intensity — convert volume to power):
  Target: maximal strength expression, rate of force development, PAP
  Rep ranges: Power 5×3-4 | Strength 4×3-5 | Auxiliary 3×6-8
  Intensity: RPE 8-9, ~80-90% TM for main compounds
  Rest: 3-4 min between compound sets

REALISATION (low volume, peak intensity — express qualities, reduce fatigue):
  Target: peak neuromuscular output, CNS freshness for competition
  Rep ranges: Power 4×2-3 | Strength 3-4×2-3 | Auxiliary 3×5-6
  Intensity: RPE 8-9 but volume halved; quality over quantity
  Rest: 4-5 min between compound sets

═══════════════════════════════════════════════════════════════
GAME-DAY PROXIMITY RULES (GD = days until next game)
═══════════════════════════════════════════════════════════════
GD-5 (Monday — main strength session):
  Full session. This is the primary training stimulus of the week.
  Power component first (PAP, alactic ATP). Then absolute strength.
  Volume: per phase targets above. Fatigue is acceptable — 5 days to recover.

GD-3 (Wednesday — power / speed emphasis):
  Reduced volume (~60-70% of Mon volume). Quality over quantity.
  Power and speed-strength only. No heavy grinding sets.
  Upper body pulling to complement Mon lower body loading.
  Do NOT add new exercises or chase fatigue.

GD-2 (Thursday — activation only, max 20 minutes):
  Field training is the priority. Gym is just CNS priming.
  2-3 exercises MAXIMUM. No compound loading. No soreness risk.
  Choose: explosive primers (box jump, broad jump), isometrics, or mobility.
  Anything that makes the athlete feel faster and sharper, not tired.

No game week (intro / bye):
  Add 1 extra set to main compounds. Use as a technical reset week.
  Introduce new exercises from the block's exercise selection.
  Prioritise movement quality. Good week to raise 1RMs or test.

═══════════════════════════════════════════════════════════════
EXERCISE SELECTION HIERARCHY (ASCA Principle: multi-joint before single-joint)
═══════════════════════════════════════════════════════════════
TIER 1 — Foundation (must anchor each session appropriately):
  Lower power:    KB Swing, Box Drop and Jump, Hang Power Clean, Broad Jump, Box Jump
  Lower strength: Front Squat, Trap Bar DL, nzr_back squat
  Upper strength: BB Push Press, Barbell Bent Over Row

TIER 2 — Posterior chain / injury prevention (include every session):
  Nordic Curl        — highest evidence base for hamstring injury prevention (Petersen et al.)
  BB Hip Thrust      — glute max strength, hip extension power
  B Stance DB RDL    — unilateral posterior chain, hamstring length under load
  SL Hip Thrust      — single-leg glute isolation

TIER 3 — Single leg / stability (include in accumulation, reduce in realisation):
  Bulgarian Split Squat — unilateral quad/glute, hip stability
  nzr_bb step up        — single-leg strength transfer

TIER 4 — Upper body auxiliary:
  nzr_weighted chin      — pulling strength, shoulder health
  Seated Row             — scapular retraction, mid-back
  DB Bench Press         — horizontal push (less shoulder stress than BB)
  Incline DB Bench Press — upper chest, shoulder pressing

TIER 5 — Core / neck (non-negotiable for rugby):
  Copenhagen Plank               — adductor/core stability, groin injury prevention
  Pallof Press                   — anti-rotation, tackle posture
  Half-Kneeling Landmine Rotation — rotational power transfer
  Isometric Squat Hold           — positional strength for scrum/lineout
  4 Way Neck Isometric           — ALWAYS include in U20s (developing cervical structures)

TIER 6 — PTT warm-up (preparation, not training load):
  Glute Bridge, Spanish Squat ISO, Band Pull Apart, Banded Hip Walk, T-Spine Rotation

═══════════════════════════════════════════════════════════════
SUPERSET STRUCTURE (triple superset format)
═══════════════════════════════════════════════════════════════
Session order: PTT section → Main Session section → (optional) Accessory section

Each superset group [A], [B], [C]:
  [Letter]1 = Highest CNS demand — power OR heaviest compound FIRST
  [Letter]2 = Complementary — different dominant chain, different fatigue signature
  [Letter]3 = Slow/iso/eccentric — athlete recovers CNS while doing quality work

PAIRING RULES (ASCA evidence-based):
  ✓ PAP pairing: Heavy compound → plyometric (e.g. Front Squat A1 → Box Drop and Jump A2)
  ✓ Push/pull: horizontal push paired with horizontal pull
  ✓ Anterior/posterior: squat pattern paired with hip hinge
  ✗ NEVER two high-CNS exercises in same superset (KB Swing + Back Squat = both posterior, both explosive = overloads that system)
  ✗ NEVER two exercises with same fatigue signature (KB Swing + BB Hip Thrust = both hip extension power)
  ✗ Nordic Curl pairs well with a quad-dominant exercise (different chain, slow eccentric recovers CNS)

═══════════════════════════════════════════════════════════════
LOAD PRESCRIPTION — ASCA STANDARD (specific, never vague)
═══════════════════════════════════════════════════════════════
Power (ballistic/Olympic):
  → Specific kg + intent: "32kg — max bar speed, full hip snap, reset each rep"
  → Or % of power clean max: "75% PC — velocity priority, no grind"

Main compounds (strength zone):
  → % of training max (TM) when known: "82.5% TM — last rep technically hard"
  → RPE when TM unknown: "RPE 8 — could do 1 more rep, form doesn't break"
  → Never write just "heavy" or "moderate"

Eccentric/isometric:
  → BW + tempo: "BW — 3s eccentric, controlled descent to floor"
  → Duration: "30s — max tension, neutral spine throughout"

Auxiliary:
  → Specific kg or RPE: "20kg — RPE 7, 3 reps in reserve"

═══════════════════════════════════════════════════════════════
PROGRESSION LOGIC (wave loading, ASCA Level 2)
═══════════════════════════════════════════════════════════════
Week-to-week within accumulation: volume wave (4×8 → 4×6 → 4×5) then intensity jump
Week-to-week within intensification: intensity wave (80% → 85% → 87.5%)
Load progression triggers: all sets completed with clean form → +5kg lower, +2.5kg upper
Deload trigger: same weight failed two sessions in a row → hold load, note it in the WHY

═══════════════════════════════════════════════════════════════
RUGBY-SPECIFIC NOTE REQUIREMENT (per exercise — mandatory)
═══════════════════════════════════════════════════════════════
Every exercise must have ONE specific note that answers: "why does a rugby player need this?"
The note must reference a rugby action, injury mechanism, or physiological rationale.
Maximum 12 words. No generic fitness phrases.

GOOD notes:
  "Alactic ATP primer — hip power for contact and jackal position"
  "Nordic: highest evidence eccentric load to prevent rugby hamstring tears"
  "Copenhagen: adductor resilience for change-of-direction and groin in contact"
  "4-Way Neck ISO: U20 cervical loading tolerance — collision preparation"
  "Pallof: anti-rotation for tackle, ruck body position under load"

BAD notes (do not use):
  "Great compound movement for overall strength" — no rugby context
  "Builds muscle and strength" — meaningless
  "Important for athletes" — filler

═══════════════════════════════════════════════════════════════
OUTPUT FORMAT — JSON array only. No text before or after the array.
═══════════════════════════════════════════════════════════════
Every item is either a session break or an exercise:

Session break: {"type": "session_break", "label": "PTT"}
Exercise:      {"superset_group": "A", "name": "KB Swing", "sets": 5, "reps": "5", "load": "32kg — max bar speed", "note": "Alactic ATP — posterior chain power for contact and jackal"}
Solo exercise: {"superset_group": null, "name": "Glute Bridge", "sets": 2, "reps": "15", "load": "BW", "note": "Glute activation before compound hip and knee loading"}

Example full output structure:
[
  {"type": "session_break", "label": "PTT"},
  {"superset_group": null, "name": "Glute Bridge", "sets": 2, "reps": "15", "load": "BW", "note": "Glute activation — switches on posterior chain before compound loading"},
  {"superset_group": null, "name": "Banded Hip Walk", "sets": 2, "reps": "10 each way", "load": "Medium band", "note": "Glute med switch-on — single-leg stability and hip abductor resilience"},
  {"superset_group": null, "name": "Band Pull Apart", "sets": 2, "reps": "15", "load": "Light band", "note": "Scapular retraction — shoulder health before upper pressing"},
  {"type": "session_break", "label": "Main Session"},
  {"superset_group": "A", "name": "KB Swing", "sets": 5, "reps": "5", "load": "32kg — max velocity, full hip snap", "note": "Alactic ATP prime — hip extension power for contact, tackle drive"},
  {"superset_group": "A", "name": "Front Squat", "sets": 4, "reps": "6", "load": "RPE 8 — last rep technically hard", "note": "Absolute strength — scrum drive and lineout lifting force production"},
  {"superset_group": "A", "name": "Nordic Curl", "sets": 4, "reps": "4", "load": "BW — 3s eccentric, controlled descent", "note": "Petersen et al. — highest evidence eccentric load for rugby hamstring"},
  {"superset_group": "B", "name": "BB Push Press", "sets": 3, "reps": "5", "load": "RPE 7-8", "note": "Triple extension power — lineout lifting, tackle completion overhead"},
  {"superset_group": "B", "name": "Barbell Bent Over Row", "sets": 3, "reps": "8", "load": "RPE 7", "note": "Scapular strength — tackle wrap, ruck body position"},
  {"superset_group": "B", "name": "Copenhagen Plank", "sets": 3, "reps": "20s each side", "load": "BW", "note": "Adductor resilience — groin protection for tackle and COD"},
  {"superset_group": "C", "name": "4 Way Neck Isometric", "sets": 3, "reps": "10s each direction", "load": "Manual resistance", "note": "Cervical loading tolerance — U20 neck preparation for collision"}
]"""


def _load(path: Path, default):
    try:
        return json.loads(path.read_text()) if path.exists() else default
    except Exception:
        return default


def _save(path: Path, data):
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(path)


async def _tb_token() -> str:
    username = os.getenv("TEAMBUILDR_USERNAME", "george@trfu.co.nz")
    password = os.getenv("TEAMBUILDR_PASSWORD", "Gothebulls1885")
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(TB_TOKEN_URL, data={
            "grant_type": "password", "client_id": TB_CLIENT_ID,
            "client_secret": TB_CLIENT_SECRET, "username": username, "password": password,
        })
        if r.status_code not in (200, 201):
            raise HTTPException(502, f"TB auth failed: {r.status_code}")
        return r.json()["access_token"]


def _next_game(games: list, from_date: str) -> Optional[dict]:
    upcoming = [g for g in games if g["date"] >= from_date]
    return min(upcoming, key=lambda g: g["date"]) if upcoming else None


def _gd_context(game_date: Optional[str], slot: str, week_start: str) -> dict:
    offsets = {"monday": 0, "tuesday": 1, "wednesday": 2, "thursday": 3, "friday": 4, "saturday": 5, "sunday": 6}
    session_date = datetime.strptime(week_start, "%Y-%m-%d") + timedelta(days=offsets.get(slot, 0))
    if not game_date:
        return {"gd": None, "session_type": "general"}
    days = (datetime.strptime(game_date, "%Y-%m-%d") - session_date).days
    if days <= 0:
        return {"gd": None, "session_type": "post_game"}
    if days == 2:
        return {"gd": 2, "session_type": "activation"}
    if days == 3:
        return {"gd": 3, "session_type": "power"}
    return {"gd": days, "session_type": "main"}


def _auto_phase(week_num: int, total_weeks: int) -> str:
    ratio = week_num / total_weeks
    if ratio <= 0.5:
        return "accumulation"
    if ratio <= 0.83:
        return "intensification"
    return "realisation"


@router.get("/squads")
def get_squads():
    return _load(SQUADS_PATH, {})


@router.get("/sessions/{squad_id}/{week_start}")
def get_week_sessions(squad_id: str, week_start: str):
    sessions = _load(SESSIONS_PATH, {})
    week = sessions.get(squad_id, {}).get(week_start, {})
    squads = _load(SQUADS_PATH, {})
    squad = squads.get(squad_id, {})
    block = squad.get("block", {})

    try:
        start = datetime.strptime(block.get("start_date", "2026-07-20"), "%Y-%m-%d")
        week_start_obj = datetime.strptime(week_start, "%Y-%m-%d")
        week_num = max(1, ((week_start_obj - start).days // 7) + 1)
    except Exception:
        week_num = 1

    total_weeks = block.get("total_weeks", 6)
    games = block.get("games", [])
    next_game = _next_game(games, week_start)
    phase = _auto_phase(week_num, total_weeks)

    return {
        "squad_id": squad_id,
        "squad_name": squad.get("name", squad_id),
        "week_start": week_start,
        "week_number": week_num,
        "total_weeks": total_weeks,
        "block_name": block.get("name", ""),
        "phase": phase,
        "next_game": next_game,
        "gym_days": squad.get("gym_days", ["monday", "wednesday", "thursday"]),
        "sessions": week,
    }


class GenerateBody(BaseModel):
    squad_id: str
    week_start: str
    slot: str
    extra_context: Optional[str] = None
    previous_loads: Optional[dict] = None


@router.post("/generate")
async def generate_session(body: GenerateBody):
    squads = _load(SQUADS_PATH, {})
    squad = squads.get(body.squad_id)
    if not squad:
        raise HTTPException(404, f"Squad '{body.squad_id}' not found")

    block = squad["block"]
    games = block.get("games", [])
    next_game = _next_game(games, body.week_start)
    gd = _gd_context(next_game["date"] if next_game else None, body.slot, body.week_start)

    try:
        start = datetime.strptime(block["start_date"], "%Y-%m-%d")
        week_start_obj = datetime.strptime(body.week_start, "%Y-%m-%d")
        week_num = max(1, ((week_start_obj - start).days // 7) + 1)
    except Exception:
        week_num = 1

    total_weeks = block.get("total_weeks", 6)
    phase = _auto_phase(week_num, total_weeks)
    week_end = (datetime.strptime(body.week_start, "%Y-%m-%d") + timedelta(days=6)).strftime("%Y-%m-%d")
    game_this_week = next_game and body.week_start <= next_game["date"] <= week_end
    is_intro = week_num == 1 and not game_this_week

    lines = [
        f"Generate a complete gym session for a U20s rugby team.",
        f"",
        f"BLOCK CONTEXT:",
        f"  Phase: {phase.upper()} — Week {week_num} of {total_weeks}",
        f"  Session: {body.slot.upper()} gym session",
        f"  Game day: {'GD-' + str(gd['gd']) + ' (' + gd['session_type'] + ')' if gd['gd'] else 'No game this week'}",
    ]

    if next_game:
        lines += [
            f"",
            f"NEXT GAME: {next_game['opponent']} — {next_game['date']} ({next_game.get('location', '')})",
        ]

    if is_intro:
        lines.append(f"NOTE: Intro week — no game. Higher volume, establish technique, introduce block lifts.")

    if body.previous_loads:
        lines.append(f"")
        lines.append(f"PREVIOUS LOADS (progress from these):")
        for ex, d in body.previous_loads.items():
            lines.append(f"  {ex}: {d.get('load', '?')} — {d.get('notes', '')}")

    if body.extra_context:
        lines += [f"", f"COACH NOTE: {body.extra_context}"]

    lines += [f"", f"Output JSON array only. Be specific with loads. Include note (WHY) for every exercise."]

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    if not api_key:
        raise HTTPException(500, "ANTHROPIC_API_KEY not set")

    prompt_text = "\n".join(lines)

    def _call_fable():
        client = anthropic.Anthropic(api_key=api_key)
        return client.messages.create(
            model="claude-fable-5",
            max_tokens=4096,
            system=SYSTEM_PROMPT,
            messages=[{"role": "user", "content": prompt_text}],
        )

    loop = asyncio.get_event_loop()
    msg = await loop.run_in_executor(None, _call_fable)

    text_block = next((b for b in msg.content if hasattr(b, 'text')), None)
    if not text_block:
        raise HTTPException(500, "AI returned no text content")
    raw = text_block.text.strip()
    match = re.search(r'\[[\s\S]*\]', raw)
    if not match:
        raise HTTPException(500, "AI returned invalid format")

    exercises = json.loads(match.group())

    sessions = _load(SESSIONS_PATH, {})
    sessions.setdefault(body.squad_id, {}).setdefault(body.week_start, {})[body.slot] = {
        "generated_at": datetime.now().isoformat(),
        "phase": phase,
        "week_number": week_num,
        "gd": gd["gd"],
        "session_type": gd["session_type"],
        "exercises": exercises,
        "pushed": False,
        "logged_loads": {},
    }
    _save(SESSIONS_PATH, sessions)

    return {
        "ok": True,
        "slot": body.slot,
        "phase": phase,
        "week_number": week_num,
        "gd": gd["gd"],
        "session_type": gd["session_type"],
        "exercises": exercises,
    }


class LogBody(BaseModel):
    squad_id: str
    week_start: str
    slot: str
    loads: dict


@router.post("/log")
def log_session(body: LogBody):
    sessions = _load(SESSIONS_PATH, {})
    slot_data = sessions.get(body.squad_id, {}).get(body.week_start, {}).get(body.slot)
    if not slot_data:
        raise HTTPException(404, "Session not found — generate it first")
    slot_data["logged_loads"] = body.loads
    slot_data["logged_at"] = datetime.now().isoformat()
    _save(SESSIONS_PATH, sessions)
    return {"ok": True}


class PatchSquadBody(BaseModel):
    block: Optional[dict] = None
    gym_days: Optional[list] = None
    tb_calendar_id: Optional[int] = None


@router.patch("/squads/{squad_id}")
def patch_squad(squad_id: str, body: PatchSquadBody):
    squads = _load(SQUADS_PATH, {})
    if squad_id not in squads:
        raise HTTPException(404, f"Squad '{squad_id}' not found")
    if body.block:
        squads[squad_id]["block"].update(body.block)
    if body.gym_days is not None:
        squads[squad_id]["gym_days"] = body.gym_days
    if body.tb_calendar_id is not None:
        squads[squad_id]["tb_calendar_id"] = body.tb_calendar_id
    _save(SQUADS_PATH, squads)
    return squads[squad_id]
