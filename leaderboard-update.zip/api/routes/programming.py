"""Programming tab backend — periodisation view + TeamBuildr push + AI coach."""
import json
import os
from datetime import datetime
from pathlib import Path
from typing import Optional

import anthropic
import httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter(prefix="/programming", tags=["programming"])

DATA_DIR              = Path(__file__).parent.parent.parent.parent / "data"
PROGRAMS_PATH         = DATA_DIR / "rehab_programs.json"
ATHLETES_PATH         = DATA_DIR / "athletes.json"
PENDING_PATH          = DATA_DIR / "pending_programs.json"
TB_HISTORY_PATH       = DATA_DIR / "tb_history.json"
BLOCKS_PATH           = DATA_DIR / "training_blocks.json"
KEY_DATES_PATH        = DATA_DIR / "key_dates.json"
TB_CUSTOM_IDS_PATH    = DATA_DIR / "tb_custom_exercise_ids.json"

TB_BASE = "https://api.teambuildr.com"
TB_TOKEN_URL = f"{TB_BASE}/oauth/token"
TB_CLIENT_ID = "xBLi9kmYnG6i586"
TB_CLIENT_SECRET = "xWlwYjVPKCyOkSk"
TB_ACCOUNT_CODE = 5292

# TeamBuildr exercise ID lookup — NZR custom + standard exercises
TB_EXERCISE_IDS: dict[str, int] = {
    # Upper — activation
    "Band Pull Apart": 2291775,
    "DB Single Arm External Rotation": 2614840,
    "Serratus Wall Slides": 3922179,
    "Banded Y-T-A": 33055076,
    # Upper — push
    "nzr_bb bench press": 14918540,
    "BB Push Press": 1296715,
    "Incline DB Bench Press": 1279646,
    "Alternating Incline DB Bench Press": 2122239,
    "L-Sit DB Press": 28790571,
    # Upper — pull
    "nzr_bench pull": 14918546,
    "nzr_weighted chin": 14918544,
    "Lat Pull Down Wide Grip": 9603847,
    "Single Arm Dumbbell Row": 1279530,
    # Upper — shoulder/arms
    "1/2 Kneeling Cable Face Pull": 1280030,
    "Tricep Pushdown": 2410163,
    "DB Bicep Curl": 1383388,
    # Neck
    "4 Way Neck Isometric": 10694560,
    # Core
    "Kneeling Pallof Press": 1279637,
    # Groin / hip adductor
    "Bent Knee Copenhagen Plank": 15041581,
    # Lower
    "Spanish Squat ISO": 32506364,
    "Leg Press": 2615934,
    "BB Hip Thrust": 3453958,
    "BW Bulgarian Split Squat": 9115607,
    "B Stance DB RDL": 10069899,
    "Banded TKE Step Up": 30124273,
    "Bent knee single leg calf raise": 5365082,
    "nzr_box squat": 14918527,
    "2:1 Calf Raise": 5997700,
    "DB Step Up": 1819690,
    "Y Balance": 29119665,
    # Upper — shoulder
    "DB Shoulder Press": 1370992,
    # Brayden — Tue/Thu/Fri
    "Pallof Press Rotations": 1279637,
    "Bench Medball Leg Lowers": 3453958,
    "Seated DB Calf Raise": 5997700,
    "1/2 Kneeling Banded Face Pull": 1280030,
    "Leg Press Calf Raises": 5365082,
    "DB Hammer Curl": 1383388,
    "DB RDL": 10069899,
    "Banded TKE": 30124273,
    # Brayden — lower body
    "Bulgarian Split Squat": 9115607,          # BW Bulgarian Split Squat
    "Side-Lying Hip Abduction": 29622425,      # Side Lying Hip Abduction
    "Banded Hip Abduction": 28742172,          # Banded Hip Abductions
    "SL Calf Raise": 2559011,                  # Single Leg Calf Raise
    "SL Seated DB Calf Raise": 2236733,        # Seated DB Calf Raise
    "DL Pogos on Weight Plate": 31160692,      # Double Leg Plate Pogo
    # Brayden — PTT balance
    "SL Balance": 5838910,                     # Single Leg Balance
    "Star Excursion Balance": 5838910,         # Single Leg Balance (closest in TB)
    "Bosu Lateral Up and Overs": 18569796,     # Bosu Balance + Lateral Raise (closest in TB)
    # Kava Vainikolo — PTT
    "Incline IYT": 9073028,              # Lying IYT — closest available
    "1/2 Kneeling T-Spine Rotation": 23057500,
    "Adductor Rock Back": 33057115,
    # Kava — plyometrics
    "nzr_bb step up": 14918529,
    "Double leg broad jump to SL land": 1279728,   # Broad Jumps
    "Lateral hop and hold": 12323765,              # Lateral Hop to Single Leg Balance
    "SL depth drop to SL land": 3502221,           # Single Leg Depth Drop and Stick
    # Kava — ankle rehab
    "Banded ankle dorsiflexion": 31780583,         # Banded Dorsi Flexion
    "Banded ankle eversion": 31534898,             # Banded Ankle Eversion
    "Standing SL Calf Raise": 2559011,             # Single Leg Calf Raise
    "Seated SL Calf Raise": 5418290,               # DB SL Calf Raise
    "Lateral hip lock step up": 28937173,          # Plate Hip Lock Step Up
    # Kava — main session
    "DB Chest Fly": 3278797,
    "Barbell Bent Over Row": 2236702,
    "1/2 Kneeling DB Shoulder Press": 28790505,    # ½ Kneeling DB Shoulder Press
    "Banded Front Neck Iso + Plyo": 3453950,       # Banded Neck Iso — closest
    # Kava — conditioning
    "Wattbike": 1475722,
    # Lower — machine (seated)
    "Leg Extension": 4571964,
    "Hamstring Single leg machine curl": 11024814,
    # Solo Mailulu — ankle rehab + cross-education
    "Overcoming Isometric Calf Raise": 24389186,  # isometric plantarflexion (boot on)
    "Banded Ankle Eversion": 31534898,            # capitalized — contralateral eversion
    "Single Leg Hip Thrust": 1280729,             # L leg posterior chain (cross-education)
    "Alternating DB Shoulder Press": 1298648,
    "Neutral Grip Chin Ups": 2378025,
    "Seated Row": 1279649,                        # Seated Cable Row
    "Long Sitting Hip Flexor Lift": 14988755,     # Hip Flexor Rehab (closest in TB)
    # Isileli Tuutafaiva — groin/hip rehab
    "Isometric Adductor Squeeze": 24634732,       # Serner 2020 — safe day 1
    "Glute Bridge": 1279689,                      # hip extension, gluteal:adductor ratio
    "Glute Clams": 9177886,                       # gluteus medius isolation
    # Zebby Uini-Faiva — postural / rounded shoulders
    "Wide Grip Seated Row": 1298141,              # TB: Wide Grip Seated Row
    "DB Rear Delt Fly": 1279527,                  # TB: DB Rear Deltoid Fly
    # New athletes — compound / power
    "nzr_trap bar deadlift": 14918524,            # TB: nzr_trapbar deadlift
    "KB Swing": 1279661,                          # TB: KB Swings
    "Box Jump": 2367609,
    "Front Squat": 14918522,                      # TB: nzr_front squat
    "Nordic Curl": 1279581,
    "Half-Kneeling Landmine Rotation": 28551626,  # TB: ½ Kneeling Landmine Rotation
    "Lateral Bound": 2241457,                     # TB: MB Lateral Bound
    "Pallof Press": 1279637,                      # map to Kneeling Pallof Press
    "Landmine Anti-Rotation Press": 1279637,      # map to Kneeling Pallof Press
    "Landmine Single Arm Row": 19123447,          # TB: SA Landmine Row
    "Isometric Squat Hold": 17186311,             # TB: Isometric Pin Squat
    # New athletes — accessory / rehab
    "SL Hip Thrust": 1280729,                     # TB: Single Leg Hip Thrust
    "DB Rear Delt Row": 1279527,                  # map to DB Rear Delt Fly
    "SL Balance (Eyes Open)": 5838910,
    "SL Balance (Eyes Closed)": 5838910,
    "Banded Hip Walk": 13868432,                  # TB: Mini band lateral walks
    # Banded Inversion intentionally omitted — auto-create as correct TP exercise
    "Lateral SL Hop Over Line": 5187628,          # TB: 1 Leg Line Hop
    # Sam McIntosh Monday (user-built in TB)
    "nzr_back squat": 14918521,
    "Plate Squat Sit": 30222804,
    "Olympic Lift": 11250063,
    "Pallof Press & Raise": 2122226,
    # Daniel Rona — global TB exercises (400 on create = already exist)
    "Banded Row": 21083756,
    "BB Bulgarian Split Squat": 14918528,
    "Copenhagen": 9999731,
    "DB Bench Press": 20128779,
    "Lat Pulldown": 1279672,
    # Hemopo Cunningham — created or mapped
    "Face Pull": 33481591,
    "DB Lateral Raise Seated": 33481601,
    "DB Seated Shrug": 33481594,
    "Seated Hamstring Curl Machine": 33481602,
    "Rear Delt Row": 33481596,
    "Battle Ropes": 33481597,
    "Assault Bike": 33481598,
    "Ski Erg": 33481599,
    "Trap 3 Raise": 33481600,
    "Dead Bug Hold": 33488664,
    "Reformer Kneeling Adduction": 33489298,
    "Lying Hip Abduction + Leg Straighten": 33488166,
    "Single Leg Glute Bridge": 33488656,
    "Hip Abduction Machine": 33488658,
}

# Merge any auto-created exercise IDs (persisted across restarts)
def _merge_custom_ids() -> None:
    if TB_CUSTOM_IDS_PATH.exists():
        try:
            TB_EXERCISE_IDS.update(json.loads(TB_CUSTOM_IDS_PATH.read_text()))
        except Exception:
            pass

_merge_custom_ids()


def _load(path: Path, default):
    try:
        return json.loads(path.read_text()) if path.exists() else default
    except Exception:
        return default


async def _tb_token() -> str:
    username = os.getenv("TEAMBUILDR_USERNAME", "george@trfu.co.nz")
    password = os.getenv("TEAMBUILDR_PASSWORD", "Gothebulls1885")
    async with httpx.AsyncClient(timeout=15) as client:
        r = await client.post(TB_TOKEN_URL, data={
            "grant_type": "password",
            "client_id": TB_CLIENT_ID,
            "client_secret": TB_CLIENT_SECRET,
            "username": username,
            "password": password,
        })
        if r.status_code not in (200, 201):
            raise HTTPException(502, f"TeamBuildr auth failed: {r.status_code} {r.text[:200]}")
        return r.json()["access_token"]


@router.get("/")
def list_athletes():
    data = _load(PROGRAMS_PATH, {})
    return {
        name: {
            "injury": p.get("injury"),
            "phase": p.get("phase"),
            "notes": p.get("notes"),
            "tb_user_id": p.get("tb_user_id"),
            "periodisation": p.get("periodisation", {}),
        }
        for name, p in data.items()
    }


@router.get("/{athlete_name}")
def get_athlete_program(athlete_name: str):
    data = _load(PROGRAMS_PATH, {})
    p = data.get(athlete_name)
    if not p:
        raise HTTPException(404, f"No program for '{athlete_name}'")
    return p


class SaveProgramBody(BaseModel):
    days: list[dict]


@router.put("/{athlete_name}")
def save_athlete_program(athlete_name: str, body: SaveProgramBody):
    data = _load(PROGRAMS_PATH, {})
    if athlete_name not in data:
        raise HTTPException(404, f"No program for '{athlete_name}'")
    data[athlete_name]["program"]["days"] = body.days
    tmp = PROGRAMS_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(PROGRAMS_PATH)
    return {"ok": True}


class PushDayBody(BaseModel):
    athlete_name: str
    day_index: int
    date: str  # YYYY-MM-DD


class SessionResultsBody(BaseModel):
    date: str
    results: dict  # {exercise_name: {weight: str, notes: str}}


@router.put("/{athlete_name}/session-results")
def save_session_results(athlete_name: str, body: SessionResultsBody):
    data = _load(PROGRAMS_PATH, {})
    if athlete_name not in data:
        raise HTTPException(404, f"No program for '{athlete_name}'")
    sr = data[athlete_name].setdefault("session_results", {})
    sr[body.date] = body.results
    tmp = PROGRAMS_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(PROGRAMS_PATH)
    return {"ok": True}


@router.post("/push-to-teambuildr")
async def push_day_to_teambuildr(body: PushDayBody):
    data = _load(PROGRAMS_PATH, {})
    p = data.get(body.athlete_name)
    if not p:
        raise HTTPException(404, f"No program for '{body.athlete_name}'")

    tb_user_id = p.get("tb_user_id")
    if not tb_user_id:
        raise HTTPException(400, f"No TeamBuildr user ID for '{body.athlete_name}'")

    days = p.get("program", {}).get("days", [])
    if body.day_index >= len(days):
        raise HTTPException(400, "day_index out of range")

    day = days[body.day_index]
    all_items = day.get("exercises", [])

    token = await _tb_token()
    headers = {"Authorization": f"Bearer {token}", "Content-Type": "application/json"}

    results = []
    errors = []

    import re

    # Pre-compute grouping letters — only for lift exercises
    group_letter_map: dict[str, str] = {}
    letter_code = ord("A")

    # Load stored assignedIds for upsert
    stored_ids: list[int] = p.get("tb_pushes", {}).get(body.date, [])
    updated_count = 0
    push_order = 0  # global order counter across all items

    async with httpx.AsyncClient(timeout=15) as client:
        new_assigned_ids: list[int] = []

        for item in all_items:
            push_order += 1
            existing_aid = stored_ids[push_order - 1] if (push_order - 1) < len(stored_ids) else None

            # ── Session break ──────────────────────────────────────────────────
            if item.get("type") == "session_break":
                payload = {
                    "type": "session_break",
                    "userId": tb_user_id,
                    "date": body.date,
                    "order": push_order,
                    "title": item.get("label", ""),
                    "showSessionBreakItems": True,
                }
                if existing_aid:
                    r = await client.put(
                        f"{TB_BASE}/accounts/{TB_ACCOUNT_CODE}/calendars/programming/{existing_aid}",
                        headers=headers, json=payload,
                    )
                    if r.status_code == 200:
                        results.append({"exercise": f"[break] {item.get('label')}", "tb_id": 0, "status": 200, "created": False, "assigned_id": existing_aid})
                        new_assigned_ids.append(existing_aid)
                        updated_count += 1
                        continue
                r = await client.post(
                    f"{TB_BASE}/accounts/{TB_ACCOUNT_CODE}/calendars/programming",
                    headers=headers, json=payload,
                )
                aid = r.json().get("assignedId", 0) if r.status_code == 201 else 0
                results.append({"exercise": f"[break] {item.get('label')}", "tb_id": 0, "status": r.status_code, "created": r.status_code == 201, "assigned_id": aid})
                new_assigned_ids.append(aid)
                continue

            # ── Regular lift ───────────────────────────────────────────────────
            ex_name = item.get("name", "")
            ex_id = TB_EXERCISE_IDS.get(ex_name)
            if not ex_id:
                # Auto-create the exercise in TeamBuildr
                cr = await client.post(
                    f"{TB_BASE}/accounts/{TB_ACCOUNT_CODE}/exercises",
                    headers=headers,
                    json={"name": ex_name, "type": "L"},
                )
                if cr.status_code == 200:
                    ex_id = cr.json().get("id", 0)
                    if ex_id:
                        TB_EXERCISE_IDS[ex_name] = ex_id
                        custom = json.loads(TB_CUSTOM_IDS_PATH.read_text()) if TB_CUSTOM_IDS_PATH.exists() else {}
                        custom[ex_name] = ex_id
                        TB_CUSTOM_IDS_PATH.write_text(json.dumps(custom, indent=2))
                if not ex_id:
                    errors.append(f"Failed to create '{ex_name}' in TB — skipped")
                    new_assigned_ids.append(0)
                    continue

            sg = item.get("superset_group")
            if sg:
                if sg not in group_letter_map:
                    group_letter_map[sg] = chr(letter_code)
                    letter_code += 1
                gl = group_letter_map[sg]
            else:
                gl = chr(letter_code)
                letter_code += 1

            sets_count = item.get("sets", 3)
            reps_raw = str(item.get("reps", "8"))
            reps_match = re.search(r"\d+", reps_raw)
            reps = int(reps_match.group()) if reps_match else 8

            payload = {
                "exerciseId": ex_id,
                "type": "lift",
                "userId": tb_user_id,
                "date": body.date,
                "order": push_order,
                "groupingLetter": gl,
                "repType": "reps",
                "repsOnly": False,
                "eachSide": False,
                "sets": [
                    {"setNumber": s + 1, "reps": reps, "prescribedValue": ""}
                    for s in range(sets_count)
                ],
                "additionalInfo": item.get("note", ""),
            }

            if existing_aid:
                r = await client.put(
                    f"{TB_BASE}/accounts/{TB_ACCOUNT_CODE}/calendars/programming/{existing_aid}",
                    headers=headers, json=payload,
                )
                if r.status_code == 200:
                    results.append({"exercise": ex_name, "tb_id": ex_id, "status": 200, "created": False, "assigned_id": existing_aid})
                    new_assigned_ids.append(existing_aid)
                    updated_count += 1
                    continue

            r = await client.post(
                f"{TB_BASE}/accounts/{TB_ACCOUNT_CODE}/calendars/programming",
                headers=headers, json=payload,
            )
            aid = r.json().get("assignedId", 0) if r.status_code == 201 else 0
            results.append({"exercise": ex_name, "tb_id": ex_id, "status": r.status_code, "created": r.status_code == 201, "assigned_id": aid})
            new_assigned_ids.append(aid)

    # Persist assignedIds for future upsert
    tb_pushes = p.get("tb_pushes", {})
    tb_pushes[body.date] = [aid for aid in new_assigned_ids if aid]
    data[body.athlete_name]["tb_pushes"] = tb_pushes
    tmp = PROGRAMS_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(PROGRAMS_PATH)

    created = sum(1 for r in results if r["created"])
    return {
        "ok": True,
        "date": body.date,
        "day_label": day.get("label"),
        "updated": updated_count,
        "created": created,
        "skipped": len(errors),
        "results": results,
        "errors": errors,
    }


# ── AI Programming ─────────────────────────────────────────────────────────────

SLOT_ORDER = ["monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday"]

_AI_TOOL = {
    "name": "propose_program_day",
    "description": "Propose adding or replacing a training day for an athlete. Shown to coach for review before anything is saved.",
    "input_schema": {
        "type": "object",
        "properties": {
            "athlete_name": {"type": "string", "description": "Full athlete name as in the system"},
            "action": {"type": "string", "enum": ["add", "replace"]},
            "day": {
                "type": "object",
                "properties": {
                    "label": {"type": "string"},
                    "slot": {"type": "string", "enum": SLOT_ORDER},
                    "focus": {"type": "string"},
                    "exercises": {
                        "type": "array",
                        "items": {
                            "type": "object",
                            "properties": {
                                "name": {"type": "string"},
                                "sets": {"type": "integer"},
                                "reps": {"type": "string"},
                                "note": {"type": "string"},
                                "superset_group": {"type": "string"},
                                "load": {},
                                "type": {"type": "string"},
                                "label": {"type": "string"},
                            },
                        },
                    },
                },
                "required": ["label", "slot", "focus", "exercises"],
            },
            "reasoning": {"type": "string", "description": "Why these exercises and structure"},
        },
        "required": ["athlete_name", "action", "day", "reasoning"],
    },
}


class AIChatBody(BaseModel):
    message: str
    history: list[dict] = []


class ApplyDayBody(BaseModel):
    athlete_name: str
    day: dict


def _ai_system(data: dict, athletes: Optional[list] = None) -> str:
    athlete_summary = {}
    for name, p in data.items():
        days = p.get("program", {}).get("days", [])
        day_summaries = []
        for d in days:
            exs = [e["name"] for e in d.get("exercises", []) if e.get("type") != "session_break"]
            day_summaries.append(f"{d.get('slot','?').title()} ({d.get('label','?')}): {', '.join(exs)}")
        athlete_summary[name] = {
            "injury": p.get("injury", ""),
            "phase": p.get("phase"),
            "notes": p.get("notes", ""),
            "tb_user_id": p.get("tb_user_id"),
            "training_days": day_summaries,
        }

    # Pull Modified Training athletes from squad roster
    modified_context = ""
    if athletes:
        modified = [
            f"  - {a['name']}: {a.get('injury_notes', 'no notes')}"
            for a in athletes if a.get("status") == "Modified Training"
        ]
        if modified:
            modified_context = f"\n\nMODIFIED TRAINING ATHLETES (need individual programs, NOT group calendar):\n" + "\n".join(modified)

    return f"""You are an expert S&C coach for Taranaki Bulls rugby academy. Today: {datetime.now().strftime('%A %d %B %Y')}.{modified_context}

ATHLETE PROGRAMS:
{json.dumps(athlete_summary, indent=2)}

AVAILABLE EXERCISES — use ONLY these exact names (they have TeamBuildr IDs):
{json.dumps(sorted(TB_EXERCISE_IDS.keys()), indent=2)}

RULES:
- superset_group letters A/B/C... for main exercises, R for physio/rehab blocks
- Session breaks use: {{"type": "session_break", "label": "Section Name"}}
- Regular exercises use: {{"name": "...", "sets": N, "reps": "...", "note": "...", "superset_group": "X", "load": null}}
- Avoid same exercise on consecutive training days
- For injury athletes follow physio notes strictly
- For rounded/postural issues: prioritise face pulls, Y-T-A, external rotation, rows, serratus work
- Always call propose_program_day with your full structured day"""


@router.post("/ai/chat")
async def ai_programming_chat(body: AIChatBody):
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        raise HTTPException(500, "ANTHROPIC_API_KEY not set")

    data = _load(PROGRAMS_PATH, {})
    athletes = _load(ATHLETES_PATH, [])
    client = anthropic.Anthropic(api_key=key)

    messages = list(body.history) + [{"role": "user", "content": body.message}]

    response = client.messages.create(
        model="claude-fable-5",
        max_tokens=4096,
        system=_ai_system(data, athletes),
        tools=[_AI_TOOL],
        messages=messages,
    )

    text = ""
    proposed = None
    for block in response.content:
        if hasattr(block, "text"):
            text = block.text
        elif getattr(block, "type", None) == "tool_use" and block.name == "propose_program_day":
            proposed = block.input

    return {"message": text, "proposed": proposed, "stop_reason": response.stop_reason}


@router.get("/ai/suggestions")
def get_ai_suggestions():
    data = _load(PROGRAMS_PATH, {})
    athletes = _load(ATHLETES_PATH, [])
    suggestions = []

    # Modified Training athletes without an individual program — highest priority
    for a in athletes:
        if a.get("status") == "Modified Training":
            name = a.get("name", "")
            if name not in data:
                injury_notes = a.get("injury_notes", "")
                note_context = f" Injury notes: {injury_notes}." if injury_notes else ""
                suggestions.append({
                    "id": f"modified_no_program_{name}",
                    "type": "modified_no_program",
                    "athlete": name,
                    "message": "Modified Training — no individual program",
                    "priority": "high",
                    "prompt": f"Create an individual modified training program for {name}. They are on Modified Training status.{note_context} Build a program that works around their limitations — what can they do, not what they can't.",
                })

    for athlete, p in data.items():
        days = p.get("program", {}).get("days", [])

        if not days:
            suggestions.append({
                "id": f"no_program_{athlete}",
                "type": "missing_program",
                "athlete": athlete,
                "message": f"No training days programmed",
                "priority": "high",
            })
            continue

        # Back-to-back exercise overlaps
        slot_exs: dict[str, set[str]] = {}
        for day in days:
            slot = day.get("slot", "")
            names = {e["name"] for e in day.get("exercises", []) if e.get("type") != "session_break"}
            slot_exs[slot] = names

        sorted_slots = sorted(slot_exs.keys(), key=lambda s: SLOT_ORDER.index(s) if s in SLOT_ORDER else 99)
        for i in range(len(sorted_slots) - 1):
            s1, s2 = sorted_slots[i], sorted_slots[i + 1]
            if s1 in SLOT_ORDER and s2 in SLOT_ORDER:
                if SLOT_ORDER.index(s2) - SLOT_ORDER.index(s1) == 1:
                    overlap = slot_exs[s1] & slot_exs[s2]
                    if overlap:
                        examples = sorted(overlap)[:2]
                        suggestions.append({
                            "id": f"overlap_{athlete}_{s1}_{s2}",
                            "type": "overlap",
                            "athlete": athlete,
                            "message": f"{s1.title()}/{s2.title()} back-to-back: {', '.join(examples)}{'…' if len(overlap) > 2 else ''}",
                            "priority": "medium",
                        })

        # Exercises missing TB IDs
        missing: list[str] = []
        for day in days:
            for ex in day.get("exercises", []):
                if ex.get("type") == "session_break":
                    continue
                name = ex.get("name", "")
                if name and name not in TB_EXERCISE_IDS:
                    missing.append(name)
        if missing:
            unique = list(dict.fromkeys(missing))
            suggestions.append({
                "id": f"no_tb_id_{athlete}",
                "type": "missing_tb_id",
                "athlete": athlete,
                "message": f"{len(unique)} exercise(s) won't push to TeamBuildr",
                "priority": "low",
                "details": unique,
            })

    suggestions.sort(key=lambda s: {"high": 0, "medium": 1, "low": 2}.get(s["priority"], 3))
    return {"suggestions": suggestions}


@router.post("/ai/apply")
def ai_apply_day(body: ApplyDayBody):
    data = _load(PROGRAMS_PATH, {})
    if body.athlete_name not in data:
        raise HTTPException(404, f"No program for '{body.athlete_name}'")

    days = data[body.athlete_name].setdefault("program", {}).setdefault("days", [])
    new_day = {**body.day, "completed": False}
    slot = new_day.get("slot")

    existing_idx = next((i for i, d in enumerate(days) if d.get("slot") == slot), None)
    if existing_idx is not None:
        days[existing_idx] = new_day
        action = "replaced"
    else:
        days.append(new_day)
        action = "added"

    tmp = PROGRAMS_PATH.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(PROGRAMS_PATH)
    return {"ok": True, "action": action}


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT 1 — Modified Status Sentinel
# Triggered when an athlete's status changes to Modified Training.
# Produces a complete draft individual program, stored in pending_programs.json.
# ═══════════════════════════════════════════════════════════════════════════════

_INDIVIDUAL_PROGRAM_TOOL = {
    "name": "propose_individual_program",
    "description": "Draft a complete individual modified-training program for an athlete who cannot train with the group. Cover 3–4 days per week. Use only exercise names that appear in the available exercises list.",
    "input_schema": {
        "type": "object",
        "properties": {
            "athlete_name": {"type": "string"},
            "injury_summary": {"type": "string", "description": "One-line injury description"},
            "phase": {"type": "string", "description": "e.g. '1 — Early loading', '2 — Progressive loading'"},
            "notes": {"type": "string", "description": "Key contraindications and coaching notes"},
            "missing_injury_info": {
                "type": "boolean",
                "description": "True if injury notes are absent and the program is based on position/sport defaults only",
            },
            "days": {
                "type": "array",
                "items": {
                    "type": "object",
                    "properties": {
                        "slot": {"type": "string", "enum": SLOT_ORDER},
                        "label": {"type": "string"},
                        "focus": {"type": "string"},
                        "exercises": {
                            "type": "array",
                            "items": {
                                "type": "object",
                                "properties": {
                                    "name":           {"type": "string"},
                                    "sets":           {"type": "integer"},
                                    "reps":           {"type": "string"},
                                    "load":           {"type": "string"},
                                    "note":           {"type": "string"},
                                    "superset_group": {"type": "string"},
                                    "type":           {"type": "string", "enum": ["lift", "session_break"]},
                                    "label":          {"type": "string"},
                                },
                                "required": ["name", "sets", "reps"],
                            },
                        },
                    },
                    "required": ["slot", "label", "focus", "exercises"],
                },
            },
            "reasoning": {"type": "string", "description": "Full programming rationale including contraindication handling"},
        },
        "required": ["athlete_name", "injury_summary", "phase", "notes", "days", "reasoning", "missing_injury_info"],
    },
}


def _draft_individual_system(athlete: dict, group_context: str, block_info: str) -> str:
    name = athlete.get("name", "")
    position = athlete.get("position", "")
    injury_notes = athlete.get("injury_notes", "") or ""
    today = datetime.now().strftime("%A %d %B %Y")

    return f"""You are an expert S&C and rehab programming coach for Taranaki Bulls rugby academy. Today: {today}.

ATHLETE: {name} — {position}
INJURY NOTES: {injury_notes if injury_notes else "NOT PROVIDED — base program on position defaults and conservative loading. Set missing_injury_info=true."}

{block_info}

WHAT THE GROUP IS DOING THIS WEEK (mirror training intent where injury allows):
{group_context}

AVAILABLE EXERCISES (use ONLY these exact names — they have TeamBuildr IDs):
{json.dumps(sorted(TB_EXERCISE_IDS.keys()), indent=2)}

RULES:
- 3 training days per week for Modified Training athletes
- Mirror the group's training intent (upper/lower split, emphasis) but substitute contraindicated movements
- Use session_break items (type='session_break', label='...') to organise sections: ACTIVATION, MAIN LIFTS, ACCESSORIES
- Main exercises: use superset_group letters A, B, C...
- If no injury notes: build a conservative position-appropriate program, set missing_injury_info=true so George knows to review after physio consult
- Always include neck work (4 Way Neck Isometric) unless head/neck is the injury
- Include shoulder health work (face pulls, Y-T-A) unless shoulder is injured
- Loads: use RPE descriptors (RPE 6-7, BW, Moderate) since we don't have 1RM data for new athletes
- Call propose_individual_program with a complete program"""


async def _run_individual_draft(athlete: dict, group_context: str = "", block_info: str = "") -> Optional[dict]:
    """Core drafting logic — returns the proposed program dict or None."""
    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if not key:
        return None

    system = _draft_individual_system(athlete, group_context, block_info)
    name = athlete.get("name", "")
    position = athlete.get("position", "")
    injury = athlete.get("injury_notes", "") or "no injury notes on file"

    client = anthropic.Anthropic(api_key=key)
    try:
        response = client.messages.create(
            model="claude-fable-5",
            max_tokens=6000,
            system=system,
            tools=[_INDIVIDUAL_PROGRAM_TOOL],
            messages=[{
                "role": "user",
                "content": f"Draft a complete individual modified training program for {name} ({position}). Injury context: {injury}.",
            }],
        )
    except Exception:
        return None

    for block in response.content:
        if getattr(block, "type", None) == "tool_use" and block.name == "propose_individual_program":
            return block.input
    return None


async def draft_individual_background(name: str, injury_notes: str, position: str) -> None:
    """Called as a background task from the status-change webhook."""
    athletes = _load(ATHLETES_PATH, [])
    athlete = next((a for a in athletes if a["name"] == name), None)
    if not athlete:
        return

    # Don't draft if one already exists in pending or programs
    existing = _load(PROGRAMS_PATH, {})
    pending = _load(PENDING_PATH, [])
    if name in existing or any(p["athlete_name"] == name for p in pending):
        return

    proposed = await _run_individual_draft(athlete)
    if not proposed:
        return

    import uuid
    entry = {
        "id": str(uuid.uuid4())[:8],
        "athlete_name": name,
        "position": position,
        "generated_at": datetime.now().isoformat(),
        "trigger": "status_change",
        "injury_summary": proposed.get("injury_summary", ""),
        "phase": proposed.get("phase", "1"),
        "notes": proposed.get("notes", ""),
        "missing_injury_info": proposed.get("missing_injury_info", False),
        "days": proposed.get("days", []),
        "reasoning": proposed.get("reasoning", ""),
    }
    pending.append(entry)
    _save(PENDING_PATH, pending)


def _save(path: Path, data) -> None:
    tmp = path.with_suffix(".tmp")
    tmp.write_text(json.dumps(data, indent=2, ensure_ascii=False))
    tmp.replace(path)


class DraftIndividualBody(BaseModel):
    athlete_name: str


@router.post("/ai/draft-individual")
async def ai_draft_individual(body: DraftIndividualBody):
    """Manually trigger an individual draft for a Modified Training athlete."""
    athletes = _load(ATHLETES_PATH, [])
    athlete = next((a for a in athletes if a["name"] == body.athlete_name), None)
    if not athlete:
        raise HTTPException(404, f"Athlete '{body.athlete_name}' not found")

    # Build group context from TB history
    tb_history = _load(TB_HISTORY_PATH, {})
    group_context = "No group history available — sync TeamBuildr history for context."
    for cal_id, cal_data in tb_history.items():
        assignments = cal_data.get("assignments", [])
        recent = [a for a in assignments if a.get("date", "") >= (datetime.now().strftime("%Y-%m-%d")[:7])]
        if recent:
            from routes.periodisation import _build_history_summary
            group_context = _build_history_summary(recent[:50])
            break

    # Build block context
    blocks = _load(BLOCKS_PATH, [])
    today = datetime.now().strftime("%Y-%m-%d")
    active = next((b for b in blocks if b.get("start_date", "") <= today <= b.get("end_date", "")), None)
    block_info = f"Current block: {active['name']} — {active['phase']} phase" if active else "No active training block set."

    proposed = await _run_individual_draft(athlete, group_context, block_info)
    if not proposed:
        raise HTTPException(500, "AI did not produce a program — try again")

    import uuid
    existing_pending = _load(PENDING_PATH, [])
    existing_pending = [p for p in existing_pending if p["athlete_name"] != body.athlete_name]

    entry = {
        "id": str(uuid.uuid4())[:8],
        "athlete_name": body.athlete_name,
        "position": athlete.get("position", ""),
        "generated_at": datetime.now().isoformat(),
        "trigger": "manual",
        "injury_summary": proposed.get("injury_summary", ""),
        "phase": proposed.get("phase", "1"),
        "notes": proposed.get("notes", ""),
        "missing_injury_info": proposed.get("missing_injury_info", False),
        "days": proposed.get("days", []),
        "reasoning": proposed.get("reasoning", ""),
    }
    existing_pending.append(entry)
    _save(PENDING_PATH, existing_pending)

    return {"ok": True, "pending_id": entry["id"], "missing_injury_info": entry["missing_injury_info"]}


@router.get("/ai/pending-programs")
def get_pending_programs():
    pending = _load(PENDING_PATH, [])
    pending.sort(key=lambda p: p.get("generated_at", ""), reverse=True)
    return {"pending": pending}


class ApproveIndividualBody(BaseModel):
    pending_id: str
    tb_user_id: Optional[int] = None


@router.post("/ai/approve-individual")
def approve_individual(body: ApproveIndividualBody):
    pending = _load(PENDING_PATH, [])
    entry = next((p for p in pending if p["id"] == body.pending_id), None)
    if not entry:
        raise HTTPException(404, "Pending program not found")

    name = entry["athlete_name"]
    programs = _load(PROGRAMS_PATH, {})

    programs[name] = {
        "injury": entry["injury_summary"],
        "phase": entry["phase"],
        "notes": entry["notes"],
        "tb_user_id": body.tb_user_id or None,
        "tb_pushes": {},
        "program": {
            "template": "individual_modified",
            "days": entry["days"],
        },
    }
    _save(PROGRAMS_PATH, programs)

    pending = [p for p in pending if p["id"] != body.pending_id]
    _save(PENDING_PATH, pending)

    return {"ok": True, "athlete_name": name}


@router.delete("/ai/pending-programs/{pending_id}")
def delete_pending_program(pending_id: str):
    pending = _load(PENDING_PATH, [])
    pending = [p for p in pending if p["id"] != pending_id]
    _save(PENDING_PATH, pending)
    return {"ok": True}


# ═══════════════════════════════════════════════════════════════════════════════
# AGENT 2+3 — Autonomous Week Generator + Progressive Overload Engine
# Scheduled Thursday afternoon. Produces group weeks + individual program
# updates with progressive overload baked in. All land in review queues.
# ═══════════════════════════════════════════════════════════════════════════════

def _compute_progression(athlete_name: str, programs_data: dict, block_phase: str) -> dict:
    """
    Reads logged session results and returns per-exercise load adjustments.
    Returns {exercise_name: {action: 'progress'|'hold'|'deload', note: str}}
    """
    p = programs_data.get(athlete_name, {})
    results = p.get("session_results", {})
    if not results:
        return {}

    # Last 2 weeks of logged dates
    sorted_dates = sorted(results.keys(), reverse=True)[:14]
    logged = {}
    for date in sorted_dates:
        for ex, r in results[date].items():
            weight_str = r.get("weight", "")
            if weight_str and ex not in logged:
                logged[ex] = {"weight": weight_str, "date": date}

    # Phase-appropriate progression increments
    increment = {"Accumulation": "5%", "Intensification": "2.5%", "Realisation": "2.5%", "Taper": "-10%"}.get(block_phase, "2.5%")

    adjustments = {}
    for ex, data in logged.items():
        if block_phase == "Taper":
            adjustments[ex] = {"action": "deload", "note": f"Taper week — reduce to ~90% of last logged"}
        else:
            adjustments[ex] = {"action": "progress", "note": f"Last logged {data['weight']} on {data['date']} — add ~{increment}"}

    return adjustments


@router.post("/ai/draft-week")
async def ai_draft_full_week(week_start: Optional[str] = None):
    """
    Agent 2+3: Autonomous week generator.
    - Generates group weeks for both Academy calendars (with progression)
    - Drafts individual programs for any Modified Training athlete without one
    - Returns a summary of everything queued for review
    """
    import asyncio as _asyncio
    from routes.periodisation import _build_history_summary

    if not week_start:
        # Default to next Monday
        today = datetime.now()
        days_until_monday = (7 - today.weekday()) % 7 or 7
        next_monday = today.replace(hour=0, minute=0, second=0, microsecond=0)
        from datetime import timedelta
        next_monday += timedelta(days=days_until_monday)
        week_start = next_monday.strftime("%Y-%m-%d")

    athletes = _load(ATHLETES_PATH, [])
    programs_data = _load(PROGRAMS_PATH, {})
    blocks = _load(BLOCKS_PATH, [])
    key_dates = _load(KEY_DATES_PATH, [])
    tb_history = _load(TB_HISTORY_PATH, {})
    pending = _load(PENDING_PATH, [])

    today_str = datetime.now().strftime("%Y-%m-%d")
    active_block = next(
        (b for b in blocks if b.get("start_date", "") <= today_str <= b.get("end_date", "")),
        blocks[0] if blocks else None,
    )
    block_phase = active_block["phase"] if active_block else "Accumulation"
    block_info = (
        f"Block: {active_block['name']} — {active_block['phase']} phase, "
        f"week {active_block.get('week_number', '?')} of {active_block.get('total_weeks', '?')}"
        if active_block else "No active block configured."
    )

    summary = {"week_start": week_start, "group_weeks": [], "individual_drafts": [], "progressions": []}

    # ── Group weeks (both Academy calendars) ──────────────────────────────────
    ACADEMY_CALENDARS = [
        {"id": 199612, "name": "Academy - Strength"},
        {"id": 208484, "name": "Academy - Year 1"},
    ]

    key = os.environ.get("ANTHROPIC_API_KEY", "")
    if key:
        from routes.periodisation import (
            _build_ai_system as _per_system,
            _GROUP_WEEK_TOOL,
            GROUP_PROGS_PATH,
        )
        import uuid as _uuid

        for cal in ACADEMY_CALENDARS:
            cal_history = tb_history.get(str(cal["id"]), {})
            assignments = cal_history.get("assignments", [])

            # Apply progressive overload context to group history summary
            history_summary = _build_history_summary(assignments)

            progression_note = ""
            if active_block:
                start = datetime.strptime(active_block["start_date"], "%Y-%m-%d")
                wk_num = max(1, round((datetime.now() - start).days / 7) + 1)
                if block_phase == "Accumulation":
                    progression_note = f"Week {wk_num}: increase total sets by 1 per main exercise vs last week if athletes completed all sets."
                elif block_phase == "Intensification":
                    progression_note = f"Week {wk_num}: increase load 2–3% on compound lifts, hold volume. Reduce sets if RPE feedback suggests fatigue."
                elif block_phase == "Realisation":
                    progression_note = f"Week {wk_num}: maintain specificity, reduce total volume by ~15%, peak for competition readiness."
                elif block_phase == "Taper":
                    progression_note = f"Week {wk_num}: TAPER — cut volume 30–40%, maintain intensity. Short, sharp sessions."

            client = anthropic.Anthropic(api_key=key)
            try:
                response = client.messages.create(
                    model="claude-fable-5",
                    max_tokens=8000,
                    system=_per_system(active_block, key_dates, history_summary),
                    tools=[_GROUP_WEEK_TOOL],
                    messages=[{
                        "role": "user",
                        "content": (
                            f"Generate a complete training week for {cal['name']} starting {week_start}. "
                            f"PROGRESSIVE OVERLOAD DIRECTIVE: {progression_note} "
                            f"This is an automated Thursday draft — George will review Friday morning."
                        ),
                    }],
                )

                proposed = None
                for blk in response.content:
                    if getattr(blk, "type", None) == "tool_use" and blk.name == "propose_group_week":
                        proposed = blk.input

                if proposed:
                    group_progs = _load(GROUP_PROGS_PATH, [])
                    prog_id = str(_uuid.uuid4())[:8]
                    group_progs.append({
                        "id": prog_id,
                        "calendar_id": cal["id"],
                        "calendar_name": cal["name"],
                        "week_start": week_start,
                        "week_label": proposed.get("week_label", ""),
                        "generated_at": datetime.now().isoformat(),
                        "trigger": "scheduled",
                        "reviewed": False,
                        "pushed": False,
                        "days": proposed.get("days", []),
                        "reasoning": proposed.get("reasoning", ""),
                        "block_name": active_block["name"] if active_block else None,
                        "block_phase": block_phase,
                    })
                    _save(GROUP_PROGS_PATH, group_progs)
                    summary["group_weeks"].append({"calendar": cal["name"], "id": prog_id, "ok": True})

            except Exception as e:
                summary["group_weeks"].append({"calendar": cal["name"], "ok": False, "error": str(e)})

    # ── Individual progressive overload (existing programs) ───────────────────
    for name, p in programs_data.items():
        athlete = next((a for a in athletes if a["name"] == name), None)
        if not athlete or athlete.get("status") == "Full Contact":
            continue
        adjustments = _compute_progression(name, programs_data, block_phase)
        if adjustments:
            summary["progressions"].append({
                "athlete": name,
                "adjustments": adjustments,
            })

    # ── Individual drafts for unprogrammed Modified Training athletes ─────────
    modified = [
        a for a in athletes
        if a.get("status") == "Modified Training"
        and a["name"] not in programs_data
        and not any(p["athlete_name"] == a["name"] for p in pending)
    ]

    if key:
        # Build group context once for individual drafts
        group_context = "No group history — sync TB first."
        for cal_id_str, cal_data in tb_history.items():
            asgns = cal_data.get("assignments", [])
            if asgns:
                group_context = _build_history_summary(asgns[:60])
                break

        for athlete in modified:
            proposed = await _run_individual_draft(athlete, group_context, block_info)
            if proposed:
                import uuid as _uuid2
                entry = {
                    "id": str(_uuid2.uuid4())[:8],
                    "athlete_name": athlete["name"],
                    "position": athlete.get("position", ""),
                    "generated_at": datetime.now().isoformat(),
                    "trigger": "draft_week",
                    "injury_summary": proposed.get("injury_summary", ""),
                    "phase": proposed.get("phase", "1"),
                    "notes": proposed.get("notes", ""),
                    "missing_injury_info": proposed.get("missing_injury_info", False),
                    "days": proposed.get("days", []),
                    "reasoning": proposed.get("reasoning", ""),
                }
                pending.append(entry)
                summary["individual_drafts"].append({
                    "athlete": athlete["name"],
                    "ok": True,
                    "missing_injury_info": entry["missing_injury_info"],
                })
            else:
                summary["individual_drafts"].append({"athlete": athlete["name"], "ok": False})

        _save(PENDING_PATH, pending)

    return {"ok": True, "summary": summary}
