#!/usr/bin/env python3
"""Run once to create the Managed Agents environment + Injury Intel agent.

Usage:  python3 api/create_agents.py

Saves agent_config.json to data/ — agents are persistent, never recreated
unless you delete the config.
"""
import json
import os
import sys
from pathlib import Path

import anthropic

DATA_DIR    = Path(__file__).parent.parent.parent / "data"
CONFIG_PATH = DATA_DIR / "agent_config.json"

INJURY_INTEL_SYSTEM = """\
You are an expert sports medicine research agent specialising in professional rugby injuries.

When given an injury description for a rugby athlete, you:

1. Research the specific injury type and mechanism using authoritative sports medicine sources (BJSM, JOSPT, NRL/World Rugby injury protocols, peer-reviewed rehabilitation studies). Prefer primary sources over blog posts.

2. Find evidence-based return-to-play (RTP) timelines for this injury in professional contact sport athletes. Note the range (best case / typical / worst case) and what factors push toward each end.

3. Structure a 4-phase RTP plan:
   - Phase 1: Acute/Protection (off field, pain management, protect tissue)
   - Phase 2: Progressive Loading (gym-based, structured loading)
   - Phase 3: Sport-Specific (field work, non-contact, skills)
   - Phase 4: Return to Contact (gradual contact re-introduction, full training)

   For each phase include: typical duration, what the athlete IS cleared to do, what remains restricted, and objective criteria that must be met before advancing to the next phase.

4. Flag any red flags or complications that would extend the timeline (e.g. failed loading test, swelling persisting, mechanism suggesting structural damage).

5. Note position-specific considerations — a prop's demands differ from a halfback's.

Be specific, cite your sources inline, and acknowledge uncertainty where evidence is limited. Write for an experienced performance staff member, not a general audience.
"""


def main():
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        print("ERROR: ANTHROPIC_API_KEY not set")
        sys.exit(1)

    client = anthropic.Anthropic(api_key=key)

    config: dict = {}
    if CONFIG_PATH.exists():
        config = json.loads(CONFIG_PATH.read_text())
        print(f"Existing config found: {CONFIG_PATH}")

    # ── Environment ───────────────────────────────────────────────────────────
    env_id = config.get("environment_id")
    if env_id:
        print(f"Reusing environment:         {env_id}")
    else:
        print("Creating environment...")
        env = client.beta.environments.create(
            name="bulls-dashboard",
            description="Taranaki Bulls performance dashboard agent environment",
        )
        env_id = env.id
        print(f"  Created environment:       {env_id}")

    # ── Injury Intel Agent ────────────────────────────────────────────────────
    injury_agent_id = config.get("injury_intel_agent_id")
    if injury_agent_id:
        print(f"Reusing Injury Intel Agent:  {injury_agent_id}")
    else:
        print("Creating Injury Intel Agent...")
        agent = client.beta.agents.create(
            model="claude-fable-5",
            name="Bulls Injury Intel",
            description="Multi-step sports medicine research + RTP plan generation for rugby injuries",
            system=INJURY_INTEL_SYSTEM,
            tools=[{"type": "agent_toolset_20260401"}],
        )
        injury_agent_id = agent.id
        print(f"  Created Injury Intel:      {injury_agent_id}")

    # ── Save ──────────────────────────────────────────────────────────────────
    config = {
        "environment_id":       env_id,
        "injury_intel_agent_id": injury_agent_id,
    }
    CONFIG_PATH.write_text(json.dumps(config, indent=2))
    print(f"\nConfig saved → {CONFIG_PATH}")
    print("Run this script again any time to reuse existing agents (safe to re-run).")


if __name__ == "__main__":
    main()
