"""Production API server — no hot-reload, used by the bundled .app."""
import os
import sys
from pathlib import Path

# Distributed copies (another coach's Mac) won't have the backend's Python packages installed
# in the system python3. If a vendored deps dir sits next to the data dir
# (<BULLS_DATA_DIR>/../vendor), put it on sys.path FIRST — before any third-party import — so
# the app is self-contained. On the dev machine that dir doesn't exist, so the system packages
# are used as before.
_bulls_data = os.environ.get("BULLS_DATA_DIR", "")
if _bulls_data:
    _root = Path(_bulls_data).parent
    _plat = "win" if os.name == "nt" else ("mac" if sys.platform == "darwin" else "")
    for _name in ([f"vendor-{_plat}"] if _plat else []) + ["vendor"]:
        _vd = _root / _name
        if _vd.exists():
            sys.path.insert(0, str(_vd))
            break

def _load_env(path: Path) -> None:
    if not path.is_file():
        return
    for line in path.read_text().splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            os.environ.setdefault(k.strip(), v.strip())

# Try: explicit BULLS_ENV_FILE → repo root → app-support dir. Guard the empty-string case —
# Path("") resolves to "." (a directory), and .exists() is True for it, so an unset
# BULLS_ENV_FILE used to make _load_env try to read the current directory as a file and crash.
_env_val = os.environ.get("BULLS_ENV_FILE", "").strip()
_env_candidates = [
    Path(_env_val) if _env_val else None,
    Path(__file__).parent.parent.parent / ".env",          # repo root (dev)
    Path.home() / "Library" / "Application Support" / "Force Decks" / ".env",
]
for _env_path in _env_candidates:
    if _env_path and _env_path.is_file():
        _load_env(_env_path)
        break

if __name__ == "__main__":
    import uvicorn
    api_dir = str(Path(__file__).parent)
    sys.path.insert(0, api_dir)
    # Default 8093 (the desktop app's sidecar port); the browser package overrides via BULLS_PORT
    # so it can run alongside the desktop app without a port clash.
    _port = int(os.environ.get("BULLS_PORT", "8093"))
    uvicorn.run("main:app", host="127.0.0.1", port=_port, reload=False, app_dir=api_dir)
