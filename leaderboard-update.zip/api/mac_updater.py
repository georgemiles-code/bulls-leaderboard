#!/usr/bin/env python3
"""Self-updater for the Mac Tauri app (Force Decks.app).

Unlike the browser/Windows channel, this app's frontend is compiled directly into the Rust
binary — there's no folder of web files the normal web-updater (see main.py's /apply-update)
can extract over. So this app needs a different trick: download a freshly *built* .app bundle
and swap the whole thing on disk, then relaunch. Invoked by the Rust side (src-tauri/src/lib.rs)
as a subprocess, one of two ways:

    python3 mac_updater.py check   -> prints {"current","latest","available","notes"} JSON
    python3 mac_updater.py apply   -> downloads the new .app, stages a swap-and-relaunch script
                                       detached in the background, prints {"ok": true}, and
                                       returns immediately so the caller can quit itself; the
                                       staged script waits for this app to exit, then replaces
                                       /Applications/Force Decks.app and reopens it.
"""
import io
import json
import os
import subprocess
import sys
import tempfile
import zipfile
from pathlib import Path

_UPDATE_BASE = os.environ.get("BULLS_UPDATE_URL", "https://georgemiles-code.github.io/bulls-leaderboard").rstrip("/")
APP_NAME = "Force Decks.app"
INSTALL_PATH = "/Applications/Force Decks.app"

# This script lives at .../Force Decks.app/Contents/Resources/api/mac_updater.py — the bundled
# version.json (baked in at build time by publish_web.py, see tauri.conf.json resources) sits
# one directory up, at Contents/Resources/version.json.
_VERSION_FILE = Path(__file__).resolve().parent.parent / "version.json"


def _local_version() -> str:
    try:
        return json.loads(_VERSION_FILE.read_text()).get("version", "")
    except Exception:
        return ""


def cmd_check():
    import requests
    import time as _t
    cur = _local_version()
    out = {"current": cur, "latest": "", "available": False, "notes": "", "error": ""}
    try:
        r = requests.get(f"{_UPDATE_BASE}/leaderboard-version.json?t={int(_t.time())}", timeout=15)
        r.raise_for_status()
        meta = r.json()
        latest = str(meta.get("version", ""))
        out["latest"] = latest
        out["notes"] = meta.get("notes", "")
        out["available"] = bool(latest) and latest != cur
    except Exception as e:
        out["error"] = str(e)
    print(json.dumps(out))


def cmd_apply():
    import requests
    import time as _t
    try:
        r = requests.get(f"{_UPDATE_BASE}/leaderboard-mac-app.zip?t={int(_t.time())}", timeout=180)
        r.raise_for_status()
        data = r.content
        with zipfile.ZipFile(io.BytesIO(data)) as z:
            pass  # validate; raises if corrupt
    except Exception as e:
        print(json.dumps({"ok": False, "error": f"download failed: {e}"}))
        return

    stage_dir = Path(tempfile.mkdtemp(prefix="force-decks-update-"))
    zip_path = stage_dir / "app.zip"
    zip_path.write_bytes(data)
    with zipfile.ZipFile(zip_path) as z:
        z.extractall(stage_dir)
    new_app = stage_dir / APP_NAME
    if not new_app.is_dir():
        print(json.dumps({"ok": False, "error": "downloaded update did not contain " + APP_NAME}))
        return

    my_pid = os.getppid()  # the Tauri app process (this script's parent)
    swap_script = stage_dir / "swap.sh"
    swap_script.write_text(f"""#!/bin/sh
# Wait for the running app to fully exit (it quits itself right after launching this).
for i in $(seq 1 50); do
    kill -0 {my_pid} 2>/dev/null || break
    sleep 0.2
done
rm -rf "{INSTALL_PATH}"
cp -R "{new_app}" "{INSTALL_PATH}"
xattr -cr "{INSTALL_PATH}" 2>/dev/null
open -a "Force Decks"
rm -rf "{stage_dir}"
""")
    swap_script.chmod(0o755)
    subprocess.Popen(
        ["/bin/sh", str(swap_script)],
        start_new_session=True,
        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, stdin=subprocess.DEVNULL,
    )
    print(json.dumps({"ok": True}))


if __name__ == "__main__":
    mode = sys.argv[1] if len(sys.argv) > 1 else ""
    if mode == "check":
        cmd_check()
    elif mode == "apply":
        cmd_apply()
    else:
        print(json.dumps({"ok": False, "error": f"unknown mode {mode!r}"}))
        sys.exit(1)
