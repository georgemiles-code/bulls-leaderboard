' Engine supervisor — PURE VBScript, no cmd/.bat, so there is NO console and Windows Terminal
' never opens a tab, even across auto-update restarts. Runs pythonw.exe (no console window) in a
' loop, relaunching whenever it exits with code 42 (the auto-update restart). Output is redirected
' by serve.py itself to %LOCALAPPDATA%\Leaderboard\engine.log (pythonw has no stdout).
' VBScript is loaded into memory at start, so the auto-updater overwriting this file mid-run is
' harmless (unlike a .bat, which cmd re-reads line-by-line and corrupts).
Option Explicit
Dim sh, fso, base, env, pyw, ret
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
base = fso.GetParentFolderName(WScript.ScriptFullName) & "\"

Set env = sh.Environment("PROCESS")
env("BULLS_DATA_DIR") = base & "data"
env("BULLS_ENV_FILE") = base & ".env"
env("BULLS_FRONTEND_DIR") = base & "web"
env("BULLS_PORT") = "8097"
env("BULLS_RESTARTABLE") = "1"

pyw = """" & base & "python-win\pythonw.exe"" """ & base & "api\serve.py"""
Do
  ret = sh.Run(pyw, 0, True)   ' 0 = hidden, True = wait for exit; pythonw = no console at all
  WScript.Sleep 1500
Loop While ret = 42
