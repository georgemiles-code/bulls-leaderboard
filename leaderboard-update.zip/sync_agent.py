"""
Taranaki Bulls — Direct Data Sync Agent
Pulls data from VALD Hub, Teambuildr, Smartabase, STATSports
using direct HTTP calls — no AI / no API credits required.
"""

import json
import random
import re
import shutil
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, timezone
from pathlib import Path
from typing import Optional

NZT = timezone(timedelta(hours=12))

import requests

BASE     = Path(__file__).parent
DATA_DIR = BASE / "data"


# ── Shared helpers ──────────────────────────────────────────────────────────────

def _atomic_save(path: Path, content: str, snapshot: bool = True, keep_backups: int = 10) -> None:
    """Write a file atomically with an optional snapshot of the prior version.

    Why this exists: sync_agent used to call path.write_text() directly on athletes.json,
    which meant any sync bug instantly corrupted the live dashboard data and the user
    had to hand-create rollback files (e.g. athletes.pre-vald-cleanup.json). This helper
    snapshots the existing file to athletes.bak-{utc_ts}.json before overwriting, and
    writes through a .tmp file with an atomic rename so a crashed write can never leave
    a half-written athletes.json on disk.

    Old auto-backups for the same file are pruned to keep_backups (default 10), so this
    doesn't bloat data/ over time.
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if snapshot and path.exists():
        ts = datetime.utcnow().strftime("%Y%m%dT%H%M%S")
        backup = path.with_name(f"{path.stem}.bak-{ts}{path.suffix}")
        try:
            shutil.copy2(path, backup)
        except Exception:
            pass
        # Prune old auto-backups for this file (keep last N)
        try:
            backups = sorted(path.parent.glob(f"{path.stem}.bak-*{path.suffix}"))
            for old in backups[:-keep_backups]:
                try:
                    old.unlink()
                except Exception:
                    pass
        except Exception:
            pass
    tmp = path.with_suffix(path.suffix + ".tmp")
    tmp.write_text(content)
    tmp.replace(path)  # atomic on POSIX


def _load_vald_profile_map() -> dict:
    """Load the canonical VALD profile_id -> athlete_name mapping.

    Multiple profile_ids can map to the same athlete (some athletes have duplicate
    VALD accounts that are legitimately the same person). Returns {} if the file
    is missing — in that case sync_vald falls back to logging unknown profile_ids
    and skipping them, never to fuzzy name matching.

    Metadata keys (leading underscore, e.g. "_comment", "_ignored_profiles") are
    stripped here — this dict's keys get iterated elsewhere as if they were all real
    VALD profile_ids (to find which mapped athletes are missing from a sync batch),
    so a stray "_comment" would otherwise get treated as one and fetched for.
    """
    p = DATA_DIR / "vald_profile_map.json"
    if not p.exists():
        return {}
    try:
        data = json.loads(p.read_text())
    except Exception:
        return {}
    return {k: v for k, v in data.items() if not k.startswith("_")}


def _load_ignored_vald_profiles() -> set:
    """Profile_ids known to not be real athletes (e.g. VALD's own "Guest" demo
    profiles) — skipped silently instead of logging an "unknown profile" warning
    every single sync run for something that will never need mapping.
    """
    p = DATA_DIR / "vald_profile_map.json"
    if not p.exists():
        return set()
    try:
        data = json.loads(p.read_text())
    except Exception:
        return set()
    return set(data.get("_ignored_profiles") or [])

def _save_data(data_type, data, log):
    if data_type == "cmj":
        return _save_cmj_to_athletes(data, log)

    file_map = {
        "gps":      DATA_DIR / "gps.json",
        "strength": DATA_DIR / "strength.json",
        "fitness":  DATA_DIR / "fitness.json",
        "speed":    DATA_DIR / "speed.json",
    }
    if data_type not in file_map:
        return 0
    path = file_map[data_type]
    existing = json.loads(path.read_text()) if path.exists() else {}
    added = 0
    for player, records in data.items():
        if player not in existing:
            existing[player] = []
        existing_dates = {r.get("date") for r in existing[player]}
        for rec in records:
            d = rec.get("date")
            if d and d not in existing_dates:
                existing[player].append(rec)
                existing_dates.add(d)
                added += 1
            elif d in existing_dates:
                idx = next((i for i, r in enumerate(existing[player]) if r.get("date") == d), None)
                if idx is not None:
                    existing[player][idx].update(rec)
    _atomic_save(path, json.dumps(existing, indent=2, ensure_ascii=False))
    log(f"  Saved {added} new {data_type} records")
    return added


def _norm_player_name(name):
    return re.sub(r"[^a-z0-9]", "", (name or "").lower())


def _parse_ddmmyyyy(raw):
    if not raw:
        return None
    for fmt in ("%d/%m/%Y", "%Y-%m-%d"):
        try:
            return datetime.strptime(str(raw), fmt)
        except (ValueError, TypeError):
            pass
    return None


def _is_plausible_cmj_height(jh):
    return jh is not None and 15 < float(jh) < 60


def _save_cmj_to_athletes(data, log):
    """Save VALD CMJ records into athletes.json, the source used by /forcedecks.

    Names in `data` are expected to be CANONICAL athlete names (matched upstream in
    sync_vald via vald_profile_map.json). The last-name fallback that used to live
    here was the root cause of cross-athlete contamination — two Hendersons on the
    roster both matched `last == "henderson"` and stomped each other's history.
    If a name doesn't match exactly here it gets skipped + logged, never guessed.

    The lock prevents two concurrent sync cycles from clobbering each other's writes.
    """
    import threading
    global _athletes_lock
    if _athletes_lock is None:
        _athletes_lock = threading.Lock()

    path = DATA_DIR / "athletes.json"
    with _athletes_lock:
        athletes = json.loads(path.read_text())
        by_norm = {_norm_player_name(a.get("name")): a for a in athletes}
        added = 0
        updated = 0
        pb_count = 0
        skipped_unknown = 0

        for player, records in data.items():
            nn = _norm_player_name(player)
            athlete = by_norm.get(nn)
            if not athlete:
                # No fuzzy fallback — fail loudly so the user knows to fix the upstream
                # profile map or the athletes.json roster, rather than silently writing
                # to the wrong athlete.
                log(f"  SKIP: no exact athlete match for '{player}' ({len(records)} record(s))")
                skipped_unknown += 1
                continue

            history = athlete.setdefault("history", [])
            old_pb = float(athlete.get("pb") or 0)
            for rec in records:
                date = rec.get("date")
                jh = _to_cm(rec.get("jh"))
                if not date or not _is_plausible_cmj_height(jh):
                    continue
                entry = {"date": date, "jh": round(jh, 2)}
                for src, dest, places in (
                    ("bw", "bw", 2),
                    ("bw_kg", "bw_kg", 2),
                    ("rsi", "rsi", 3),
                    ("rsi_mod", "rsi", 3),
                    ("power_wkg", "power_wkg", 2),
                    ("pp_bm", "power_wkg", 2),
                    ("landing_force_n", "landing_force_n", 1),
                ):
                    val = rec.get(src)
                    try:
                        val = float(val)
                    except (TypeError, ValueError):
                        val = None
                    if val and val > 0:
                        entry[dest] = round(val, places)

                existing = next((h for h in history if h.get("date") == date), None)
                if existing:
                    before = float(existing.get("jh") or 0)
                    if entry["jh"] > before:
                        # New jump is better — update jh + any new metrics, but never
                        # overwrite an already-stored metric with a missing/lower value.
                        for k, v in entry.items():
                            if k == "jh":
                                existing[k] = v
                            elif k == "date":
                                pass
                            elif k not in existing or existing.get(k) in (None, ""):
                                existing[k] = v
                        updated += 1
                    else:
                        # New jh not better — fill in any gaps only.
                        for k, v in entry.items():
                            if k not in existing or existing.get(k) in (None, ""):
                                existing[k] = v
                else:
                    history.append(entry)
                    added += 1

            history.sort(key=lambda h: _parse_ddmmyyyy(h.get("date")) or datetime.min)
            new_pb = max([float(h.get("jh") or 0) for h in history] or [0])
            if new_pb > old_pb + 0.001:
                pb_count += 1
                athlete["pb"] = round(new_pb, 2)
            best = next((h for h in history if abs(float(h.get("jh") or 0) - new_pb) < 0.001), None)
            if best:
                athlete["pbDate"] = best.get("date")

        _atomic_save(path, json.dumps(athletes, indent=2, ensure_ascii=False))
        msg = f"  Saved {added + updated} CMJ updates into athletes.json ({pb_count} PB changes)"
        if skipped_unknown:
            msg += f" — skipped {skipped_unknown} unknown athlete(s); add them to vald_profile_map.json or athletes.json"
        log(msg)
        return added + updated


def _load_npc_manual_additions() -> set:
    """Names that always count as NPC squad regardless of VALD's "Bulls NPC" group
    tag — e.g. coaching staff who aren't tagged in VALD but test alongside the
    squad. Kept separate from VALD-driven membership so the sync's reconciliation
    (removing names VALD no longer tags) never silently undoes a manual addition.
    """
    p = DATA_DIR / "npc_manual_additions.json"
    try:
        return set(json.loads(p.read_text()).get("names", []))
    except Exception:
        return set()


def _sync_npc_squad(vald_npc_names, log):
    """Keep each athlete's NPC squad membership in sync with VALD Hub's "Bulls NPC"
    group attribute — VALD Hub is now the authoritative source for this, replacing
    a one-off manual list. Athletes tagged "Bulls NPC" in VALD get "npc" added to
    their `extra_squads` (on top of their existing primary squad); athletes that
    previously had it but are no longer tagged in VALD get it removed — unless
    they're in npc_manual_additions.json, which always wins.
    """
    import threading
    global _athletes_lock
    if _athletes_lock is None:
        _athletes_lock = threading.Lock()

    manual_names = _load_npc_manual_additions()
    npc_norm = {_norm_player_name(n) for n in vald_npc_names} | {_norm_player_name(n) for n in manual_names}
    path = DATA_DIR / "athletes.json"
    with _athletes_lock:
        athletes = json.loads(path.read_text())
        added = 0
        removed = 0
        for a in athletes:
            is_npc = _norm_player_name(a.get("name")) in npc_norm
            extra = set(a.get("extra_squads") or [])
            had_npc = "npc" in extra
            if is_npc and not had_npc:
                extra.add("npc")
                a["extra_squads"] = sorted(extra)
                added += 1
            elif not is_npc and had_npc:
                extra.discard("npc")
                a["extra_squads"] = sorted(extra)
                removed += 1
        if added or removed:
            _atomic_save(path, json.dumps(athletes, indent=2, ensure_ascii=False))
        log(f"VALD Hub: NPC squad synced from \"Bulls NPC\" group — +{added} / -{removed} (now {len(npc_norm)} tagged in VALD)")


def _get_athletes():
    return json.loads((DATA_DIR / "athletes.json").read_text())


def _squad_norm_names(squad: str) -> set:
    """Normalised names of athletes in `squad` — same matching rules as force_lab.py's
    _squad_athlete_ids (kept as a separate copy rather than a cross-module import, since
    these two files are independently loaded/reloaded in different ways).
    'male' is a combined alias for academy + npc + wtg. An athlete also matches if `squad`
    is in their extra_squads list.
    """
    allowed = {"academy", "npc", "wtg"} if squad == "male" else {squad}
    names = set()
    for a in _get_athletes():
        extra = set(a.get("extra_squads") or [])
        if a.get("squad") in allowed or extra & allowed:
            names.add(_norm_player_name(a.get("name")))
    return names


def _fmt_date(dt):
    if isinstance(dt, datetime):
        return dt.strftime("%d/%m/%Y")
    return str(dt) if dt else None


def _parse_dt(s):
    if not s:
        return None
    for fmt in ("%Y-%m-%dT%H:%M:%S.%fZ", "%Y-%m-%dT%H:%M:%SZ",
                "%Y-%m-%dT%H:%M:%S", "%Y-%m-%d"):
        try:
            return datetime.strptime(s, fmt)
        except (ValueError, TypeError):
            pass
    return None


def _match_athlete(name, athletes):
    """Fuzzy-match an API name to our athlete list."""
    if not name:
        return None
    norm = lambda s: s.lower().replace(" ", "").replace("-", "").replace("'", "").replace("’", "").replace("‘", "")
    for a in athletes:
        if norm(a["name"]) == norm(name):
            return a["name"]
    # Last-name fallback
    last = name.strip().split()[-1].lower() if name.strip() else ""
    for a in athletes:
        if a["name"].split()[-1].lower() == last:
            return a["name"]
    return None


# ── VALD Hub ────────────────────────────────────────────────────────────────────

# Token cache: avoid re-authenticating on every sync cycle (tokens are valid ~1 hr)
_vald_token_cache: dict = {}  # keys: token, expires_at, client_id

# Rotating-window cursor for the live per-athlete fallback fetch, keyed by squad. See its use
# in sync_vald for why this exists: capping REQUEST VOLUME per cycle (not just shuffling order)
# is what actually keeps the live poller under VALD's real rate limit.
_live_batch_cursor: dict = {}
# Profile IDs the live batcher has already seen at least once, keyed by squad. A profile mapped
# mid-session (e.g. a coach adds a new athlete and they test immediately) would otherwise land at
# an arbitrary spot in the rotation and could wait a couple of cycles for its first check — this
# lets a brand-new profile jump the queue and get checked on the very next live cycle instead.
_live_known_profiles: dict = {}

def _get_vald_token(token_url: str, client_id: str, client_secret: str, audience: str, log) -> str:
    """Return a cached Bearer token, refreshing only when expired.
    On 429 rate-limit, backs off for 5 minutes before retrying auth."""
    import time as _time
    cached = _vald_token_cache
    now = _time.time()
    # Return cached token if still valid
    if cached.get("client_id") == client_id and cached.get("token") and cached.get("expires_at", 0) > now + 60:
        return cached["token"]
    # Respect auth rate-limit backoff
    if cached.get("backoff_until", 0) > now:
        raise Exception(f"VALD auth rate-limited, retrying after {int(cached['backoff_until'] - now)}s")
    log("VALD Hub: authenticating…")
    r = requests.post(token_url, data={
        "grant_type": "client_credentials",
        "client_id": client_id,
        "client_secret": client_secret,
        "audience": audience,
    }, timeout=15)
    if r.status_code == 429:
        cached["backoff_until"] = now + 300  # back off 5 minutes
        r.raise_for_status()
    r.raise_for_status()
    data = r.json()
    token = data["access_token"]
    expires_in = data.get("expires_in", 3600)
    cached["token"] = token
    cached["expires_at"] = now + expires_in
    cached["client_id"] = client_id
    cached.pop("backoff_until", None)
    log("VALD Hub: authenticated ✓")
    return token


def sync_vald_live(creds, log, squad=None):
    """Fast-path VALD sync — only last day of data for live leaderboard responsiveness.
    Was 2 days; that meant every ~9s cycle asked VALD to compute+return two full days of
    everyone's tests just to check for anything brand new, which is itself a real chunk of
    the per-cycle latency (VALD has to do the work of finding/returning that data before we
    even start processing it). One day still comfortably covers a same-day session including
    the NZT/UTC day-boundary case (a 6am NZT session is 18:xx UTC the previous day — see
    _append_force_result's date handling), while meaningfully shrinking what VALD has to
    compute per request. The separate non-live "vald" sync still uses the full days_back=30
    default, so nothing here affects historical completeness — this only governs how far
    back the aggressive live-polling loop looks each cycle.

    `squad`, if given, restricts the expensive per-athlete fallback fetch (see sync_vald)
    to athletes in that squad — the TV app passes whichever squad tab is currently on
    screen, so a live session only pays the per-athlete cost for the ~20-40 people who
    could plausibly show up on the visible leaderboard instead of the whole ~113-person
    roster every cycle.
    """
    return sync_vald(creds, log, days_back=1, squad=squad)


def sync_vald(creds, log, days_back=30, squad=None):
    import threading
    squad_names = _squad_norm_names(squad) if squad else None
    token_url    = creds.get("token_url", "https://auth.prd.vald.com/oauth/token")
    audience     = creds.get("audience", "vald-api-external")
    client_id    = creds.get("client_id", "")
    client_secret = creds.get("client_secret", "")
    api_base     = creds.get("api_base", "https://prd-aue-api-extforcedecks.valdperformance.com")

    if not client_id or not client_secret:
        if creds.get("vald_username") and creds.get("vald_password"):
            return {
                "success": False,
                "message": "VALD temporary login is saved, but ForceDecks auto-sync needs VALD API Client ID + Secret. Website-password automation is not enabled because it is brittle and may break with MFA.",
                "records": 0,
            }
        return {"success": False, "message": "VALD credentials not set — add Client ID and Secret in Data Sync"}

    try:
        token = _get_vald_token(token_url, client_id, client_secret, audience, log)
    except Exception as e:
        return {"success": False, "message": f"VALD auth failed: {e}"}

    headers = {"Authorization": f"Bearer {token}", "Accept": "application/json"}
    athletes = _get_athletes()
    profile_map = _load_vald_profile_map()
    if not profile_map:
        return {"success": False, "message": "VALD profile map empty — data/vald_profile_map.json is missing or invalid. Refusing to sync without an authoritative profile_id → athlete map (last-name matching has been removed because it caused cross-athlete contamination)."}
    ignored_profiles = _load_ignored_vald_profiles()
    unknown_profiles = {}  # profile_id -> last seen name

    from_dt = (datetime.utcnow() - timedelta(days=days_back)).strftime("%Y-%m-%dT00:00:00Z")
    to_dt   = datetime.utcnow().strftime("%Y-%m-%dT23:59:59Z")

    try:
        teams_resp = requests.get(f"{api_base}/v2019q3/teams", headers=headers, timeout=15)
        teams_resp.raise_for_status()
        raw = teams_resp.json()
        teams = raw if isinstance(raw, list) else raw.get("teams") or raw.get("data") or raw.get("items") or []
        log(f"VALD Hub: found {len(teams)} team(s)")
        for t in teams:
            tid = t.get("id") or t.get("teamId") or t.get("Id") or "?"
            tname = t.get("name") or t.get("teamName") or t.get("Name") or "?"
            log(f"  Team: {tname} (id={tid})")
    except Exception as e:
        return {"success": False, "message": f"VALD teams fetch failed: {e}"}

    # Fetch athlete roster from each team to build id → name lookup for unmapped athletes.
    # VALD Hub now tags athletes with named group attributes (e.g. "Bulls NPC", "Bulls WTG") —
    # collect the "Bulls NPC" names here so squad membership can be kept in sync automatically
    # instead of maintained by hand (see _sync_npc_squad below).
    vald_athlete_names: dict[str, str] = {}  # athleteId → display name
    npc_names: set[str] = set()
    for team in teams:
        tid = team.get("id") or team.get("teamId") or team.get("Id")
        if not tid:
            continue
        for athletes_path in (f"/v2019q3/teams/{tid}/athletes", f"/v2019q3/teams/{tid}/profiles"):
            try:
                ar = requests.get(f"{api_base}{athletes_path}", headers=headers, timeout=15)
                if not ar.ok:
                    continue
                raw_a = ar.json()
                aths = raw_a if isinstance(raw_a, list) else raw_a.get("athletes") or raw_a.get("profiles") or raw_a.get("data") or raw_a.get("items") or []
                for a in aths:
                    aid = a.get("id") or a.get("athleteId") or a.get("profileId") or ""
                    first = a.get("firstName") or a.get("givenName") or ""
                    last  = a.get("lastName") or a.get("familyName") or a.get("surname") or ""
                    name  = a.get("name") or a.get("displayName") or f"{first} {last}".strip()
                    if aid and name:
                        vald_athlete_names[aid] = name
                    if name and any((attr.get("valueName") or "") == "Bulls NPC" for attr in (a.get("attributes") or [])):
                        npc_names.add(name)
                if aths:
                    log(f"VALD Hub: {len(aths)} athlete(s) in team roster")
                    break
            except Exception:
                continue

    if npc_names:
        _sync_npc_squad(npc_names, log)

    cmj_data = {}
    total_tests = 0
    other_tests = 0

    # Build athlete id lookup (profile_id → athlete id in athletes.json)
    all_athletes = _get_athletes()
    athlete_id_by_name = {_norm_player_name(a.get("name")): str(a["id"]) for a in all_athletes}

    # Every test in the days_back window gets a separate /trials API call below to fetch
    # its metrics — that's fine for a handful of genuinely new tests, but the rolling
    # window overlaps almost entirely with the previous cycle's window, so most of those
    # calls were re-fetching tests we already have stored, every single sync (every ~2s
    # while live). That N+1 pattern was the actual cause of each live sync taking 20-40s.
    # Skip the trials fetch for any test_id we've already successfully stored.
    try:
        _existing_force = json.loads((DATA_DIR / "force_results.json").read_text())
        known_test_ids = {r.get("test_id") for recs in _existing_force.values() for r in recs if r.get("test_id")}
    except Exception:
        known_test_ids = set()

    # New VALD profiles get auto-mapped here rather than requiring a manual copy-paste into
    # vald_profile_map.json each time — but only on an EXACT normalised-name match against
    # an athlete already in our own athletes.json roster (the same safety rule as before;
    # this is not the old fuzzy last-name matching that caused cross-athlete contamination,
    # since it only ever resolves against names WE curate, not raw VALD name guesses). VALD's
    # own generic "Guest" demo profiles never have a real athlete to match against, so they
    # fall straight through to the unknown-profile path unchanged — explicit belt-and-braces
    # skip here too in case a real "Guest ..." VALD name ever coincidentally matched someone.
    mapped_names = set(profile_map.values())
    local_norm  = {_norm_player_name(a["name"]): a["name"] for a in all_athletes}
    newly_mapped: dict[str, str] = {}  # profile_id → canonical name
    for pid, vname in vald_athlete_names.items():
        if pid in profile_map or "guest" in vname.strip().lower():
            continue
        norm = _norm_player_name(vname)
        canonical = local_norm.get(norm)
        if canonical and canonical not in mapped_names:
            newly_mapped[pid] = canonical
    if newly_mapped:
        log(f"VALD Hub: {len(newly_mapped)} new roster athlete(s) auto-mapped by exact name match:")
        for pid, name in sorted(newly_mapped.items(), key=lambda x: x[1]):
            log(f"    {name!r} ({pid[:8]}…)")
        profile_map.update(newly_mapped)  # so this same sync cycle picks up their tests too
        try:
            raw = json.loads((DATA_DIR / "vald_profile_map.json").read_text())
            raw.update(newly_mapped)
            (DATA_DIR / "vald_profile_map.json").write_text(json.dumps(raw, indent=2, sort_keys=False))
        except Exception as e:
            log(f"VALD Hub: failed to persist auto-mapped profiles to vald_profile_map.json: {e}")

    for team in teams:
        team_id = team.get("id") or team.get("teamId") or team.get("Id")
        if not team_id:
            continue
        # VALD uses path-based pagination: nextPage field contains a relative URL for the
        # next page (e.g. /v2019q3/teams/{id}/tests/2?modifiedFrom=...). take/skip params
        # are ignored by the API — only the page number in the URL path advances the cursor.
        tests: list = []
        next_url: str | None = f"{api_base}/v2019q3/teams/{team_id}/tests"
        next_params: dict | None = {"modifiedFrom": from_dt}
        while next_url:
            try:
                tests_resp = requests.get(next_url, headers=headers, params=next_params, timeout=30)
                next_params = None  # nextPage URL already carries query params
                if not tests_resp.ok:
                    log(f"VALD Hub: team {team_id} tests fetch failed ({tests_resp.status_code}): {tests_resp.text[:300]}")
                    break
                raw = tests_resp.json()
                if isinstance(raw, dict):
                    page = raw.get("tests") or raw.get("data") or raw.get("items") or []
                    next_path = raw.get("nextPage") or raw.get("next") or raw.get("nextPageUrl") or raw.get("next_page")
                    # Log pagination fields once so we can see the structure
                    if not tests:
                        total_items = raw.get("totalItems")
                        total_pages = raw.get("totalPages")
                        log(f"VALD Hub: response dict — totalItems={total_items}, totalPages={total_pages}, nextPage={next_path!r}")
                    next_url = f"{api_base}{next_path}" if next_path else None
                else:
                    page = raw
                    next_url = None
                tests.extend(page)
            except Exception as e:
                log(f"VALD Hub: team {team_id} error: {e}")
                break
        log(f"VALD Hub: team {team_id} returned {len(tests)} test record(s)")

        # Collect which profile IDs appeared in the team-level fetch
        team_profile_ids: set[str] = {
            (t.get("athleteId") or t.get("hubAthleteId") or "")
            for t in tests if (t.get("athleteId") or t.get("hubAthleteId"))
        }

        # For mapped profiles not seen in team tests, try the per-athlete endpoint.
        # This catches athletes in VALD groups that aren't returned by the team endpoint.
        # In practice the bulk team-tests response only ever returns a handful of records
        # (e.g. 19 of 100+ athletes' tests), so this "fallback" is really the primary path
        # for almost the whole roster, every single cycle — not optional work to skip.
        # These requests are all independent, so fetch them concurrently.
        missing_profiles = [pid for pid in profile_map if pid not in team_profile_ids]
        if squad_names is not None:
            # This is the actual point of the squad filter — restrict the expensive part
            # (one HTTP request per missing profile) to whoever could plausibly show up on
            # the currently-viewed leaderboard. Athletes outside the squad just don't get
            # checked this cycle; they're caught by the next non-scoped/full sync instead.
            before = len(missing_profiles)
            missing_profiles = [pid for pid in missing_profiles if _norm_player_name(profile_map[pid]) in squad_names]
            log(f"VALD Hub: squad filter — {before} missing profile(s) narrowed to {len(missing_profiles)} in-squad")
        # Shuffling (the previous approach) only randomised WHICH athletes got starved when a
        # 429 hit mid-batch — it still tried to fire a request for the ENTIRE missing list every
        # single cycle, so total request RATE to VALD never actually went down as squads grew
        # (confirmed: npc at 54+ profiles and wtg at 65 both 429'd on nearly every call). That's
        # what turned "jump to on-screen" into a 30-60s wait: a rate-limited cycle skips its
        # remaining checks entirely, so whoever landed late in that cycle's random order just
        # waits for the next one to get lucky.
        #
        # Fix: on the LIVE path (days_back<=1 — the aggressive ~2.5s poll), cap how many
        # profiles get checked per cycle and ROTATE through a stable window instead of
        # re-shuffling the whole squad. This directly caps request volume (the actual cause),
        # so the live poller stays under VALD's real rate limit regardless of how big a squad
        # grows, at the cost of any single athlete only being checked once every few cycles
        # instead of every cycle — a small, predictable trade for no longer risking a 429
        # storm that stalls everyone. The full/scheduled sync (days_back=30, runs every 30 min
        # per sync_config.json, not competing for a tight request budget) is untouched — it
        # still checks the entire squad every time for full historical completeness.
        LIVE_BATCH_SIZE = 18
        if days_back <= 1 and len(missing_profiles) > LIVE_BATCH_SIZE:
            missing_profiles.sort()  # stable order so the rotation window is well-defined
            key = squad or "_all"
            # First time this squad is seen in this process (e.g. right after an engine
            # restart — which happens on every auto-update, so this is common), seed "known"
            # with the CURRENT full squad rather than starting empty. Otherwise every restart
            # would treat the whole squad as "new" and burst-check everyone at once — the exact
            # rate-limit risk this batching exists to avoid. Only a profile that shows up AFTER
            # this baseline (added while the process keeps running) counts as genuinely new.
            if key not in _live_known_profiles:
                _live_known_profiles[key] = set(missing_profiles)
            known = _live_known_profiles[key]
            # Newly-mapped profiles (added mid-session, after the baseline above) always get
            # checked THIS cycle instead of waiting for their rotation turn — otherwise an
            # athlete added mid-session could sit unchecked for a couple of cycles purely
            # because of where their profile id happened to sort.
            new_ids = [pid for pid in missing_profiles if pid not in known]
            rest = [pid for pid in missing_profiles if pid in known]
            rotation_budget = max(0, LIVE_BATCH_SIZE - len(new_ids))
            start = _live_batch_cursor.get(key, 0) % max(1, len(rest))
            end = start + rotation_budget
            rotation_window = ([] if not rest else
                                (rest[start:end] if end <= len(rest) else rest[start:] + rest[:end - len(rest)]))
            if rest:
                _live_batch_cursor[key] = end % len(rest)
            window = new_ids + rotation_window
            known.update(missing_profiles)
            if new_ids:
                log(f"VALD Hub: live batch — {len(new_ids)} newly-mapped profile(s) prioritised this cycle")
            log(f"VALD Hub: live batch — checking {len(window)}/{len(missing_profiles)} in-squad profile(s) this cycle (rotating window, full coverage every ~{-(-len(rest)//max(1, rotation_budget)) if rotation_budget else 1} cycles)")
            missing_profiles = window
        else:
            random.shuffle(missing_profiles)
        if missing_profiles:
            log(f"VALD Hub: {len(missing_profiles)} mapped profile(s) absent from team tests — fetching per-athlete")
            per_athlete_added = 0
            # Shared flag so that once VALD starts rate-limiting (429), the rest of this
            # batch backs off immediately instead of continuing to hammer a wall — 20
            # concurrent workers previously drove VALD into a 429 state that then took the
            # whole live sync down for several minutes. This makes that failure mode
            # self-limiting: a 429 mid-batch now skips the remaining requests in THIS
            # cycle rather than compounding, and the next cycle (~15-20s later) tries fresh.
            rate_limited = threading.Event()

            def _fetch_athlete_tests(pid: str):
                if rate_limited.is_set():
                    return pid, []
                try:
                    # requests' timeout resets on each received chunk rather than capping
                    # total request time — a slow-trickling VALD response can blow past 15s
                    # regardless (one hit 91.9s in testing). Tighter here bounds the worst
                    # case for the live-sync hot path; a timed-out test just retries next
                    # cycle since it never got recorded as known.
                    #
                    # CRITICAL FIX (Sep 2026): this was "/v2019q3/athletes/{pid}/tests" — a
                    # URL that ALWAYS returns 404, for every profile, with no exception raised
                    # (`if pa_resp.ok` is just False) — so this whole per-athlete fallback has
                    # silently been a no-op since it was written, for every athlete, always.
                    # Confirmed via VALD's own athlete record `links.Tests` field and direct
                    # testing: the real, working, TEAM-SCOPED path is
                    # /v2019q3/teams/{team_id}/athlete/{pid}/tests (singular "athlete"). This
                    # explains the "slow sync" / "nobody's today data has synced" reports —
                    # the only thing that was ever actually finding new tests was the sparse
                    # bulk team-tests feed, which the comments above already note only returns
                    # a handful of records regardless of squad size.
                    pa_resp = requests.get(
                        f"{api_base}/v2019q3/teams/{team_id}/athlete/{pid}/tests",
                        headers=headers,
                        params={"modifiedFrom": from_dt},
                        timeout=6,
                    )
                    if pa_resp.status_code == 429:
                        rate_limited.set()
                        return pid, []
                    if pa_resp.ok:
                        pa_raw = pa_resp.json()
                        return pid, (pa_raw if isinstance(pa_raw, list) else pa_raw.get("tests") or pa_raw.get("data") or pa_raw.get("items") or [])
                except Exception:
                    pass
                return pid, []

            # max_workers is a deliberate middle ground — 20 tripped VALD's rate limit almost
            # immediately, and even 10 started 429ing after ~3 back-to-back cycles in testing
            # (i.e. VALD's limit is closer to sustained request RATE than burst size, so a
            # faster cycle means more cycles/minute means more total calls/minute). The 429
            # short-circuit above is the real safety net regardless of this number — it backs
            # off within the same cycle instead of cascading into a dead sync.
            with ThreadPoolExecutor(max_workers=7) as pool:
                futures = [pool.submit(_fetch_athlete_tests, pid) for pid in missing_profiles]
                for fut in as_completed(futures):
                    pid, pa_tests = fut.result()
                    if pa_tests:
                        log(f"VALD Hub: athlete {profile_map[pid]!r} ({pid[:8]}…) — {len(pa_tests)} test(s) via per-athlete endpoint")
                        tests.extend(pa_tests)
                        per_athlete_added += len(pa_tests)
            if rate_limited.is_set():
                log("VALD Hub: rate limited (429) partway through per-athlete fetch — backed off, will retry next cycle")
            if per_athlete_added:
                log(f"VALD Hub: added {per_athlete_added} test(s) from per-athlete fetch")

        seen_in_batch: dict[str, str] = {}
        for test in tests:
            type_raw = (test.get("testType") or test.get("testTypeName") or test.get("typeName") or test.get("name") or "").strip()
            type_key  = _vald_test_type_key(type_raw)

            # Match by VALD athlete id (stable, never ambiguous).
            # The v2019q3 API uses "athleteId"/"hubAthleteId"; older exports used "profileId".
            profile_id = (test.get("athleteId") or test.get("hubAthleteId")
                          or test.get("profileId") or test.get("profile_id")
                          or (test.get("athlete") or {}).get("id")
                          or (test.get("athlete") or {}).get("profileId") or "")
            name_raw = (test.get("athleteName") or test.get("profileName")
                        or (test.get("athlete") or {}).get("name") or "")
            if profile_id and profile_id not in seen_in_batch:
                seen_in_batch[profile_id] = name_raw or "?"
            matched = profile_map.get(profile_id) if profile_id else None
            if not matched:
                if profile_id and profile_id not in ignored_profiles:
                    unknown_profiles[profile_id] = name_raw or "?"
                continue

            date_raw = (test.get("recordedAt") or test.get("recordedUTC") or test.get("testDateUtc")
                        or test.get("testDate") or test.get("date"))
            dt = _parse_dt(date_raw)
            if not dt:
                continue

            test_id = test.get("id") or test.get("testId") or ""
            if test_id and test_id in known_test_ids:
                continue

            # Fetch trial results — VALD v2019q3 embeds no inline metrics in test records;
            # all metric values live in the trials endpoint under results[n].definition.result + .value
            # trial_groups keeps results per-trial so we can pick the best jump rather than
            # merging all trials (which caused last-trial-wins — storing the WORST result).
            trial_groups: list[list] = []
            flat_results: list = []
            if test_id:
                try:
                    # See matching comment in the per-athlete fallback above — tightened
                    # from 15s after a single trials fetch took 91.9s in testing despite
                    # the timeout, because requests' timeout is per-chunk, not total.
                    tr = requests.get(
                        f"{api_base}/v2019q3/teams/{team_id}/tests/{test_id}/trials",
                        headers=headers, timeout=6,
                    )
                    if tr.ok:
                        raw_t = tr.json()
                        trials = raw_t if isinstance(raw_t, list) else raw_t.get("trials") or raw_t.get("data") or []
                        for trial in trials:
                            results = trial.get("results") or trial.get("metrics") or []
                            if isinstance(results, list) and results:
                                trial_groups.append(results)
                                flat_results.extend(results)
                except Exception:
                    pass

            # For drop jump rank by RSI; for all other types rank by jump height.
            best_results = (_best_dj_trial(trial_groups) if type_key == "drop_jump" else _best_trial(trial_groups)) if trial_groups else flat_results

            # ── CMJ path (keep existing athletes.json save for backwards compat) ──
            if type_key == "cmj":
                jh = _extract_vald_jh(best_results) if best_results else _extract_vald_jh(test)
                if jh is not None:
                    rec = {"date": dt.strftime("%d/%m/%Y"), "jh": jh, "profile_id": profile_id}
                    for r in best_results:
                        if not isinstance(r, dict):
                            continue
                        mid = ((r.get("definition") or {}).get("result") or "").upper()
                        val = r.get("value")
                        if val is None:
                            continue
                        if mid == "RSI_MODIFIED_IMP_MOM" and "rsi_mod" not in rec:
                            v = _num_safe(val)
                            if v and v > 0:
                                rec["rsi_mod"] = round(v, 3)
                        elif mid == "BODYMASS_RELATIVE_MEAN_CONCENTRIC_POWER" and "pp_bm" not in rec:
                            v = _num_safe(val)
                            if v and v > 0:
                                rec["pp_bm"] = round(v, 1)
                    cmj_data.setdefault(matched, []).append(rec)
                    total_tests += 1

            # ── All test types → force_results.json ──────────────────────────────
            metrics_obj = _extract_all_metrics({"results": best_results}, type_key) if best_results else _extract_all_metrics(test, type_key)
            if metrics_obj:
                athlete_id = athlete_id_by_name.get(_norm_player_name(matched))
                if athlete_id:
                    # Store date in NZT (UTC+12) so morning sessions (6 AM NZT = 18:xx UTC prev day) land on the correct calendar date
                    dt_nzt = dt.replace(tzinfo=timezone.utc).astimezone(NZT)
                    _append_force_result(athlete_id, {
                        "test_id":      test_id,
                        "test_type":    type_key,
                        "test_label":   type_raw or type_key,
                        "date":         dt_nzt.strftime("%Y-%m-%d"),
                        "recorded_utc": date_raw or "",
                        "bw_kg":        _num_safe(test.get("bodyWeightKg") or test.get("bw_kg")),
                        "metrics":      metrics_obj,
                    })
                    if type_key != "cmj":
                        other_tests += 1

    log(f"VALD Hub: {total_tests} CMJ + {other_tests} other ForceDecks results matched")
    if unknown_profiles:
        log(f"VALD Hub: {len(unknown_profiles)} UNKNOWN athlete id(s) skipped — copy these into data/vald_profile_map.json:")
        for pid, nm in sorted(unknown_profiles.items()):
            resolved_name = vald_athlete_names.get(pid) or nm or "?"
            log(f"    \"{pid}\": \"{resolved_name}\",")
    saved = _save_data("cmj", cmj_data, log)
    msg = f"VALD sync complete — {saved} new CMJ updates, {other_tests} other ForceDecks updates"
    if unknown_profiles:
        msg += f". WARNING: {len(unknown_profiles)} unknown VALD profile(s) skipped — see log."
    return {"success": True, "message": msg, "records": saved + other_tests}


def _num_safe(v):
    try:
        f = float(v)
        return round(f, 3) if f == f else None
    except (TypeError, ValueError):
        return None


def _vald_test_type_key(raw: str) -> str:
    """Normalise a VALD testTypeName to a stable snake_case key."""
    t = raw.strip().lower().replace("-", " ").replace("_", " ")
    if not t:
        return "unknown"
    # Must be checked before the generic countermovement/cmj match below — VALD's short
    # code for this is "SLJ", but a longer "Single Leg Countermovement Jump" style name
    # would otherwise match that check first and get folded into bilateral CMJ data.
    if t == "slj" or ("single leg" in t and ("countermovement" in t or "cmj" in t)):
        return "slj"
    if "countermovement" in t or "cmj" in t:
        return "cmj"
    # Currently only matches because VALD happens to send the literal short code "PPU" —
    # which falls through every check below unchanged and hits the generic fallback at the
    # bottom. Explicit guard here so a future VALD rename to something more descriptive
    # (e.g. "Plyometric Push-Up") doesn't silently stop matching, the same class of bug
    # that prompted the SLJ guard above.
    if t == "ppu" or "push up" in t or "plyo" in t:
        return "ppu"
    if "drop jump" in t or "depth jump" in t or t in ("dj", "sldj"):
        return "drop_jump"
    if "squat jump" in t or "sj" == t:
        return "squat_jump"
    if "mid-thigh" in t or "mid thigh" in t or "imtp" in t:
        return "imtp"
    if "hop" in t and "return" in t:
        return "hop_return"
    if "land and hold" in t or "lah" == t:
        return "land_hold"
    if "single leg" in t and ("jump" in t or "iso" in t):
        return "single_leg"
    if "quiet stand" in t:
        return "quiet_stand"
    if "abalakov" in t:
        return "abalakov"
    return t.replace(" ", "_")[:32]


# Metric ID → force_results.json field name. Extend as VALD exposes more.
_METRIC_MAP = {
    "JUMP_HEIGHT_IMP_MOM":              "jump_height_cm",
    "JUMP_HEIGHT_FLIGHT_TIME":          "jump_height_flight_cm",
    "PUSHUP_HEIGHT":                    "pushup_height_cm",  # VALD's own "Push Up Height (Flight Time)", already in cm
    "RSI":                              "rsi_jh_ct",
    "RSI_MODIFIED":                     "rsi_modified",
    "CONTACT_TIME":                     "contact_time_ms",
    "FLIGHT_TIME":                      "flight_time_ms",
    "CONTRACTION_TIME":                 "contraction_time_ms",
    "COUNTERMOVEMENT_DEPTH":            "countermovement_depth_cm",
    "BRAKING_DURATION":                 "braking_duration_ms",
    "BRAKING_RFD":                      "braking_rfd_n_s",
    "RELATIVE_BRAKING_RFD":             "braking_rfd_n_s_kg",
    "CONCENTRIC_DURATION":              "concentric_duration_ms",
    "RELATIVE_PEAK_CONCENTRIC_FORCE":   "concentric_peak_force_n_kg",
    "CONCENTRIC_MEAN_POWER_BW":         "concentric_mean_power_w_kg",
    "CONCENTRIC_PEAK_VELOCITY":         "concentric_peak_velocity_m_s",
    "RELATIVE_CONCENTRIC_RFD":          "concentric_rfd_n_s_kg",
    "LOWER_LIMB_STIFFNESS":             "lower_limb_stiffness_n_m",
    "PEAK_FORCE":                       "peak_force_n",
    "RELATIVE_PEAK_FORCE":              "peak_force_n_kg",
    "ASYMMETRY_INDEX":                  "asymmetry_pct",
}

# Metrics stored in cm (VALD returns m for some)
_CM_METRICS  = {"jump_height_cm", "jump_height_flight_cm", "countermovement_depth_cm"}
# Metrics stored in ms (VALD returns s for some)
_MS_METRICS  = {"contact_time_ms", "flight_time_ms", "contraction_time_ms",
                 "braking_duration_ms", "concentric_duration_ms"}


def _coerce_metric(field: str, val: float) -> float:
    """Convert VALD raw value to dashboard unit (m→cm, s→ms)."""
    if field in _CM_METRICS and 0 < val < 2.0:
        return round(val * 100, 1)
    if field in _MS_METRICS and 0 < val < 30:
        return round(val * 1000, 1)
    return round(val, 3)


def _extract_all_metrics(test: dict, test_key: str) -> dict:
    """Extract every available metric from a VALD test object."""
    result = {}

    def _add(field, val):
        v = _num_safe(val)
        if v is not None and v > 0:
            result[field] = _coerce_metric(field, v)

    # Dict-form metrics (newer API responses)
    metrics = test.get("metrics") or test.get("results") or {}
    if isinstance(metrics, dict):
        for api_key, field in _METRIC_MAP.items():
            # API keys come in camelCase variants; try both
            snake = api_key.lower().replace("_", "")
            for candidate in (api_key, api_key.lower(), snake):
                v = metrics.get(candidate)
                if v is not None:
                    _add(field, v)
                    break

    # List-form metrics — VALD v2019q3 trial results use definition.result as the metric ID
    if isinstance(metrics, list):
        for m in metrics:
            if not isinstance(m, dict):
                continue
            mid = (m.get("metric_id") or m.get("metricId") or m.get("id")
                   or (m.get("definition") or {}).get("result") or "").upper()
            if mid in _METRIC_MAP:
                _add(_METRIC_MAP[mid], m.get("value") or m.get("Value") or m.get("result"))

    return result


_force_results_lock = None  # will be set to threading.Lock on first use
_athletes_lock = None        # guards athletes.json read-modify-write


def _append_force_result(athlete_id: str, record: dict) -> None:
    """Upsert one test result into force_results.json (keyed by test_id)."""
    import threading
    global _force_results_lock
    if _force_results_lock is None:
        _force_results_lock = threading.Lock()

    path = DATA_DIR / "force_results.json"
    test_id = record.get("test_id", "")

    with _force_results_lock:
        try:
            data = json.loads(path.read_text()) if path.exists() else {}
        except Exception:
            data = {}

        existing = data.setdefault(athlete_id, [])
        # Skip if test_id is in the ignored list
        ignored_path = DATA_DIR / "ignored_vald_tests.json"
        try:
            ignored = json.loads(ignored_path.read_text()) if ignored_path.exists() else {}
            if test_id and test_id in ignored.get("test_ids", []):
                return
        except Exception:
            pass
        # Skip if test_id already stored (idempotent)
        if test_id and any(r.get("test_id") == test_id for r in existing):
            return

        existing.append(record)
        # Keep sorted descending by date
        existing.sort(key=lambda r: r.get("date", ""), reverse=True)
        _atomic_save(path, json.dumps(data, indent=2, ensure_ascii=False))


def _best_trial(trial_groups: list) -> list:
    """Return the result list from the trial with the highest jump height.

    VALD embeds each trial's metrics as a flat list. When multiple trials exist,
    `_extract_all_metrics` used to take the last occurrence of each metric_id,
    meaning trial 2 always beat trial 1 even if trial 1 was the stronger jump.
    This function picks the single best trial first, so all metrics come from
    the same jump rather than mixing across trials.
    """
    if not trial_groups:
        return []
    if len(trial_groups) == 1:
        return trial_groups[0]
    best_group = trial_groups[0]
    best_jh = -1.0
    for group in trial_groups:
        for m in group:
            if not isinstance(m, dict):
                continue
            mid = (
                (m.get("definition") or {}).get("result")
                or m.get("metric_id") or m.get("metricId") or ""
            ).upper()
            if mid == "JUMP_HEIGHT_IMP_MOM":
                v = _num_safe(m.get("value") or m.get("Value"))
                if v is not None and v > best_jh:
                    best_jh = v
                    best_group = group
    return best_group


def _best_dj_trial(trial_groups: list) -> list:
    """Return the trial with the highest RSI (rsi_jh_ct) — used for drop jump.

    VALD's ForceDecks UI shows the best-RSI trial as the athlete's result, not
    the best-jump-height trial. Picking by jump height for a DJ can produce the
    wrong RSI value (e.g. 2.746 vs 2.77) because RSI = JH / CT, and the trial
    with the tallest jump may have a longer contact time.
    """
    if not trial_groups:
        return []
    if len(trial_groups) == 1:
        return trial_groups[0]
    RSI_IDS = {"RSI_JH_CT", "RSI_MODIFIED", "RSI"}
    best_group = trial_groups[0]
    best_rsi = -1.0
    for group in trial_groups:
        for m in group:
            if not isinstance(m, dict):
                continue
            mid = (
                (m.get("definition") or {}).get("result")
                or m.get("metric_id") or m.get("metricId") or ""
            ).upper()
            if any(mid == r or mid.startswith(r) for r in RSI_IDS):
                v = _num_safe(m.get("value") or m.get("Value"))
                if v is not None and v > best_rsi:
                    best_rsi = v
                    best_group = group
                break
    # Fallback to jump height if no RSI metric found (e.g. legacy data)
    return best_group if best_rsi >= 0 else _best_trial(trial_groups)


def _extract_vald_jh(obj):
    """Extract jump height from a VALD test/trial/metric object.

    LOCKED to JUMP_HEIGHT_IMP_MOM (Impulse-Momentum) only. VALD ForceDecks exposes
    multiple jump-height metrics on the same test ("Jump Height (Flight Time)",
    "Jump Height (Imp-Mom)", peak displacement, etc.). The old code returned the
    first match by loose name substring, which meant different sync runs picked
    different metrics for the same test on the same day on the same athlete —
    producing apparent ~16 cm swings in an athlete's PB across syncs.

    Imp-Mom is the right default for academy rugby S&C: most consistent across
    devices, least affected by ankle/foot extension at takeoff.
    """
    if not obj:
        return None
    if isinstance(obj, dict):
        # Only accept explicitly Imp-Mom keys. The bare 'jumpHeight' / 'JumpHeight'
        # keys are NOT safe — VALD uses them inconsistently and they sometimes
        # carry Flight Time values.
        for key in ("jumpHeightImpulseMomentum", "JumpHeightImpulseMomentum",
                    "jumpHeightImpMom", "jump_height_imp_mom"):
            v = obj.get(key)
            if v is not None:
                return _to_cm(v)
    if isinstance(obj, list):
        for m in obj:
            if not isinstance(m, dict):
                continue
            mid = (m.get("metric_id") or m.get("metricId") or m.get("id")
                   or (m.get("definition") or {}).get("result") or "").upper()
            nm  = (m.get("name") or m.get("metricName") or m.get("displayName") or "").lower()
            # Prefer matching by stable metric_id. Fall back to name only when the
            # name unambiguously says Imp-Mom AND does not say Flight Time.
            is_imp_mom = (
                mid == "JUMP_HEIGHT_IMP_MOM"
                or ("jump height" in nm and ("imp-mom" in nm or "impulse" in nm) and "flight" not in nm)
            )
            if is_imp_mom:
                v = m.get("value") or m.get("Value") or m.get("result")
                if v is not None:
                    return _to_cm(v)
    return None


def _to_cm(val):
    try:
        val = float(val)
    except (TypeError, ValueError):
        return None
    if val <= 0:
        return None
    return round(val * 100 if val < 2.0 else val, 1)


# ── Teambuildr ──────────────────────────────────────────────────────────────────

def sync_teambuildr(creds, log):
    log("Teambuildr: connecting…")
    api_key = creds.get("api_key", "")
    team_id = creds.get("team_id", "")
    base    = "https://api.teambuildr.com/v1"

    if not api_key or not team_id:
        if creds.get("username") and creds.get("password"):
            return {
                "success": False,
                "message": "Teambuildr temporary login is saved, but automatic strength sync needs Teambuildr API Key + Team ID. Use CSV import until API access is enabled.",
                "records": 0,
            }
        return {"success": False, "message": "Teambuildr credentials not set — add API Key and Team ID in Data Sync"}

    headers  = {"x-api-key": api_key, "Accept": "application/json"}
    athletes = _get_athletes()

    # Get Teambuildr athletes
    try:
        r = requests.get(f"{base}/teams/{team_id}/athletes", headers=headers, timeout=15)
        r.raise_for_status()
        tb_athletes = r.json() if isinstance(r.json(), list) else r.json().get("athletes") or r.json().get("data") or []
        log(f"Teambuildr: {len(tb_athletes)} athletes found")
    except Exception as e:
        return {"success": False, "message": f"Teambuildr athletes fetch failed: {e}"}

    # Map Teambuildr athlete IDs to our academy players
    id_map = {}
    for tba in tb_athletes:
        tb_name = f"{tba.get('firstName','')} {tba.get('lastName','')}".strip()
        matched = _match_athlete(tb_name, athletes)
        if matched:
            id_map[tba.get("id") or tba.get("athleteId")] = matched

    log(f"Teambuildr: matched {len(id_map)} academy players")

    EXERCISE_MAP = {
        "back squat":             "BackSquat_kg",
        "front squat":            "FrontSquat_kg",
        "bench press":            "BenchPress_kg",
        "bench pull":             "BenchPull_kg",
        "chin up":                "Chin_kg",
        "chinup":                 "Chin_kg",
        "bulgarian split squat":  "BulgarianSS_kg",
        "trap bar deadlift":      "TrapBar_kg",
        "trap bar":               "TrapBar_kg",
        "power clean":            "Clean_kg",
        "hang clean":             "Clean_kg",
    }

    strength_data = {}
    for tb_id, player_name in id_map.items():
        try:
            r = requests.get(f"{base}/athletes/{tb_id}/maxes", headers=headers, timeout=15)
            if not r.ok:
                continue
            maxes = r.json() if isinstance(r.json(), list) else r.json().get("maxes") or r.json().get("data") or []
        except Exception:
            continue

        rec = {}
        rec_date = None
        for mx in maxes:
            ex_name = (mx.get("exerciseName") or mx.get("name") or "").lower()
            for keyword, field in EXERCISE_MAP.items():
                if keyword in ex_name:
                    val = mx.get("weight") or mx.get("max") or mx.get("value")
                    if val:
                        rec[field] = float(val)
                    date_raw = mx.get("date") or mx.get("achievedDate")
                    if date_raw and not rec_date:
                        dt = _parse_dt(date_raw)
                        if dt:
                            rec_date = dt.strftime("%d/%m/%Y")
                    break

        if rec and rec_date:
            rec["date"] = rec_date
            strength_data[player_name] = [rec]

    saved = _save_data("strength", strength_data, log)
    return {"success": True, "message": f"Teambuildr sync complete — {saved} new strength records", "records": saved}


# ── Smartabase ──────────────────────────────────────────────────────────────────

def sync_smartabase(creds, log):
    log("Smartabase: authenticating…")
    base_url = creds.get("base_url", "").rstrip("/")
    username = creds.get("username", "")
    password = creds.get("password", "")

    if not base_url or not username or not password:
        return {"success": False, "message": "Smartabase credentials not set — add URL, username and password in Data Sync"}

    sb = requests.Session()
    sb.headers.update({"Accept": "application/json", "Content-Type": "application/json",
                        "X-Requested-With": "XMLHttpRequest"})

    # Step 1: GET the base page to initialise JSESSIONID cookie (required before login)
    try:
        sb.get(base_url + "/", timeout=10)
    except Exception:
        pass

    # Step 2: Login — Smartabase uses "username" field (not "loginName")
    try:
        r = sb.post(f"{base_url}/api/v2/user/login",
                    json={"username": username, "password": password}, timeout=15)
        data = r.json() if r.text.strip().startswith("{") else {}

        # Smartabase returns 200 even on failure — check for RPC exception
        if data.get("__is_rpc_exception__"):
            msg = (data.get("value") or {}).get("detailMessage") or "Login failed"
            if "incorrect" in msg.lower() or "password" in msg.lower():
                return {"success": False,
                        "message": "Smartabase: username or password incorrect — check your Smartabase login credentials"}
            return {"success": False, "message": f"Smartabase login error: {msg}"}

        user_id = data.get("id")
        log(f"Smartabase: logged in as {data.get('firstName','')} {data.get('lastName','')} ✓")
    except Exception as e:
        return {"success": False, "message": f"Smartabase auth failed: {e}"}

    # Check if data API is accessible (Smartabase only exposes it for admin/API-enabled accounts)
    probe = sb.get(f"{base_url}/api/v2/user/{user_id}/event", timeout=10)
    if probe.status_code == 404:
        return {
            "success": False,
            "message": (
                "Smartabase: login succeeded but data API is not enabled for this account. "
                "Contact the NZ Rugby Smartabase admin and ask them to enable REST API access "
                "for george@trfu.co.nz — or export data manually as CSV and import it via "
                "the Strength/GPS dashboards."
            )
        }

    athletes = _get_athletes()

    # List forms
    forms = []
    for forms_path in ["/api/v2/form", "/api/v1/forms", "/api/v2/forms"]:
        try:
            r = sb.get(f"{base_url}{forms_path}", timeout=15)
            if r.ok and r.text.strip().startswith(("[", "{")):
                raw = r.json()
                forms = raw if isinstance(raw, list) else raw.get("forms") or raw.get("data") or []
                if forms:
                    log(f"Smartabase: {len(forms)} forms found")
                    break
        except Exception:
            continue

    if not forms:
        return {"success": False, "message": "Smartabase: could not retrieve forms list — your account may not have API access. Contact your Smartabase admin."}

    # Identify relevant forms
    FORM_TARGETS = {
        "strength": ["strength", "lift", "gym", "squat"],
        "speed":    ["speed", "sprint", "10m", "20m"],
        "fitness":  ["bronco", "fitness", "endurance"],
    }

    from_date = (datetime.utcnow() - timedelta(days=180)).strftime("%Y-%m-%d")
    to_date   = datetime.utcnow().strftime("%Y-%m-%d")

    all_saved = 0

    for form in forms:
        form_name = (form.get("name") or form.get("formName") or "").lower()
        form_id   = form.get("id") or form.get("formId")
        if not form_id:
            continue

        matched_type = None
        for data_type, keywords in FORM_TARGETS.items():
            if any(k in form_name for k in keywords):
                matched_type = data_type
                break
        if not matched_type:
            continue

        log(f"Smartabase: fetching '{form.get('name')}' ({matched_type})…")

        try:
            r = sb.get(
                f"{base_url}/api/v1/form/{form_id}/entry",
                params={"startDate": from_date, "endDate": to_date, "limit": 500},
                timeout=30,
            )
            if not r.ok:
                # try alternate endpoint structure
                r = sb.get(
                    f"{base_url}/api/v1/forms/{form_id}/entries",
                    params={"startDate": from_date, "endDate": to_date},
                    timeout=30,
                )
            if not r.ok:
                continue
            entries_raw = r.json()
            entries = entries_raw if isinstance(entries_raw, list) else entries_raw.get("entries") or entries_raw.get("data") or []
        except Exception:
            continue

        result_data = {}
        FIELD_MAP = {
            "strength": {
                "back squat":            "BackSquat_kg",
                "bench press":           "BenchPress_kg",
                "bench pull":            "BenchPull_kg",
                "chin":                  "Chin_kg",
                "bulgarian":             "BulgarianSS_kg",
                "trap bar":              "TrapBar_kg",
                "clean":                 "Clean_kg",
            },
            "speed": {
                "10m": "Sprint10m_s",
                "10 m": "Sprint10m_s",
                "20m": "Sprint20m_s",
                "20 m": "Sprint20m_s",
            },
            "fitness": {
                "bronco": "bronco_s",
                "time":   "bronco_s",
            },
        }

        for entry in entries:
            athlete_name = (entry.get("athleteName") or entry.get("name")
                            or (entry.get("athlete") or {}).get("name") or "")
            matched = _match_athlete(athlete_name, athletes)
            if not matched:
                continue

            date_raw = entry.get("date") or entry.get("eventDate") or entry.get("recordedAt")
            dt = _parse_dt(date_raw)
            if not dt:
                continue
            date_str = dt.strftime("%d/%m/%Y")

            fields = entry.get("fields") or entry.get("data") or entry.get("values") or {}
            rec = {"date": date_str}

            if isinstance(fields, dict):
                for field_name, value in fields.items():
                    fn_lower = field_name.lower()
                    for keyword, col in FIELD_MAP.get(matched_type, {}).items():
                        if keyword in fn_lower:
                            try:
                                rec[col] = float(str(value).replace(",", ""))
                            except (ValueError, TypeError):
                                pass
            elif isinstance(fields, list):
                for f in fields:
                    fn_lower = (f.get("name") or f.get("label") or "").lower()
                    value    = f.get("value") or f.get("val")
                    for keyword, col in FIELD_MAP.get(matched_type, {}).items():
                        if keyword in fn_lower:
                            try:
                                rec[col] = float(str(value).replace(",", ""))
                            except (ValueError, TypeError):
                                pass

            if len(rec) > 1:  # has at least one metric besides date
                result_data.setdefault(matched, []).append(rec)

        saved = _save_data(matched_type, result_data, log)
        all_saved += saved

    return {"success": True, "message": f"Smartabase sync complete — {all_saved} new records", "records": all_saved}


# ── STATSports ──────────────────────────────────────────────────────────────────

def sync_statsports(creds, log):
    log("STATSports: connecting…")
    api_key = creds.get("api_key", "")
    team_id = creds.get("team_id", "")
    base    = "https://cloud.statsports.com/api/v1"

    if not api_key or not team_id:
        if creds.get("username") and creds.get("password"):
            return {
                "success": False,
                "message": "Sonra/STATSports temporary login is saved, but GPS auto-sync needs API access or an export bridge. CSV import is available now.",
                "records": 0,
            }
        return {"success": False, "message": "STATSports credentials not set — add API Key and Team ID in Data Sync"}

    headers  = {"Authorization": f"Bearer {api_key}", "Accept": "application/json"}
    athletes = _get_athletes()

    from_date = (datetime.utcnow() - timedelta(days=365)).strftime("%Y-%m-%d")
    to_date   = datetime.utcnow().strftime("%Y-%m-%d")

    try:
        r = requests.get(
            f"{base}/teams/{team_id}/sessions",
            headers=headers,
            params={"from": from_date, "to": to_date},
            timeout=30,
        )
        r.raise_for_status()
        raw = r.json()
        sessions = raw if isinstance(raw, list) else raw.get("sessions") or raw.get("data") or []
        log(f"STATSports: {len(sessions)} sessions found")
    except Exception as e:
        return {"success": False, "message": f"STATSports sessions fetch failed: {e}"}

    gps_data   = {}
    total_rows = 0

    for s in sessions:
        session_id   = s.get("id") or s.get("sessionId")
        session_date = s.get("date") or s.get("sessionDate") or s.get("startTime")
        session_type = s.get("type") or s.get("sessionType") or s.get("name") or ""
        dt = _parse_dt(session_date)
        if not dt or not session_id:
            continue
        date_str = dt.strftime("%d/%m/%Y")

        try:
            pr = requests.get(f"{base}/sessions/{session_id}/players", headers=headers, timeout=15)
            if not pr.ok:
                continue
            raw_p = pr.json()
            players = raw_p if isinstance(raw_p, list) else raw_p.get("players") or raw_p.get("data") or []
        except Exception:
            continue

        for p in players:
            p_name = (p.get("playerName") or p.get("name")
                      or f"{p.get('firstName','')} {p.get('lastName','')}".strip())
            matched = _match_athlete(p_name, athletes)
            if not matched:
                continue

            rec = {
                "date":         date_str,
                "session_type": session_type,
                "total_dist":   _safe_float(p, "totalDistance", "total_distance", "totalDist"),
                "hml_dist":     _safe_float(p, "highMetabolicLoadDistance", "hml_distance", "hmlDistance"),
                "hsr":          _safe_float(p, "highSpeedRunning", "hsr", "highSpeedDistance"),
                "max_speed":    _safe_float(p, "maxSpeed", "max_speed", "maximumSpeed"),
                "sprints":      _safe_float(p, "sprints", "sprintCount", "numberOfSprints"),
                "sprint_dist":  _safe_float(p, "sprintDistance", "sprint_distance", "totalSprintDistance"),
                "dsl":          _safe_float(p, "dynamicStressLoad", "dsl", "dynamicStress"),
            }
            # Only save if we got at least total distance
            if rec.get("total_dist"):
                gps_data.setdefault(matched, []).append(rec)
                total_rows += 1

    log(f"STATSports: {total_rows} player-session records matched")
    saved = _save_data("gps", gps_data, log)
    return {"success": True, "message": f"STATSports sync complete — {saved} new GPS records", "records": saved}

GYMAWARE_API_BASE = "https://cloud.gymaware.com/api"

# GymAware set-summary field → our stored metric key. GymAware returns a newline-separated
# stream of JSON objects (one per SET), each carrying the full velocity/power metric set;
# we keep them all so the board's metric selector (mean velocity / peak power / W·kg) can
# rank on any of them without a re-sync. See the API integration guide:
# https://gymaware.com/gymaware-cloud-api-integration-guide/
_GYMAWARE_METRIC_FIELDS = {
    "meanVelocity":     "mean_velocity",
    "peakVelocity":     "peak_velocity",
    "meanPower":        "mean_power",
    "peakPower":        "peak_power",
    "meanWattsPerKg":   "mean_watts_per_kg",
    "peakWattsPerKg":   "peak_watts_per_kg",
}


def _gymaware_name_forms(name: str) -> list[str]:
    """GymAware reports athlete names as 'Last, First' (e.g. 'Sa, Fiti'); our roster is
    'First Last'. Return the candidate normalised forms to match against — the reconstructed
    'First Last' and the raw string — so both orderings resolve. 'Guest' (unattributed sets
    logged without selecting an athlete on the unit) yields nothing and is skipped upstream."""
    name = (name or "").strip()
    if not name or name.lower() == "guest":
        return []
    forms = {_norm_player_name(name)}
    if "," in name:
        last, first = name.split(",", 1)
        forms.add(_norm_player_name(f"{first.strip()} {last.strip()}"))
    return [f for f in forms if f]


def _gymaware_recorded_dt(val):
    """GymAware timestamps come as either epoch seconds (int/str) or an ISO string —
    normalise to a naive UTC datetime. Query params are UTC seconds, but the response
    'recorded'/'modified' fields aren't documented to a single type, so handle both."""
    if val is None:
        return None
    if isinstance(val, (int, float)):
        try:
            return datetime.utcfromtimestamp(float(val))
        except (OverflowError, OSError, ValueError):
            return None
    s = str(val).strip()
    if s.isdigit():
        try:
            return datetime.utcfromtimestamp(int(s))
        except (OverflowError, OSError, ValueError):
            return None
    return _parse_dt(s)


def sync_gymaware_live(creds, log, squad=None):
    """Fast-path GymAware sync — only the current session window, for live-board latency.
    Mirrors sync_vald_live: the aggressive live poller only needs today's sets, not the
    full historical window the plain 'gymaware' sync pulls."""
    return sync_gymaware(creds, log, days_back=1, squad=squad)


def sync_gymaware(creds, log, days_back=30, squad=None):
    """Pull GymAware Cloud VBT set summaries into gymaware_results.json.

    HTTP Basic auth: username = Account ID, password = API token (a named token created on
    the GymAware 'API tokens' settings page). The API returns a newline-separated stream of
    JSON objects (NOT a JSON array) — one per set — so the body is parsed line by line.
    """
    account_id = (creds.get("account_id") or "").strip()
    token      = (creds.get("api_token") or "").strip()
    if not account_id or not token:
        return {"success": False, "message": "GymAware credentials not set — add Account ID and API token (GYMAWARE_ACCOUNT_ID / GYMAWARE_API_TOKEN) in .env", "records": 0}

    auth = (account_id, token)
    # /summaries accepts start/end as UTC epoch seconds, window capped at ~1 month by the API.
    now = datetime.utcnow()
    start_s = int((now - timedelta(days=days_back)).timestamp())
    end_s   = int(now.timestamp())

    try:
        resp = requests.get(
            f"{GYMAWARE_API_BASE}/summaries",
            params={"start": start_s, "end": end_s},
            auth=auth, timeout=30,
        )
    except Exception as e:
        return {"success": False, "message": f"GymAware request failed: {e}", "records": 0}

    if resp.status_code == 401:
        return {"success": False, "message": "GymAware auth rejected (401) — the Account ID / API-token pair isn't accepted. Confirm the exact Basic-auth username with GymAware (it may differ from the web login).", "records": 0}
    if not resp.ok:
        return {"success": False, "message": f"GymAware API error {resp.status_code}: {resp.text[:200]}", "records": 0}

    # Newline-separated JSON objects — parse per line, skipping blanks/garbage lines.
    sets_raw: list[dict] = []
    for line in resp.text.splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            obj = json.loads(line)
            if isinstance(obj, dict):
                sets_raw.append(obj)
        except json.JSONDecodeError:
            continue
    log(f"GymAware: {len(sets_raw)} set summary(ies) in {days_back}-day window")

    athletes = _get_athletes()
    athlete_id_by_name = {_norm_player_name(a.get("name")): str(a["id"]) for a in athletes}
    squad_names = _squad_norm_names(squad) if squad else None

    stored = 0
    exercises_seen: set[str] = set()
    unmatched: dict[str, int] = {}
    guest_sets = 0
    for s in sets_raw:
        if s.get("deleted"):
            continue
        name = (s.get("athleteName") or "").strip()
        forms = _gymaware_name_forms(name)
        if not forms:
            if name.lower() == "guest":
                guest_sets += 1
            continue
        if squad_names is not None and not any(f in squad_names for f in forms):
            continue
        athlete_id = next((athlete_id_by_name[f] for f in forms if f in athlete_id_by_name), None)
        if not athlete_id:
            unmatched[name] = unmatched.get(name, 0) + 1
            continue

        exercise = (s.get("exerciseName") or "Unknown").strip()
        exercises_seen.add(exercise)
        dt = _gymaware_recorded_dt(s.get("recorded"))
        if not dt:
            continue
        dt_nzt = dt.replace(tzinfo=timezone.utc).astimezone(NZT)

        metrics = {}
        for src_key, dst_key in _GYMAWARE_METRIC_FIELDS.items():
            v = _num_safe(s.get(src_key))
            if v is not None:
                metrics[dst_key] = v
        if not metrics:
            continue

        # No documented globally-unique set id, so derive a stable one for idempotent upserts:
        # a given athlete can't record two distinct sets of the same exercise at the same
        # instant, so (athleteReference|recorded|exercise) uniquely identifies the set.
        set_id = s.get("reference") or s.get("setReference") or f"{s.get('athleteReference','?')}|{s.get('recorded','?')}|{exercise}"

        _append_gymaware_result(athlete_id, {
            "set_id":            str(set_id),
            "exercise":          exercise,
            "date":              dt_nzt.strftime("%Y-%m-%d"),
            "recorded_utc":      str(s.get("recorded") or ""),
            "bar_weight_kg":     _num_safe(s.get("barWeight")),
            "athlete_weight_kg": _num_safe(s.get("athleteWeight")),
            "rep_count":         _num_safe(s.get("repCount")),
            "velocity_zone":     s.get("velocityZone"),
            "metrics":           metrics,
        })
        stored += 1

    if exercises_seen:
        log(f"GymAware: exercises seen — {', '.join(sorted(exercises_seen))}")
    if guest_sets:
        log(f"GymAware: skipped {guest_sets} unattributed 'Guest' set(s) (lifter didn't select a profile on the unit)")
    if unmatched:
        log(f"GymAware: {len(unmatched)} athlete name(s) with no roster match — {', '.join(sorted(unmatched))}")
    return {"success": True, "message": f"GymAware sync complete — {stored} set(s) stored", "records": stored}


_gymaware_results_lock = None


def _append_gymaware_result(athlete_id: str, record: dict) -> None:
    """Upsert one GymAware set into gymaware_results.json (keyed by athlete_id, deduped on
    set_id). Mirrors _append_force_result's atomic-write + snapshot behaviour."""
    import threading
    global _gymaware_results_lock
    if _gymaware_results_lock is None:
        _gymaware_results_lock = threading.Lock()

    path = DATA_DIR / "gymaware_results.json"
    set_id = record.get("set_id", "")
    with _gymaware_results_lock:
        try:
            data = json.loads(path.read_text()) if path.exists() else {}
        except Exception:
            data = {}
        existing = data.setdefault(athlete_id, [])
        if set_id and any(r.get("set_id") == set_id for r in existing):
            return
        existing.append(record)
        existing.sort(key=lambda r: r.get("recorded_utc", ""), reverse=True)
        _atomic_save(path, json.dumps(data, indent=2, ensure_ascii=False))


def _safe_float(d, *keys):
    for k in keys:
        v = d.get(k)
        if v is not None:
            try:
                return float(v)
            except (TypeError, ValueError):
                pass
    return None


# ── Public entry point ──────────────────────────────────────────────────────────

# ── Teambuildr wellness questionnaire pull ─────────────────────────────────────
# Uses Teambuildr's internal API (same one the web app calls) authenticated via
# username + password OAuth flow. No API key required — only TB credentials.

_TB_OAUTH_URL  = "https://api.teambuildr.com/oauth/token"
_TB_API_BASE   = "https://api.teambuildr.com"
_TB_CLIENT_ID  = "xBLi9kmYnG6i586"
_TB_CLIENT_SECRET = "xWlwYjVPKCyOkSk"

# Question abbreviation → canonical wellness field name
# These are the actual question abbrs from the Academy In-Season Wellness form.
_TB_ABBR_MAP = {
    "SOR":       "soreness",      # 1=Extremely Sore, 5=No Soreness (higher=better)
    "MNT":       "mental",        # 1=Not Great, 3=Good as Gold (higher=better)
    "Fuel":      "fuelling",      # higher=better
    "Hrs sleep": "sleep_hours",   # raw hours (numeric)
    "BW":        "bodyweight",    # kg, not used in composite
    "Anything":  "notes",         # free text, store separately
}

# Background colour → flag
def _tb_colour_flag(bg: str) -> str:
    c = (bg or "").upper().strip()
    if c in ("#0DCC8A", "#00CC8A"):
        return "green"
    if c in ("#FFCB47", "#FFB347"):
        return "amber"
    if "#FF" in c and c not in ("#FFFFFF",):
        return "red"
    return "neutral"

def _tb_wellness_composite(responses: dict) -> Optional[float]:
    """
    Composite 1–5 wellness score from raw TB question values.
    Only uses ordinal scale fields (not bodyweight or free text).
    Each field is normalised to 1–5 (5 = best) then averaged.
    """
    parts = []

    # soreness: TB scale 1–5, higher=better → already 1–5, higher=good
    sor = responses.get("soreness")
    if sor not in (None, "-", ""):
        try:
            v = float(sor)
            if 1 <= v <= 5:
                parts.append(v)   # 5 = no soreness = best
        except (TypeError, ValueError):
            pass

    # mental: TB scale 1–3, higher=better → scale to 1–5
    mnt = responses.get("mental")
    if mnt not in (None, "-", ""):
        try:
            v = float(mnt)
            if 1 <= v <= 3:
                parts.append(1 + (v - 1) * 2)  # maps 1→1, 2→3, 3→5
        except (TypeError, ValueError):
            pass

    # fuelling: TB scale unknown, assume 1–3 or 1–5 (normalise to 1–5)
    fuel = responses.get("fuelling")
    if fuel not in (None, "-", ""):
        try:
            v = float(fuel)
            if 1 <= v <= 5:
                parts.append(v)
            elif 1 <= v <= 3:
                parts.append(1 + (v - 1) * 2)
        except (TypeError, ValueError):
            pass

    # sleep hours: threshold <6 = poor, ≥7 = good, convert to 1–5
    slp = responses.get("sleep_hours")
    if slp not in (None, "-", ""):
        try:
            raw = str(slp).lower().replace("hours", "").replace("hour", "").strip()
            h = float(raw)
            if h >= 8:
                parts.append(5.0)
            elif h >= 7:
                parts.append(4.0)
            elif h >= 6:
                parts.append(3.0)
            elif h >= 5:
                parts.append(2.0)
            else:
                parts.append(1.0)
        except (TypeError, ValueError):
            pass

    return round(sum(parts) / len(parts), 2) if parts else None


def _tb_authenticate(username: str, password: str, log) -> Optional[str]:
    """OAuth password grant → returns access_token or None."""
    try:
        r = requests.post(
            _TB_OAUTH_URL,
            headers={
                "Content-Type": "application/x-www-form-urlencoded",
                "client-id": _TB_CLIENT_ID,
                "client-secret": _TB_CLIENT_SECRET,
            },
            data={
                "grant_type": "password",
                "username": username,
                "password": password,
                "client_id": _TB_CLIENT_ID,
                "client_secret": _TB_CLIENT_SECRET,
            },
            timeout=20,
        )
        r.raise_for_status()
        return r.json().get("access_token")
    except Exception as e:
        log(f"Teambuildr wellness: auth failed — {e}")
        return None


def _tb_api(path: str, token: str, params: Optional[dict] = None):
    """GET from api.teambuildr.com with Bearer auth."""
    return requests.get(
        f"{_TB_API_BASE}/{path.lstrip('/')}",
        headers={
            "Authorization": f"Bearer {token}",
            "client-id": _TB_CLIENT_ID,
            "client-secret": _TB_CLIENT_SECRET,
        },
        params=params,
        timeout=30,
    )


def sync_teambuildr_wellness(creds: dict, log) -> dict:
    """Pull Academy In-Season Wellness questionnaire responses from Teambuildr."""
    username = creds.get("tb_username") or creds.get("username", "")
    password = creds.get("tb_password") or creds.get("password", "")
    if not username or not password:
        return {"success": False, "message": "Teambuildr username/password not configured", "records": 0}

    log("Teambuildr wellness: authenticating…")
    token = _tb_authenticate(username, password, log)
    if not token:
        return {"success": False, "message": "Teambuildr authentication failed", "records": 0}

    # Get account code from /me
    try:
        me = _tb_api("me", token).json()
        account_code = me.get("accountCode") or me.get("organizationId")
        if not account_code:
            return {"success": False, "message": "Could not determine Teambuildr account code", "records": 0}
    except Exception as e:
        return {"success": False, "message": f"Teambuildr /me failed: {e}", "records": 0}

    log(f"Teambuildr wellness: account {account_code}, fetching questionnaires…")

    # Discover questionnaire IDs
    try:
        qs = _tb_api(f"accounts/{account_code}/questionnaires", token).json()
        if not isinstance(qs, list):
            return {"success": False, "message": "Unexpected questionnaire response format", "records": 0}
    except Exception as e:
        return {"success": False, "message": f"Teambuildr questionnaire list failed: {e}", "records": 0}

    # Use wellness-tagged questionnaires (contains Wellness / Check In in name)
    wellness_qs = [
        q for q in qs
        if any(kw in q.get("name", "").lower()
               for kw in ("wellness", "check in", "check-in", "readiness", "daily"))
    ]
    if not wellness_qs:
        wellness_qs = qs  # fallback: try all
    log(f"Teambuildr wellness: found {len(wellness_qs)} relevant questionnaire(s)")

    # Get all user IDs (athletes = non-admin)
    try:
        users = _tb_api(f"accounts/{account_code}/users", token).json()
        athlete_ids = [u["id"] for u in users if not u.get("admin") and u.get("id")]
        # Build id→name map
        tb_id_to_name = {u["id"]: f"{u.get('first','')} {u.get('last','')}".strip() for u in users}
    except Exception as e:
        return {"success": False, "message": f"Teambuildr users fetch failed: {e}", "records": 0}

    log(f"Teambuildr wellness: {len(athlete_ids)} athletes to pull")

    our_athletes = _get_athletes()
    end_dt   = datetime.now(NZT).replace(tzinfo=None)
    start_dt = end_dt - timedelta(days=14)
    start_str = start_dt.strftime("%Y-%m-%d")
    end_str   = end_dt.strftime("%Y-%m-%d")

    wellness_path = DATA_DIR / "wellness.json"
    existing: dict = {}
    if wellness_path.exists():
        try:
            existing = json.loads(wellness_path.read_text())
        except Exception:
            pass

    saved_count = 0
    for q in wellness_qs:
        q_id   = q["id"]
        q_name = q["name"]

        # Build URL with all athlete IDs
        params: dict = {
            "filterType": 1,
            "startDate":  start_str,
            "endDate":    end_str,
            "questionnaire": q_id,
            "useDateAssigned": "false",
            "showIncompleteData": "true",
        }
        for aid in athlete_ids:
            pass  # params can't have repeated keys via dict; use manual URL

        filter_qs = "&".join(f"filterIds={aid}" for aid in athlete_ids)
        base_url = (f"accounts/{account_code}/reports/questionnaire/multiple"
                    f"?filterType=1&{filter_qs}"
                    f"&startDate={start_str}&endDate={end_str}"
                    f"&questionnaire={q_id}&useDateAssigned=false&showIncompleteData=true")

        try:
            r = _tb_api(base_url, token)
            if not r.ok:
                log(f"Teambuildr wellness: report {q_id} returned {r.status_code}")
                continue
            report = r.json()
        except Exception as e:
            log(f"Teambuildr wellness: report fetch error — {e}")
            continue

        for athlete_data in report:
            tb_name  = athlete_data.get("name", "").strip()
            tb_id    = athlete_data.get("id")
            our_name = _match_athlete(tb_name, our_athletes)
            if not our_name:
                continue

            entries = existing.get(our_name, [])
            by_date = {e["date"]: e for e in entries}

            for day in (athlete_data.get("responses") or []):
                date_str = day.get("date", "")
                if not date_str:
                    continue
                # Skip days where nothing was submitted (all values are "-")
                has_value = any(
                    q_r["response"].get("value") not in ("-", None, "")
                    for q_r in (day.get("questions") or [])
                )
                if not has_value:
                    continue

                responses: dict = {}
                notes = None
                flags: dict = {}
                for q_r in (day.get("questions") or []):
                    abbr  = q_r.get("abbr", "")
                    field = _TB_ABBR_MAP.get(abbr)
                    val   = q_r["response"].get("value")
                    bg    = q_r["response"].get("backgroundColor", "#ffffff")
                    flag  = _tb_colour_flag(bg)
                    if field == "notes":
                        notes = str(val) if val not in (None, "-", "") else None
                    elif field and val not in (None, "-", ""):
                        responses[field] = val
                        flags[field] = flag

                composite = _tb_wellness_composite(responses)
                new_entry = {
                    "date":      date_str,
                    "form_name": q_name,
                    "form_id":   q_id,
                    "source":    "teambuildr_api",
                    "synced_at": datetime.utcnow().isoformat() + "Z",
                    "responses": responses,
                    "flags":     flags,
                    "notes":     notes,
                    "composite": composite,
                }
                if date_str not in by_date:
                    saved_count += 1
                by_date[date_str] = new_entry

            existing[our_name] = sorted(by_date.values(), key=lambda e: e["date"], reverse=True)

    _atomic_save(wellness_path, json.dumps(existing, indent=2))
    log(f"Teambuildr wellness: {saved_count} new entries saved")
    return {"success": True, "message": f"Wellness sync complete — {saved_count} entries", "records": saved_count}


SYNC_FNS = {
    "vald":                  sync_vald,
    "vald_live":             sync_vald_live,
    "teambuildr":            sync_teambuildr,
    "teambuildr_wellness":   sync_teambuildr_wellness,
    "smartabase":            sync_smartabase,
    "statsports":            sync_statsports,
    "gymaware":              sync_gymaware,
    "gymaware_live":         sync_gymaware_live,
}

def run_sync(source: str, credentials: dict, log_fn=print, anthropic_key: str = None, squad: str = None) -> dict:
    """
    Run the sync for a given source.
    Returns {"success": bool, "message": str, "records": int}
    """
    fn = SYNC_FNS.get(source)
    if not fn:
        return {"success": False, "message": f"Unknown source '{source}'"}
    try:
        # squad scoping applies to the live pollers (vald_live/gymaware_live) — other sync
        # functions (teambuildr, smartabase, the full non-live catch-ups, etc.) don't accept it.
        if source in ("vald_live", "gymaware_live") and squad:
            return fn(credentials, log_fn, squad=squad)
        return fn(credentials, log_fn)
    except Exception as e:
        return {"success": False, "message": str(e), "records": 0}


if __name__ == "__main__":
    import os, sys
    source = sys.argv[1] if len(sys.argv) > 1 else "vald"
    env_file = BASE / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                k, _, v = line.partition("=")
                os.environ[k.strip()] = v.strip()

    creds = {
        "token_url":     os.getenv("VALD_TOKEN_URL", "https://auth.prd.vald.com/oauth/token"),
        "audience":      os.getenv("VALD_AUDIENCE", "vald-api-external"),
        "client_id":     os.getenv("VALD_CLIENT_ID", ""),
        "client_secret": os.getenv("VALD_CLIENT_SECRET", ""),
        "api_base":      "https://prd-aue-api-extforcedecks.valdperformance.com",
        "api_key":       os.getenv("TEAMBUILDR_API_KEY") or os.getenv("STATSPORTS_API_KEY", ""),
        "team_id":       os.getenv("TEAMBUILDR_TEAM_ID") or os.getenv("STATSPORTS_TEAM_ID", ""),
        "base_url":      os.getenv("SMARTABASE_URL", ""),
        "username":      os.getenv("SMARTABASE_USERNAME", ""),
        "password":      os.getenv("SMARTABASE_PASSWORD", ""),
    }
    result = run_sync(source, creds)
    print(result)
