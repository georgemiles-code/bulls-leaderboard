@echo off
rem Engine supervisor loop. Launched HIDDEN by "Start Leaderboard (Windows).vbs" and runs the
rem engine with pythonw.exe (no console window), so nothing terminal-like is ever visible.
rem Relaunches the engine whenever it exits with code 42 (the auto-update restart). Output goes
rem to a log file (pythonw has no console, and this is also handy for diagnostics).
cd /d "%~dp0"
set "BULLS_DATA_DIR=%~dp0data"
set "BULLS_ENV_FILE=%~dp0.env"
set "BULLS_FRONTEND_DIR=%~dp0web"
set "BULLS_PORT=8097"
set "BULLS_RESTARTABLE=1"
set "LOGDIR=%LOCALAPPDATA%\Leaderboard"
if not exist "%LOGDIR%" mkdir "%LOGDIR%"
:loop
"%~dp0python-win\pythonw.exe" "%~dp0api\serve.py" >> "%LOGDIR%\engine.log" 2>&1
if "%errorlevel%"=="42" (
  ping -n 3 127.0.0.1 >nul
  goto loop
)
