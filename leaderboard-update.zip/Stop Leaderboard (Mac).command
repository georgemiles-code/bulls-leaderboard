#!/bin/bash
pkill -f "api/serve.py" 2>/dev/null
echo "Stopped. (Close the Leaderboard browser window with Cmd+Q if it's still open.)"
sleep 1
